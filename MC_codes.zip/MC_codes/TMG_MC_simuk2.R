rm(list=ls())

list.of.packages <- c("parallel")
new.packages <- list.of.packages[!(list.of.packages %in% installed.packages()[,"Package"])]
if(length(new.packages)) install.packages(new.packages)
library(parallel)

################################################################################
### Define Functions of DGP
################################################################################
Deme_i = function(paneldata_e,Tobs,i) {
  ei = as.matrix(paneldata_e[(1+(i-1)*Tobs):(i*Tobs),])
  ti = dim(ei)[1] 
  qti= diag(ti)-matrix(1, nrow=ti, ncol=1) %*% t(matrix(1, nrow=ti, ncol=1))/ti 
  deti = det( t(ei) %*% qti %*% ei)
  return(deti)
}

Simu_kappa = function(nobs,Tobs,k,m_y,gauss_y,m_x,hetero_x,dist_x,ar_x,para_case){
  ## Step 1: Generate x_it and lambda_n: dist_x, hetero_x, ar_x, te_x
  ###################################################################################
  x_nT_long = matrix(,(nobs*Tobs),(k-1)) 
  e_nT_long = matrix(,(nobs*Tobs),(k-1)) # standardiized errors in the xit equation
  
  for (j in 1: (k-1)) {
    ### 1(1). x_it: generate IID(0,1) errors distributed as Gaussian and uniform
    if (dist_x==1) {
      e_nT = matrix(rnorm(nobs*Tobs,0,1),nobs,Tobs) # (n by T) N(0,1)
      gamma2 = 0
    }
    if (dist_x==2) {
      e_0 = matrix(runif(nobs*Tobs,0,1),nobs,Tobs)
      e_nT = sqrt(12)*(e_0-1/2) # (n by T) uniform with mean=0 and std=1
      gamma2 = -6/5
    }
    
    ### 1(2) x_it: generate sigma_iv (hetero_x=0,1) and alpha_ix then plug in
    ### (i). static x_it with an interactive effect or not (ar_x=0, te_x=0,1,2) 
    ### (ii) dynamic x_it with hetero autoregressions (ar_x=1)
    # hetero_x==0: homogeneous variance of x
    if (hetero_x==0) {
      sigma_vnT = matrix(1,nobs,Tobs)
    }
    # hetero_x==1: heterogeneous variance of x
    if (hetero_x==1) {
      sigma_vnT = matrix(sigma_vn[,j],nobs,Tobs) # (n by T) same in a row
    }
    v_nT = e_nT*sigma_vnT # (n by T) # errors in the xit equation
    
    alphax_n = matrix(m_x[j,1],nobs,1) + axx_n[,j] # (n by 1)
    alphax_nT = matrix(alphax_n,nobs,Tobs) # (n by T) same in a row
    Th = 51 # number of existing periods before observed
    if (ar_x == 0) {
      phix_n = matrix(m_x[j,2],nobs,1) # (n by 1)
      phix_nT = matrix(phix_n,nobs,Tobs) # (n by T) same in a row
      ## include a common factor structure or time effects
      ft_n = t(matrix(rep(ft,nobs),Tobs,nobs)) # factors
      # factor loadings
      if (te_x==0) {
        gamma_n = matrix(0,nobs,Tobs)
      }
      if (te_x==1) {
        gamma_n = matrix(1,nobs,Tobs)
      }
      if (te_x==2) {
        gamma_n = matrix(runif(nobs,0,2),nobs,Tobs)
      }
      x_nT = alphax_nT*(1-phix_nT) + gamma_n*ft_n + v_nT # (n by T)
    }
    if (ar_x == 1) {
      tau_n = matrix(1,nobs,1) 
      phix_n = phixx_n[,j] # (n by 1) uniform (0,0.95)
      if (dist_x==1) {
        e_h = matrix(rnorm(nobs*Th,0,1),nobs,Th) # (n by T) normal(0,1)
      }
      if (dist_x==2) {
        e_h0 = matrix(runif(nobs*Th,0,1),nobs,Th)
        e_h = sqrt(12)*(e_h0-1/2) # (n by T) uniform
      }
      sigma_vh = matrix(sigma_vn[,j],nobs,Th)
      v_h = sigma_vh*e_h # (n by 51)
      v_hT = cbind(v_h,v_nT) # (n by (51+Tobs))
      x_hT = matrix(,nobs,(Th+Tobs))
      x_hT[,1] = matrix(0,nobs,1)
      if (te_x==0) {
        gamma_n = matrix(0,nobs,1)
      }
      if (te_x==1) {
        gamma_n = matrix(1,nobs,1)
      }
      if (te_x==2) {
        gamma_n = matrix(runif(nobs,0,2),nobs,1)
      }
      for ( j2 in 2:(Th+Tobs)) {
        fth_n = matrix(rep(fth[j2],nobs),nobs,1)
        x_hT[,j2] = alphax_n*(tau_n-phix_n) + gamma_n*fth_n + phix_n*x_hT[,(j2-1)]+sqrt(tau_n-phix_n^2)*v_hT[,j2]
      }
      x_nT = x_hT[,(Th+1):(Th+Tobs)]
    }
    
    e_nT_temp = matrix(t(e_nT),nobs*Tobs,1) # (nT by 1)
    e_nT_long[,j] = e_nT_temp 
    rm(e_nT_temp)
    
    x_nT_temp = matrix(t(x_nT),nobs*Tobs,1) # (nT by 1)
    x_nT_long[,j] = x_nT_temp 
    rm(x_nT_temp)
  }
  int_nT_long = matrix(1,nobs*Tobs) # (n by T)
  w_nT_long = cbind(int_nT_long, x_nT_long) # (nT by k) 
  
  ### 1(3). x_it: calculate lambda_i
  id_n = matrix(seq(1,nobs,by=1),nobs,1)
  deme_n = matrix(sapply(id_n,Deme_i,paneldata_e=e_nT_long,Tobs=Tobs),nobs,1) # (n by 1)
  lambda_n = (deme_n-(Tobs-1))/sqrt(2*(Tobs-1)+gamma2/Tobs*((Tobs-1)^2)) # (n by 1)
  ###################################################################################
  
  ### 2. Generate heterogeneous coefficients: case
  ###################################################################################
  sigma_zeta = para_case[1:k]  # (1 by k) 
  psi = para_case[(k+1):(2*k)] # (1 by k) 
  zeta_n = matrix(,nobs,k)
  eta_n = matrix(,nobs,k)
  theta_n = matrix(,nobs,k)
  theta_nT_long = matrix(,nobs*Tobs,k)
  for (j in c(1) ){ # individual fixed effects
    zeta_n[,j] = rnorm(nobs,0,sigma_zeta[j])
    eta_n[,j] = psi[j]*lambda_n + zeta_n[,j]
    theta_n[,j] = matrix(m_y[j],nobs,1) + eta_n[,j]
    theta_nT_long[,j] = matrix(t(matrix(theta_n[,j],nobs,Tobs)),nobs*Tobs,1)
  }
  for (j in 2:k){
    if (case==0) { # homogeneous slope coefficients - case 0
      theta_n[,j] = matrix(m_y[j],nobs,1) 
      theta_nT_long[,j] = matrix(t(matrix(theta_n[,j],nobs,Tobs)),nobs*Tobs,1)
    } else { # heterogeneous slope coefficients - cases 1,2,3,4,5
      zeta_n[,j] = rnorm(nobs,0,sigma_zeta[j])
      eta_n[,j] = psi[j]*lambda_n + zeta_n[,j]
      theta_n[,j] = matrix(m_y[j],nobs,1) + eta_n[,j]
      theta_nT_long[,j] = matrix(t(matrix(theta_n[,j],nobs,Tobs)),nobs*Tobs,1)
    }
  }
  ###################################################################################
  
  ### stochastic simulation of kappa
  A_r = mean((theta_nT_long[,2])^2*(x_nT_long)^2) 
  B_r = mean(theta_nT_long[,2]*x_nT_long) 
  cbind(A_r,B_r)
}

## Key parameters
k = 2 # dim(wit) = k
m_y = cbind(1,1) # True value of parameters of ineterests
m_x = matrix(cbind(1,0),(k-1),2)

sigma_a = sqrt(0.2)
sigma_b = matrix(sqrt(c(0.5,0.75)),(k-1),2) # 2 cases
sigma = rbind(matrix(sigma_a,1,2),sigma_b) 
rho_eta = matrix(c(0,0,0.25,0.25,0.5,0.5),k,3) # 3 cases
PR2 = cbind(0.2,0.4) # 2 cases
di1 = length(PR2)
di2 = dim(sigma_b)[2]
di3 = dim(rho_eta)[2]
ncase = di1*di2*di3
case_list = seq(1,ncase,by=1)

case_table = matrix(,(1+k+k+k+k),ncase)
sigma_zeta_list = matrix(,k,ncase)
psi_list = matrix(,k,ncase)
for (i1 in 1:di1) {
  for (i2 in 1:di2) {
    for (i3 in 1:di3) {
      ic = i3+(i2-1)*di3+(i1-1)*di2*di3
      for (j in 1:k){
        sigma_zeta_list[j,ic] = sqrt(sigma[j,i2]^2*(1-rho_eta[j,i3]^2))
        psi_list[j,ic] = rho_eta[j,i3]*sigma[j,i2]
      }
      case_table[,ic] = rbind(PR2[i1],sigma[1,i2]^2,sigma[2,i2]^2,rho_eta[1,i3],rho_eta[2,i3],sigma_zeta_list[1,ic]^2,sigma_zeta_list[2,ic]^2,psi_list[1,ic],psi_list[2,ic])
    }
  }
}
para_list = rbind(sigma_zeta_list,psi_list)
# PR2 = 0.2: (1) rho_beta=0, (2) rho_beta = 0.25, (3) rho_beta = 0.5, (4) rho_beta = 0.5 and PR^2 = 0.4
para_list = para_list[,c(1,2,3,9)] 
case_table = case_table[,c(1,2,3,9)] 
rownames(case_table) = c('PR2',"sigma_a2","sigma_b2","rho_a","rho_b","sigma_zeta_a2","sigma_zeta_b2","psi_a","psi_b")

case_list = seq(1,dim(case_table)[2],by=1)

# True value of parameters 
truem = matrix(m_y,1,k)

## Input data and fix the dimension
Nlist = c(5000)
Tlist = c(2,3,4,5,6,8)
NT = expand.grid(Nlist,Tlist) 
rep = 1000 # number of replication for stochastic simulation
dist_list = c(1)#,2) # Gaussian and uniform: errors in the xit equation

## Setting parameters
gauss_y = 0 # (0,1)
hetero_x = 1 # (0,1)
te_x_list = c(0,2)

kappa2 = matrix(,length(Tlist),length(case_list))

for (dist_x in dist_list)  {
  for (ar_x in c(0)) {
    for (te_x in te_x_list[1:(ar_x+1)]) {
      for (case in 3) {#case_list) {
        for (l in 1:dim(NT)[1]) {
          nobs = NT[l,1]
          Tobs = NT[l,2]
          
          para_case = para_list[,case]
          
          ## A stationary AR(1) process of a common effect
          set.seed(2022202299)
          fth = matrix(,Tobs+51,1); fth[1]=0; # with a zero initial value
          for (tid in 2:(Tobs+51) ) {
            vt = rnorm(1,0,1)
            fth[tid] = 0.9*fth[tid-1]+sqrt(1-0.9^2)*vt;rm(vt) 
          }
          ft = fth[52:(Tobs+51)] # for t=1,2,...,T
          
          set.seed(102021)
          AB_Rep = matrix(,rep,2)
          ft = seq(1,Tobs,by=1) 
          for (r in 1:rep) {
            sigma_vn = matrix(sqrt(0.5*rnorm(nobs,0,1)^2+0.5),nobs,1) # (n by 1)
            sigma_un = matrix(sqrt(0.5*rnorm(nobs,0,1)^2+0.5),nobs,1) # (n by 1)
            axx_n = matrix(rnorm(nobs,0,1),nobs,1) # (n by 1)
            phixx_n = matrix(runif(nobs,0,0.95),nobs,1) # (n by 1)
            AB_Rep[r,] = Simu_kappa(nobs,Tobs,k,m_y,gauss_y,m_x,hetero_x,dist_x,ar_x,para_case)
          }
          A_R = mean(AB_Rep[,1])
          B_R = mean(AB_Rep[,2])
          vbx_R = A_R - B_R^2
          PR2_c = case_table[1,case]
          kappa2[l,case] = (1-PR2_c)/PR2_c*vbx_R
        }
        name = paste("k2",dist_x,sep="dx")
        if (ar_x==1 & te_x==0) {
          name = paste(name,"_arx",sep="")
        }
        if (ar_x==1 & te_x==2) {
          name = paste(name,"_afx",sep="")
        }
        name = paste(name,sep="")
        assign(name,kappa2)
      }
    }
  }
}

k2.list = ls(pattern = "^k2"); rm(list = setdiff(ls(), k2.list))
save.image(file = "simukappa2.RData")






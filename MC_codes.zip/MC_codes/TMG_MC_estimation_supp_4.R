rm(list=ls())
load("simukappa2.RData")

list.of.packages <- c("parallel","MASS")
new.packages <- list.of.packages[!(list.of.packages %in% installed.packages()[,"Package"])]
if(length(new.packages)) install.packages(new.packages)
library(parallel)
library(MASS)

################################################################################
### Define Functions Calculate Statistics: (Bias, RMSE, T_test & Power, Coverage)
################################################################################
Bias = function(ests,truev) {
  ests = as.matrix(ests)
  truematrix = matrix(truev,nrow=nrow(ests),ncol=ncol(ests))
  colMeans(ests - truematrix)
}

Rmse = function(ests,truev) {
  ests = as.matrix(ests)
  truematrix = matrix(truev,nrow=nrow(ests),ncol=ncol(ests))
  sqrt(colMeans((ests - truematrix)^2))
}

T_test = function(truev,estsd,rep){
  ests = as.matrix(estsd[1:rep])
  sds = as.matrix(estsd[(rep+1):(2*rep)])
  truematrix = matrix(truev,nrow=nrow(ests),ncol=ncol(ests))
  colMeans(abs((ests-truematrix)/sds)>qnorm(p = 0.975))
}

pwlb=-2.5; pwrb=2.5; pwintv=0.01;
pwgrid = length(as.matrix(seq(as.numeric(0+pwlb),as.numeric(0+pwrb),by=pwintv)))
Power = function(truev,estsd,rep){
  h1 = as.matrix(seq(as.numeric(truev+pwlb),as.numeric(truev+pwrb),by=pwintv)) # values of alternatives (v0-0.5,v0+0.5) length = 101
  powers = sapply(h1,function(x) T_test(x,estsd,rep))
  powers
}

Coverage = function(truev,estsd,rep){
  ests = as.matrix(estsd[1:rep])
  sds = as.matrix(estsd[(rep+1):(2*rep)])
  truem = matrix(truev,nrow=nrow(ests),ncol=ncol(ests))
  cvr = abs(truem - ests) < qnorm(0.975,0,1)*sds # within the 95% CI excluding 2.5% from each tail
  mean(cvr)
}


################################################################################
### Define Functions of Estimation: 
### FE and FE-TE: (PMD_i, PMDV_i, FE_est, FE_TE_est)
### MG, MG-TE and MG-C: (Inv_i, OLS_i, Rw_i, Phiuu_i, MG_est, MG_TE_est)
### GP: (Minor, Cofactor, Adjoint1, Dw_i, Det_i, GPedn_i, GPuu_i, GP_est)
### SU: (SUN_est_l, SU_est_l, SU_est) 
### TMG, TMG-TE and TMG-C:
### (Minor, Cofactor, Adjoint1, Det_i, TOLS_i, Qw_i, MTxy_i, MTuu_i, Phiuu_i, TMG_an, TMG_TE_an, TMG_est)
################################################################################
######  FE estimator (PMD_i, PMDV_i, FE_est, FE_TE_est)
################################################################################
PMD_i = function(m1,m2,Tobs,id) {
  Ti = Tobs
  xi = as.matrix(m1[(1+(id-1)*Ti):(id*Ti),]) # (T by k1)
  yi = as.matrix(m2[(1+(id-1)*Ti):(id*Ti),]) # (T by k2)
  k1i = dim(xi)[2]
  k2i = dim(yi)[2]
  mti = diag(Ti)-matrix(1, nrow=Ti, ncol=1) %*% t(matrix(1, nrow=Ti, ncol=1))/Ti # (T by T)
  pd_i = matrix(t(xi) %*% mti %*% yi,k1i*k2i,1) # (k1*k2) by 1
  pd_i
}

PMDV_i = function(mx,mre,Tobs,id) {
  Ti = Tobs
  xi = as.matrix(mx[(1+(id-1)*Ti):(id*Ti),]) # (T by k )
  rei = as.matrix(mre[(1+(id-1)*Ti):(id*Ti),]) # (T by 1) residuals
  ki = dim(xi)[2]
  Mti = diag(Ti)-matrix(1, nrow=Ti, ncol=1) %*% t(matrix(1, nrow=Ti, ncol=1))/Ti # (T by T)
  pdv_i = matrix(t(xi) %*% Mti %*% rei %*% t(rei) %*% Mti %*% xi,ki*ki,1) # (k*k)  by 1
  pdv_i
}

FE_est = function(paneldata,nobs,Tobs,k) {
  nT = nobs*Tobs
  id_list = as.matrix(seq(1,nobs,by=1))
  int_nT_long = matrix(1,nobs*Tobs,1)
  x = as.matrix(paneldata[,2:k]) # nT by (k-1)
  w = cbind(int_nT_long,x) # (nT by k)
  y = matrix(paneldata[,1],nobs*Tobs,1) # (nT by 1)
  panel_int = cbind(y,w) # add intercepts
  
  # FE (1) calculate numerator and denominator of FE estimator
  xmx_n = matrix(sapply(id_list,PMD_i,m1=x,m2=x,Tobs=Tobs),(k-1)*(k-1),nobs) 
  xmx = matrix(rowMeans(xmx_n)/Tobs,(k-1),(k-1)) # (k-1 by k-1) average over nT
  xmy_n = matrix(sapply(id_list,PMD_i,m1=x,m2=y,Tobs=Tobs),k-1,nobs) # k=2: (1 by n)
  xmy = matrix(rowMeans(xmy_n)/Tobs,k-1,1) # (k-1 by 1) average over nT
  
  # FE (2) calculate estimators and residuals
  fe_hatb = solve(xmx) %*% xmy # (k-1 by 1) eq. (2.14)
  taut = matrix(1,Tobs,1) 
  mt = diag(1,Tobs)-taut %*% solve(t(taut)%*%taut) %*% t(taut) # (T by T)
  re_fe = as.matrix(y - x %*% fe_hatb) # (nT by 1) residuals
  
  # FE (3) calcualte asymptotic variance of FE estimators
  xmuumx_n = matrix(sapply(id_list,PMDV_i,mx=x,mre=re_fe,Tobs=Tobs),(k-1)*(k-1),nobs)
  xmuumx = matrix(rowMeans(xmuumx_n)/Tobs,k-1,k-1) # (k-1 by k-1) average over nT
  fe_avarb = solve(xmx) %*% xmuumx %*% solve(xmx) / nobs / Tobs # Pesaran (2015) p. 654 
  
  fe_hata =  mean(y - x %*% fe_hatb) 
  x_br = matrix(colMeans(x),k-1,1) # (k-1 by 1) average over nT
  fe_avara = t(x_br) %*% fe_avarb %*% x_br
  fe_acovab = t(x_br) %*% fe_avarb # (1 by k-1)
  
  # FE report results
  fe_avar = matrix(,1,(k+k*(k-1)/2))
  fe_avar[1,1:k] = append(fe_avara,diag(fe_avarb))
  acov_temp = fe_acovab
  if (k > 2) {
    for (j in 1:(k-2)) {
      acov_temp = append(acov_temp,fe_avarb[j,(j+1):(k-1)])
    }
  }
  fe_avar[1,(k+1):(k+k*(k-1)/2)] = acov_temp
  
  fe_hat = append(fe_hata,fe_hatb)
  fe_output = list(fe_hat,fe_avar)
  names(fe_output) = c("ests","avar")
  fe_output
}

FE_TE_est = function(paneldata,nobs,Tobs,k) {
  nT = nobs*Tobs
  id_list = as.matrix(seq(1,nobs,by=1))
  int_nT_long = matrix(1,nobs*Tobs,1)
  x = as.matrix(paneldata[,2:k]) # nT by (k-1)
  w = cbind(int_nT_long,x) # (nT by k)
  y = matrix(paneldata[,1],nobs*Tobs,1) # (nT by 1)
  panel_int = cbind(y,w) # add intercepts
  
  # FE-TE (1) eliminate the time effects
  x_n = matrix(t(x),Tobs*(k-1),nobs) # T*(k-1) by n
  x_bn = t(matrix(rowMeans(x_n),(k-1),Tobs)) # T by (k-1)
  x_bnm = t(matrix(t(x_bn),(k-1),Tobs*nobs)) # nT by (k-1)
  x_dn = x - x_bnm # (nT by k-1) x_{it} - x_{ot}
  
  y_n = matrix(t(y),Tobs,nobs) # T*(k-1) by n
  y_bn = t(matrix(rowMeans(y_n),1,Tobs)) # T by (k-1)
  y_bnm = t(matrix(t(y_bn),1,Tobs*nobs)) # T*(k-1) by n
  y_dn = y - y_bnm # nT by 1
  
  x = x_dn
  y = y_dn
  
  # FE-TE (2) calculate numerator and denominator of FE estimator
  xmx_n = matrix(sapply(id_list,PMD_i,m1=x,m2=x,Tobs=Tobs),(k-1)*(k-1),nobs) 
  xmx = matrix(rowMeans(xmx_n)/Tobs,(k-1),(k-1)) # (k-1 by k-1) average over nT
  xmy_n = matrix(sapply(id_list,PMD_i,m1=x,m2=y,Tobs=Tobs),k-1,nobs) # k=2: (1 by n)
  xmy = matrix(rowMeans(xmy_n)/Tobs,k-1,1) # (k-1 by 1) average over nT
  
  # FE-TE (3) calculate estimators and residuals
  fete_hatb = solve(xmx) %*% xmy # (k-1 by 1)
  re_fe = as.matrix(y - x %*% fete_hatb) # (nT by 1) 
  
  # FE-TE (4) calcualte ssymptotic variance 
  xmuumx_n = matrix(sapply(id_list,PMDV_i,mx=x,mre=re_fe,Tobs=Tobs),(k-1)*(k-1),nobs)
  xmuumx = matrix(rowMeans(xmuumx_n)/Tobs,k-1,k-1) # (k-1 by k-1) average over nT
  fete_avarb = solve(xmx) %*% xmuumx %*% solve(xmx) / nobs / Tobs 
  
  fete_hata =  mean(y - x %*% fete_hatb) # average fixed effects (1 by 1)
  x_br = matrix(colMeans(x),k-1,1) # (k-1 by 1) average over nT
  fete_avara = t(x_br) %*% fete_avarb %*% x_br
  fete_acovab = t(x_br) %*% fete_avarb # (1 by k-1)
  
  # FE report results
  fete_avar = matrix(,1,(k+k*(k-1)/2))
  fete_avar[1,1:k] = append(fete_avara,diag(fete_avarb))
  acov_temp = fete_acovab
  if (k > 2) {
    for (j in 1:(k-2)) {
      acov_temp = append(acov_temp,fete_avarb[j,(j+1):(k-1)])
    }
  }
  fete_avar[1,(k+1):(k+k*(k-1)/2)] = acov_temp
  
  fete_hat = append(fete_hata,fete_hatb)
  fete_output = list(fete_hat,fete_avar)
  names(fete_output) = c("ests","avar")
  fete_output
}
###### Fin: FE estimator

################################################################################
######  MG estimator (Inv_i, OLS_i, Rw_i, Phiuu_i, MG_est, MG_TE_est)
################################################################################
Inv_i = function(paneldata_w,nobs,Tobs,id) {
  wi = as.matrix(paneldata_w[(1+(id-1)*Tobs):(id*Tobs),])  # (T by k)
  m = t(wi) %*% wi
  is.matrix(try(solve(m),silent=T))
}

OLS_i = function(panel_int,nobs,Tobs,k,id){
  obsi = as.matrix(panel_int[(1+(id-1)*Tobs):(id*Tobs),]) # paneldata = {(yi,xi)} (nT by k+1) matrix
  yi = as.matrix(obsi[,1]) # yi (T by 1)
  wi = as.matrix(obsi[,2:(k+1)]) # wi (T by k) 
  ols_i = solve(t(wi) %*% wi) %*% (t(wi) %*%yi) 
  ols_i
}

Rw_i = function(paneldata_w,nobs,Tobs,id,k){
  wi = matrix(paneldata_w[(1+(id-1)*Tobs):(id*Tobs),],Tobs,k)  # (T by k)
  rw_i = wi %*% solve(t(wi) %*% wi)  # (T by k)
  rw_i
}

MG_est = function(paneldata,nobs,Tobs,k){
  id_list = as.matrix(seq(1,nobs,by=1))
  int_nT_long = matrix(1,nobs*Tobs,1)
  paneldata_w = cbind(int_nT_long,paneldata[,2:k]) # add intercepts to regressor
  paneldata_y = matrix(paneldata[,1],nobs*Tobs,1) # add intercepts to regressor
  panel_int = cbind(paneldata[,1],paneldata_w) # add intercepts to panel
  
  ## MG (1) determine whether MG estimator exists: 1 = invertible
  inv_n = as.matrix(sapply(id_list,Inv_i,paneldata_w=paneldata_w,nobs=nobs,Tobs=Tobs))
  nexist = 1 - sum(inv_n)/nobs # portion of units with non-invertible design matrix
  
  ## MG (2) calculate individual OLS estimators with non-singular wi'wi
  nobs = sum(inv_n) 
  inv_id = which(inv_n==1)
  ols_n = matrix(sapply(inv_id,OLS_i,panel_int=panel_int,nobs=nobs,Tobs=Tobs,k=k),k,nobs) #(k by n)
  
  ## MG (3) calculate (trimmed or not) MG estimator
  mg_hat = rowMeans(ols_n) # (k by 1)
  mg_bm = matrix(mg_hat, k ,nobs)
  avar_temp = nobs^(-1)*(nobs-1)^(-1)*(ols_n-mg_bm) %*% t(ols_n-mg_bm) #(t(ols_n) %*% qn %*% ols_n) # k by k
  mge = mg_hat
  
  acov_temp = avar_temp[1,2:k]
  if (k > 2) {
    for (j in 2:(k-1)) {
      acov_temp = append(acov_temp, avar_temp[j,(j+1):k])
    }
  }
  
  ## MG (4) report (trimmed or not) MG estimator
  mg_avar = matrix(,1,(k+k*(k-1)/2))
  if (mean(inv_n)==1 & mean(diag(avar_temp)>0)==1) {
    mg_est = mge
    mg_avar[1,1:k] = diag(avar_temp)
    mg_avar[1,(k+1):(k+k*(k-1)/2)] = acov_temp
  } else {
    mg_est = matrix(-99999,1,k)
    mg_avar = matrix(-99999,1,(k+k*(k-1)/2))
  }
  
  mg = list(nexist,mg_est,mg_avar)
  names(mg) = c("np","ests","avar")
  output = mg
  output 
}

MG_TE_est = function(paneldata,nobs,Tobs,k) {
  id_list = as.matrix(seq(1,nobs,by=1))
  int_nT_long = matrix(1,nobs*Tobs,1)
  paneldata_w = cbind(int_nT_long,paneldata[,2:k]) # add intercepts to regressor
  paneldata_y = matrix(paneldata[,1],nobs*Tobs,1) # add intercepts to regressor
  panel_int = cbind(paneldata[,1],paneldata_w) # add intercepts to panel
  
  ## calculate MG estimator
  ##################################################
  ## MG (1) determine whether MG estimator exists: 1 = invertible
  inv_n = as.matrix(sapply(id_list,Inv_i,paneldata_w=paneldata_w,nobs=nobs,Tobs=Tobs))
  nexist = 1 - sum(inv_n)/nobs # portion of units with non-invertible design matrix
  
  ## MG (2) calculate individual OLS estimators with non-singular wi'wi
  keep_n = matrix(t(matrix(inv_n,nobs,Tobs)),nobs*Tobs,1)
  paneldata_w = paneldata_w[which(keep_n==1),]
  paneldata_y = paneldata_y[which(keep_n==1),]
  panel_int = cbind(paneldata_y,paneldata_w) 
  nobs = sum(inv_n) 
  inv_id = seq(1,nobs,1)   #inv_id = which(inv_n==1)
  ols_n = matrix(sapply(inv_id,OLS_i,panel_int=panel_int,nobs=nobs,Tobs=Tobs,k=k),k,nobs) #(k by n)
  
  ## MG (3) calculate MG estimator
  mg_hat = rowMeans(ols_n) # (k by 1)
  ##################################################
  
  ## calculate MG-TE estimator under tau'phi=0
  #################################################################
  w_n = matrix(t(paneldata_w),k*Tobs,nobs) # (Tk by n)
  w_bn = t(matrix(rowMeans(w_n),k,Tobs)) # (T by k) average over n
  taut = matrix(1,Tobs,1) 
  mt = diag(1,Tobs)-taut %*% solve(t(taut)%*%taut) %*% t(taut) # (T by T)
  rw_n = sapply(inv_id,Rw_i,paneldata_w=paneldata_w,nobs=nobs,Tobs=Tobs,k=k) # Tk by n 
  rw_bn = matrix(rowMeans(rw_n),Tobs,k) # (T by k)
  
  y_n = matrix(paneldata_y,Tobs,nobs) # (T by n)
  y_bn = matrix(rowMeans(y_n),Tobs,1) # (T by 1) {y_it} average over n for each t
  
  ## MG-TE (1) calculate estimator phi_hat and theta_hat
  phi_hat = solve(diag(1,Tobs)-mt%*%w_bn%*% t(rw_bn)) %*% mt %*% (y_bn-w_bn%*% mg_hat)
  theta_hat = mg_hat - t(rw_bn) %*%phi_hat
  
  ## MG-TE (2) calculate asymptotic variance of theta_hat
  phie_nT = matrix(matrix(phi_hat,Tobs,nobs),Tobs*nobs,1)
  ydte_nT = paneldata_y - phie_nT # (nT by 1) 
  panel_dte = cbind(ydte_nT,paneldata_w)  
  theta_n = sapply(inv_id,OLS_i,panel_int=panel_dte,nobs=nobs,Tobs=Tobs,k=k) # (k by n)
  theta_bm = matrix(theta_hat,k,nobs)
  theta_av0 = (nobs*(nobs-1))^(-1)*(theta_n-theta_bm) %*% t(theta_n-theta_bm) # (k by k) 
  theta_av = solve(diag(1,k)-t(rw_bn)%*%mt%*%w_bn)%*%theta_av0%*%t(solve(diag(1,k)-t(rw_bn)%*%mt%*% w_bn)) 
  
  ## MG-TE asymptotic variance of time effects phi
  mgte_hat = as.matrix(c(phi_hat,theta_hat)) # (T+k) by 1: phi_hat, theta_hat 
  phiuu_n = sapply(inv_id,Phiuu_i,paneldata=paneldata,nobs=nobs,Tobs=Tobs,k=k,est=mgte_hat)
  phiuu_bn = matrix(rowMeans(phiuu_n),Tobs,Tobs)
  phi_av0 = nobs^(-1)*phiuu_bn
  phi_av = mt %*% ( w_bn %*% theta_av %*% t(w_bn) + phi_av0 ) %*% mt
  #################################################################
  
  ## Report the estimated asymptotic variance of TMG-TE
  #################################################################
  theta_cov = theta_av[1,2:k]
  if (k > 2) {
    for (j in 2:(k-1)) {
      theta_cov = append(theta_cov,theta_av[j,(j+1):k])
    }
  }
  theta_avar = matrix(,1,(k+k*(k-1)/2))
  theta_avar[1,1:k] = diag(theta_av)
  theta_avar[1,(k+1):(k+k*(k-1)/2)] = theta_cov
  phi_avar = diag(phi_av)
  #################################################################
  
  ## MG-C estimator
  ##################################################################
  ## calculate TMG-C estimator under tau'phi=0
  if (Tobs>k) {
    mtxy_n = sapply(id_list,MTxy_i,paneldata=paneldata,nobs=nobs,Tobs=Tobs,k=k)
    mtx_bn = matrix(rowMeans(mtxy_n[1:(Tobs*Tobs),]),Tobs,Tobs)
    mty_bn = matrix(rowMeans(mtxy_n[(Tobs*Tobs+1):(Tobs*(Tobs+1)),]),Tobs,1)
    phi_c = solve(mtx_bn) %*% mty_bn
    
    mtuu_n = sapply(id_list,MTuu_i,paneldata=paneldata,nobs=nobs,Tobs=Tobs,k=k,phi_c=phi_c)
    mtuu_bn = matrix(rowMeans(mtuu_n),Tobs,Tobs)
    phic_av = nobs^(-1)*solve(mtx_bn) %*% mtuu_bn %*% t(solve(mtx_bn))
    
    phic_nT = matrix(matrix(phi_c,Tobs,nobs),Tobs*nobs,1)
    ydtc_nT = paneldata_y - phic_nT # (nT by 1) vector of yit-phit_hat
    panel_dtc = cbind(ydtc_nT,paneldata_w) 
    thetac_n = sapply(inv_id,OLS_i,panel_int=panel_dtc,nobs=nobs,Tobs=Tobs,k=k) # (k by n)
    theta_c = matrix(rowMeans(thetac_n),k,1)
    
    ## TMG-C asymptotic variance of E(theta_i)
    thetac_bm = matrix(theta_c,k,nobs)
    thetac_av0 = (nobs*(nobs-1))^(-1)*(thetac_n-thetac_bm) %*% t(thetac_n-thetac_bm) # (k by k) (46)
    rw_n = sapply(inv_id,Rw_i,paneldata_w=paneldata_w,nobs=nobs,Tobs=Tobs,k=k) # kT by n 
    rw_bn = matrix(rowMeans(rw_n),k,Tobs) # (k by T)
    thetac_av1 = rw_bn %*% phic_av %*% t(rw_bn)
    thetac_av = thetac_av0 + thetac_av1
    
    thetac_cov = thetac_av[1,2:k]
    if (k > 2) {
      for (j in 2:(k-1)) {
        thetac_cov = append(thetac_cov,thetac_av[j,(j+1):k])
      }
    }
    thetac_avar = matrix(,1,(k+k*(k-1)/2))
    thetac_avar[1,1:k] = diag(thetac_av)
    thetac_avar[1,(k+1):(k+k*(k-1)/2)] = thetac_cov
    
    phic_avar = diag(phic_av)
  }
  ###################################################################
  
  
  # report TMG estimator with time effects
  #################################################################
  if (Tobs==k) {
    mgte_output = list(nexist,t(theta_hat),theta_avar,t(phi_hat),t(phi_avar)) # 1+k+(k+k*(k-1)/2))+ T+(T+T*(T-1)/2)
    names(mgte_output) = c("np","ests","avar","tests","tavar")
    output = list(mgte_output)
    names(output) = c("mgte")
  }
  if (Tobs>k) {
    mgte_output = list(nexist,t(theta_hat),theta_avar,t(phi_hat),t(phi_avar)) # 1+k+(k+k*(k-1)/2))+ T+(T+T*(T-1)/2)
    names(mgte_output) = c("np","ests","avar","tests","tavar")
    mgc_output = list(nexist,t(theta_c),thetac_avar,t(phi_c),t(phic_avar)) # 1+k+(k+k*(k-1)/2))+ T+(T+T*(T-1)/2)
    names(mgc_output) = c("np","ests","avar","tests","tavar")
    output = list(mgte_output,mgc_output)
    names(output) = c("mgte","mgc")
  }
  output
}

###### Fin: MG estimators 

################################################################################
######  GP estimator 
#### (Minor, Cofactor, Adjoint1, Dw_i, Det_i, GPedn_i, GPuu_i, GP_est)
################################################################################
# T=k calcualte the determinant of regressors 
Dw_i = function(paneldata_w,nobs,Tobs,k,id) {
  wi = matrix(paneldata_w[(1+(id-1)*Tobs):(id*Tobs),],Tobs,k)  # (T by k) with T=K
  dwi = det(wi) 
  dwi
}

# GP: calculate denomiator and numerator for estimators of both time effects and hetero coeff 
GPedn_i = function(panel_int,trim_n,nobs,Tobs,k,hn,te,id){
  obsi = as.matrix(panel_int[(1+(id-1)*Tobs):(id*Tobs),]) # paneldata = {(yi,xi)} (nT by k+1) matrix
  yi = as.matrix(obsi[,1]) # yi (T by 1)
  wi = as.matrix(obsi[,2:(k+1)]) # wi (T by k) 
  trimi = trim_n[id] # index of trimming: 1 trim
  
  # no time effects
  if (te==0 ){
    dwinv_i = matrix(0,Tobs,k) # (T by k)
    if (trimi==0) {
      dwinv_i = wi %*% solve( t(wi) %*% wi )
    }
    qi = (1-trimi)*dwinv_i # (T by k)
    ri = (1-trimi)*wi# (T by k)
    qri = t(qi) %*% ri # k by k
    qyi = t(qi) %*% yi # k by 1
  }
  
  # with time effects
  if (te>0) {
    # ts=1 (intercepts) or ts=k (all coefficients)
    if (te == 1) {
      v0 = matrix(0,1,(Tobs-1)) # 1 by (T-1)
      z0 = diag(1,(Tobs-1)) # (T-1) by (T-1)
      zi = rbind(v0,z0) # a common intercept shift (T by T-1)
    } else {
      zi = matrix(0,Tobs,((Tobs-1)*k)) # time shifters (T by (T-1)k)
      for (idx in 2:Tobs) {
        zi[idx, (1+k*(idx-2)):(k+k*(idx-2))] = wi[idx,]
      }
    }
    
    # irregular estimator of time effects with T=k
    if (Tobs==k) {
      wzi = Adjoint1(wi) %*% zi
      winv_i = matrix(0,Tobs,k) 
      if (trimi==0) {
        winv_i = 1/det(wi)*diag(1,k)
      }
      qi = cbind(trimi/hn*wzi,(1-trimi)*winv_i) # (T by (Tobs-1)k+k)
      ri = cbind(wzi,(1-trimi)*det(wi)*diag(1,k)) # (T by (Tobs-1)k+k)
      qri = t(qi) %*% ri # (Tobs-1)k+k by (Tobs-1)*k+k
      qyi = t(qi) %*% Adjoint1(wi) %*% yi # (Tobs-1)*k+k by 1
    }
    
    # regular estimator of time effects with T=k
    if (Tobs>k) {
      mwi = diag(1,Tobs)- wi %*% solve(t(wi) %*% wi) %*% t(wi) # T by T
      mwzi = mwi %*% zi # T by (T-1)k
      wwinv_i = matrix(0,k,k) 
      if (trimi==0) {
        wwinv_i = solve(t(wi) %*% wi)
      }
      qi = cbind(mwzi,(1-trimi)*wi %*% wwinv_i)
      ri = cbind(zi,(1-trimi)*wi)
      qri = t(qi) %*% ri
      qyi = t(qi) %*% yi # (Tobs-1)*k+k by 1
    }
  }
  cbind(qri,qyi) # k by (k+1)
}

# GP: calculate asymptotic variance for each i
GPuu_i = function(panel_int,trim_n,nobs,Tobs,k,hn,te,gp_hat,id){
  obsi = as.matrix(panel_int[(1+(id-1)*Tobs):(id*Tobs),]) # paneldata = {(yi,xi)} (nT by k+1) matrix
  yi = as.matrix(obsi[,1]) # yi (T by 1)
  wi = as.matrix(obsi[,2:(k+1)]) # wi (T by k) 
  trimi = trim_n[id] # index of trimming: 1=trim
  
  # no time effects
  ###########################
  if (te==0) {
    dwinv_i = matrix(0,Tobs,k) # (T by k)
    if (trimi==0) {
      dwinv_i = wi %*% solve( t(wi) %*% wi )
    }
    qi = (1-trimi)*dwinv_i # (T by k)
    ri = (1-trimi)*wi# (T by k)
    qri = t(qi) %*% ri # k by k
    qyi = t(qi) %*%  yi # k by 1
    uhat_i =  yi - ri %*% gp_hat
  }
  ###########################
  
  # with time effects
  if (te>0) {
    # construct Zi matrix: ts=1 (intercepts) or ts=k (all coefficients)
    ###########################
    if (te == 1) {
      v0 = matrix(0,1,(Tobs-1))
      z0 = diag(1,(Tobs-1))
      zi = rbind(v0,z0) # a common intercept shift (T by T-1)
    } else {
      zi = matrix(0,Tobs,((Tobs-1)*k)) # time shifters (T by (T-1)k)
      for (idx in 2:Tobs) {
        zi[idx, (1+k*(idx-2)):(k+k*(idx-2))] = wi[idx,]
      }
    }
    ###########################
    # irregular estimator by GP (2012)
    ###########################
    if (Tobs==k) {
      wzi = Adjoint1(wi) %*% zi
      winv_i = matrix(0,Tobs,k) 
      if (trimi==0) {
        winv_i = 1/det(wi)*diag(1,Tobs,k)
      }
      qi = cbind(trimi/hn*wzi,(1-trimi)*winv_i) # (T by (Tobs-1)k+k)
      ri = cbind(wzi,(1-trimi)*det(wi)*diag(1,Tobs,k)) # (T by (Tobs-1)k+k)
      uhat_i = Adjoint1(wi) %*% yi - ri %*% gp_hat
    } 
    ###########################
    # regular estimator by Chamberlain (1992)
    ###########################
    if (Tobs>k) {
      mwi = diag(1,Tobs)- wi %*% solve(t(wi) %*% wi) %*% t(wi)
      mwzi = mwi %*% zi # T by (T-1)k
      wwinv_i = matrix(0,k,k) 
      if (trimi==0) {
        wwinv_i = solve(t(wi) %*% wi)
      }
      qi = cbind(mwzi,(1-trimi)*wi%*% wwinv_i)
      ri = cbind(zi,(1-trimi)*wi)
      uhat_i = yi - ri %*% gp_hat
    }
    ###########################
  }
  uui = (t(qi) %*% uhat_i) %*% t((t(qi) %*% uhat_i)) # (Tobs-1)k+k by (Tobs-1)k+k
  uui 
}

GP_est = function(paneldata,nobs,Tobs,k,te){
  id_list = as.matrix(seq(1,nobs,by=1))
  int_nT_long = matrix(1,nobs*Tobs,1)
  paneldata_w = cbind(int_nT_long,paneldata[,2:k])
  panel_int = cbind(paneldata[,1],paneldata_w) # add intercepts
  dimte = 0*(te==0)+(Tobs-1)*(te==1)+(Tobs-1)*k*(te==((Tobs-1)*k))
  
  # GP (1) calculate di = det(Wi'Wi)
  det_n = sapply(id_list,Det_i,paneldata_w=paneldata_w,nobs=nobs,Tobs=Tobs,k=k) 
  
  ## GP (2) calculate the threshold and indexes of trimming
  if (Tobs==k) {
    dw_n = sapply(id_list,Dw_i,paneldata_w=paneldata_w,nobs=nobs,Tobs=Tobs,k=k) 
    sd_hat = sd(dw_n); qn_hat = IQR(dw_n)
    c = 1/2*min(sd_hat,qn_hat/1.34)
  } else {
    c = sqrt(mean(det_n))
  }
  hn = c*(nobs^(-1/3))
  hn2 = hn^2
  trim_n = (det_n<=hn2)
  
  ## GP (3) calculate the numertor and denominator of GP estimators 
  gpedn_n = sapply(id_list,GPedn_i,panel_int=panel_int,trim_n=trim_n,nobs=nobs,Tobs=Tobs,k=k,hn=hn,te=te)
  # denominator: mean(Qi'Ri) lower-triangular matrix
  gped = matrix(rowMeans(gpedn_n[1:((dimte+k)^2),]),(dimte+k),(dimte+k)) # denominator
  # numerator: mean(Qi'yi)
  gpen = matrix(rowMeans(gpedn_n[(((dimte+k)^2)+1):(((dimte+k)^2)+(dimte+k)),]),(dimte+k),1) # numerator
  gp_hat = solve(gped) %*% gpen # (T-1+k)
  
  ## GP (4) calculate the asymptotic variance of the GP estimators 
  uu_n = sapply(id_list,GPuu_i,panel_int=panel_int,trim_n=trim_n,nobs=nobs,Tobs=Tobs,k=k,hn=hn,te=te,gp_hat=gp_hat)
  uu_hat = matrix(rowMeans(uu_n), (dimte+k),(dimte+k))
  avar_hat = 1/nobs*solve(gped) %*% uu_hat %*% t(solve(gped)) # (T-1+k) by (T-1+k) 
  
  ## report GP estimates after transformation between different normalizations of time effects
  if (te==0) {
    theta_hat = gp_hat
    theta_av = avar_hat
  }
  if (te==1) {
    vte1 = -1/Tobs+rbind(matrix(0,1,Tobs-1),diag(1,Tobs-1)) # T by (T-1) phi* to phi
    vte2 = matrix(0,Tobs,k) # (T by k) alpha* to phi (zeros)
    vte = cbind(vte1,vte2) # T by (T-1+k) matrix 
    va = matrix(c(rep(1/Tobs,Tobs-1),1,rep(0,k-1)),1,(Tobs-1+k)) # 1 by (T-1+k) vector
    vb = cbind(matrix(0,k-1,Tobs),diag(1,k-1)) # (k-1) by (T-1+k) matrix
    trm = rbind(vte,va,vb) # (T-1+k) by (T-1+k) matrix
    
    gp_hat2 = trm %*% gp_hat
    avar_hat2 = trm %*% avar_hat %*% t(trm)
    
    phi_hat = gp_hat2[1:Tobs]
    phi_av = avar_hat2[1:Tobs,1:Tobs]
    theta_hat = gp_hat2[(Tobs+1):(Tobs+k)]
    theta_av = avar_hat2[(Tobs+1):(Tobs+k),(Tobs+1):(Tobs+k)]
    phi_avar = diag(phi_av)
  }
  if (te>1) {
    idte = seq(1,Tobs-1,by=k)
    idw = c(((Tobs-1)*k+1):((Tobs-1)*k+k))
    id = c(idte,idw)
    gp_hat1 = as.matrix(gp_hat[id]) # phi*, E(theta_i)
    
    idm = expand.grid(id,id)
    avar_hat1 = matrix(,length(gp_hat1),length(gp_hat1))
    idx = seq(1,length(gp_hat1),by=1)
    idm1 = expand.grid(idx,idx)
    for (s in 1:dim(idm)[1]) {
      i = idm[s,2]; j = idm[s,1];
      temp = avar_hat[i,j]
      i1 = idm1[s,2]; j1 = idm1[s,1];
      avar_hat1[i1,j1] = temp; rm(temp)
    }
    
    vte1 = -1/Tobs+rbind(matrix(0,1,Tobs-1),diag(1,Tobs-1)) # T by (T-1) phi* to phi
    vte2 = matrix(0,Tobs,k) # (T by k) alpha* to phi (zeros)
    vte = cbind(vte1,vte2) # T by (T-1+k) matrix 
    va = matrix(c(rep(1/Tobs,Tobs-1),1,rep(0,k-1)),1,(Tobs-1+k)) # 1 by (T-1+k) vector
    vb = cbind(matrix(0,k-1,Tobs),diag(1,k-1)) # (k-1) by (T-1+k) matrix
    trm = rbind(vte,va,vb) # (T-1+k) by (T-1+k) matrix
    
    gp_hat2 = trm %*% gp_hat1
    avar_hat2 = trm %*% avar_hat1 %*% t(trm)
    
    phi_hat = gp_hat2
    phi_av = avar_hat
    theta_hat = gp_hat2[(Tobs+1):(Tobs+k)]
    theta_av = avar_hat2[(Tobs+1):(Tobs+k),(Tobs+1):(Tobs+k)]
    phi_avar = diag(phi_av)
  }
  
  theta_cov = theta_av[1,2:k]
  if (k > 2) {
    for (j in 2:(k-1)) {
      theta_cov = append(theta_cov,theta_av[j,(j+1):k])
    }
  }
  theta_avar = matrix(,1,(k+k*(k-1)/2))
  theta_avar[1,1:k] = diag(theta_av)
  theta_avar[1,(k+1):(k+k*(k-1)/2)] = theta_cov
  
  np = mean(trim_n) # trimmed portion
  
  if (te==0) {
    gp_output = list(np,theta_hat,theta_avar)
    names(gp_output) = c("np","ests","avar")
  }
  if (te>0) {
    gp_output = list(np,theta_hat,theta_avar,phi_hat,phi_avar)
    names(gp_output) = c("np","ests","avar","tests","tavar")
  }
  gp_output
}

###### Fin: GP estimator

################################################################################
######  SU (SUN_est_l, SU_est_l, SU_est) 
################################################################################
SUN_est_l = function(paneldata,nobs,Tobs,k,L){
  t=0 # time effects only in intercepts
  p = k
  N = nobs
  T = Tobs
  
  R = matrix(c(0,0,0,0),2,2)      # For t = 1 for Monte Carlo
  if( t == 2 ){
    R = diag(p)
  }
  paneldata_x = matrix(paneldata[,2],2,nobs)
  paneldata_y = matrix(paneldata[,1],2,nobs) 
  
  X1 = matrix(paneldata_x[1,],nobs,1)
  X2 = matrix(paneldata_x[2,],nobs,1)
  Y1 = matrix(paneldata_y[1,],nobs,1)
  Y2 = matrix(paneldata_y[2,],nobs,1)
  
  ################################################################
  # ADJOINT MATRIX FUNCTION
  ################################################################
  adjoint <- function(A){
    adjA = matrix(0,dim(A)[2],dim(A)[1])
    for( i in 1:(dim(A)[1]) ){
      for( j in 1:(dim(A)[2]) ){
        adjA[j,i] = (-1)^(i+j) * det(as.matrix(A[-i,-j]))
      }
    }
    return( adjA )
  }
  
  ################################################################
  # D, BOLD-FACE X, BOLD-FACE X*, BOLD-FACE X^{-1}, & BOLD-FACE W
  ################################################################
  i = 1
  D = det(rbind(cbind(1,X1[i,1]),cbind(1,X2[i,1])))
  bfX = list(rbind(cbind(1,X1[i,1]),cbind(1,X2[i,1])))
  bfXstr = list(adjoint(rbind(cbind(1,X1[i,1]),cbind(1,X2[i,1]))))
  bfXinv = list(ginv(rbind(cbind(1,X1[i,1]),cbind(1,X2[i,1]))))
  #bfW = list(rbind(0,cbind(1,X2[i,1])))
  bfW = list(rbind(0,cbind(0,0)))
  bfY = list(rbind(Y1[i,1],Y2[i,1]))
  for( i in 2:N ){
    D = c(D,det(rbind(cbind(1,X1[i,1]),cbind(1,X2[i,1]))))
    bfX[length(bfX)+1] = list(rbind(cbind(1,X1[i,1]),cbind(1,X2[i,1])))
    bfXstr[length(bfXstr)+1] = list(adjoint(rbind(cbind(1,X1[i,1]),cbind(1,X2[i,1]))))
    bfXinv[length(bfXinv)+1] = list(ginv(rbind(cbind(1,X1[i,1]),cbind(1,X2[i,1]))))
    bfW[length(bfW)+1] = list(rbind(0,cbind(0,0))) #list(rbind(0,cbind(1,X2[i,1])))
    bfY[length(bfY)+1] = list(rbind(Y1[i,1],Y2[i,1]))
  }
  
  ################################################################
  # h AND b (GRAHAM & POWELL, 2012, PAGE 2138)
  ################################################################
  h = min(c(sd(D), (quantile(D,0.75)-quantile(D,0.25))/1.34 )) / N^(1/(2*L+1)) / 2
  
  ################################################################
  # h_hat, e1, D0L, D1L
  ################################################################
  i = 1
  h_hat = (abs(D[i])<=h)*matrix(D[i]^(0:(L-1)),L,1) / N
  e1 = matrix(c(1, array(0,L)),L+1,1)
  D0L = list((abs(D[i])<=h)*matrix(D[i]^(0:L),L+1,1))
  D1L = list((abs(D[i])<=h)*matrix(D[i]^(1:L),L,1))
  for(i in 2:N){
    h_hat = h_hat + (abs(D[i])<=h)*matrix(D[i]^(0:(L-1)),L,1) / N
    D0L[length(D0L)+1] = list((abs(D[i])<=h)*matrix(D[i]^(0:L),L+1,1))
    D1L[length(D1L)+1] = list((abs(D[i])<=h)*matrix(D[i]^(1:L),L,1))
  }
  
  ################################################################
  # ESTIMATE DELTA
  ################################################################
  END0LD0L = 0                                     # E_N[D0L D0L']
  for( i in 1:N ){
    D0Li = matrix(unlist(D0L[i]),L+1,1)
    END0LD0L = END0LD0L + D0Li%*%t(D0Li) / N
  }
  
  denominator = 0
  numerator = 0
  for( i in 1:N ){
    D0Li = matrix(unlist(D0L[i]),L+1,1)
    XstrWi = matrix(unlist(bfXstr[i]),T,p)%*%matrix(unlist(bfW[i]),T,(T-1)*p)
    XstrYi = matrix(unlist(bfXstr[i]),T,p)%*%matrix(unlist(bfY[i]),T,1)
    denominator = denominator + as.numeric(t(D0Li)%*%ginv(END0LD0L)%*%e1) * t(XstrWi) %*% XstrWi / N
    numerator   = numerator   + as.numeric(t(D0Li)%*%ginv(END0LD0L)%*%e1) * t(XstrWi) %*% XstrYi / N
  }
  delta_hat = ginv(denominator)%*%numerator
  
  ################################################################
  # ESTIMATE GAMMA
  ################################################################
  END1LD1L = 0                                     # E_N[D1L D1L']
  for( i in 1:N ){
    D1Li = matrix(unlist(D1L[i]),L,1)
    END1LD1L = END1LD1L + D1Li%*%t(D1Li) / N
  }
  
  gamma_hat = 0
  for( i in 1:N ){
    D1Li = matrix(unlist(D1L[i]),L,1)
    XstrWi = matrix(unlist(bfXstr[i]),T,p)%*%matrix(unlist(bfW[i]),T,(T-1)*p)
    XstrYi = matrix(unlist(bfXstr[i]),T,p)%*%matrix(unlist(bfY[i]),T,1)
    gamma_hat = gamma_hat + (XstrYi - XstrWi %*% delta_hat) %*% t(D1Li) / N
  }
  gamma_hat = gamma_hat %*% ginv(END1LD1L)
  
  ################################################################
  # ESTIMATE BETA_L
  ################################################################
  beta_M_hat_numerator = 0
  for( i in 1:N ){
    XstrWi = matrix(unlist(bfXstr[i]),T,p)%*%matrix(unlist(bfW[i]),T,(T-1)*p)
    XstrYi = matrix(unlist(bfXstr[i]),T,p)%*%matrix(unlist(bfY[i]),T,1)
    if( abs(D[i])>h ){
      beta_M_hat_numerator = beta_M_hat_numerator + (abs(D[i])>h)*(1/D[i])*(XstrYi - XstrWi %*% delta_hat) / N
    }
  }
  beta_M_hat_denominator = mean((abs(D)>h))
  
  beta_M_hat = beta_M_hat_numerator * beta_M_hat_denominator^(-1)
  beta_L_hat = beta_M_hat_numerator + gamma_hat %*% h_hat
  
  ################################################################
  # ESTIMATE THETA
  ################################################################
  theta_L_hat = beta_L_hat + R%*%delta_hat
  theta_M_hat = beta_M_hat + R%*%delta_hat
  
  ################################################################
  # COMPUTE V_hat
  ################################################################
  V_hat = 0
  for( i in 1:N ){
    D0Li = matrix(unlist(D0L[i]),L+1,1)
    XstrWi = matrix(unlist(bfXstr[i]),T,p)%*%matrix(unlist(bfW[i]),T,(T-1)*p)
    V_hat = V_hat + as.numeric(t(D0Li)%*%ginv(END0LD0L)%*%e1) * t(XstrWi)%*%XstrWi / N
  }
  
  ################################################################
  # COMPUTE Q_hat
  ################################################################
  Q_hat = 0
  for( i in 1:N ){
    D1Li = matrix(unlist(D1L[i]),L,1)
    XstrWi = matrix(unlist(bfXstr[i]),T,p)%*%matrix(unlist(bfW[i]),T,(T-1)*p)
    if( abs(D[i])>h ){
      Q_hat = Q_hat + as.numeric( (abs(D[i])>h)/D[i] + t(D1Li)%*%ginv(END1LD1L)%*%h_hat ) * XstrWi / N
    }
  }
  
  ################################################################
  # COMPUTE zeta_hat (1ST TERM)
  ################################################################
  zeta_hat_1 = NULL
  for(i in 1:N){
    XstrWi = matrix(unlist(bfXstr[i]),T,p)%*%matrix(unlist(bfW[i]),T,(T-1)*p)
    XstrYi = matrix(unlist(bfXstr[i]),T,p)%*%matrix(unlist(bfY[i]),T,1)
    if( abs(D[i])>h ){
      zeta_hat_1 = cbind(zeta_hat_1, (abs(D[i])>h)/D[i] * (XstrYi - XstrWi%*%delta_hat))
    }else{
      zeta_hat_1 = cbind(zeta_hat_1, matrix(0,p,1) )
    }
  }
  zeta_hat_1 = zeta_hat_1 - matrix(rowMeans(zeta_hat_1),p,N)
  
  ################################################################
  # COMPUTE zeta_hat (2ND TERM)
  ################################################################
  zeta_hat_2 = NULL
  for(i in 1:N){
    D1Li = matrix(unlist(D1L[i]),L,1)
    XstrWi = matrix(unlist(bfXstr[i]),T,p)%*%matrix(unlist(bfW[i]),T,(T-1)*p)
    XstrYi = matrix(unlist(bfXstr[i]),T,p)%*%matrix(unlist(bfY[i]),T,1)
    zeta_hat_2 = cbind(zeta_hat_2, ((XstrYi-XstrWi%*%delta_hat) - gamma_hat%*%D1Li) %*% t(D1Li) %*% ginv(END1LD1L) %*% h_hat)
  }
  
  ################################################################
  # COMPUTE zeta_hat (3RD TERM)
  ################################################################
  zeta_hat_3R = NULL
  zeta_hat_3Q = NULL
  for(i in 1:N){
    D0Li = matrix(unlist(D0L[i]),L+1,1)
    XstrWi = matrix(unlist(bfXstr[i]),T,p)%*%matrix(unlist(bfW[i]),T,(T-1)*p)
    XstrYi = matrix(unlist(bfXstr[i]),T,p)%*%matrix(unlist(bfY[i]),T,1)
    zeta_hat_3R = cbind(zeta_hat_3R, as.numeric(t(D0Li)%*%ginv(END0LD0L)%*%e1) * R%*%ginv(V_hat)%*%t(XstrWi)%*%(XstrYi-XstrWi%*%delta_hat))
    zeta_hat_3Q = cbind(zeta_hat_3Q, as.numeric(t(D0Li)%*%ginv(END0LD0L)%*%e1) * Q_hat%*%ginv(V_hat)%*%t(XstrWi)%*%(XstrYi-XstrWi%*%delta_hat))
  }
  
  ################################################################
  # COMPUTE zeta_hat (ALL TOGETHER)
  ################################################################
  zeta_hat_M = zeta_hat_1 + zeta_hat_3R
  zeta_hat_L = zeta_hat_1 + zeta_hat_2 + zeta_hat_3R - zeta_hat_3Q
  rm(zeta_hat_1); rm(zeta_hat_2); rm(zeta_hat_3R); rm(zeta_hat_3Q); gc();
  
  ################################################################
  # VARIANCE AND SD
  ################################################################
  VAR_theta_M = zeta_hat_M %*% t(zeta_hat_M) / N
  VAR_theta_L = zeta_hat_L %*% t(zeta_hat_L) / N
  #rm(zeta_hat); 
  rm(zeta_hat_M); gc();
  SD_theta_M_hat = matrix(sqrt(diag(VAR_theta_M/N)),,1)
  SD_theta_L_hat = matrix(sqrt(diag(VAR_theta_L/N)),,1)
  
  
  ### report estimated unconditional cross-sectional means of coefficients without time effects
  ####### R = matrix(zeroes)
  sum_est = theta_M_hat # 2 by 1
  sum_av = VAR_theta_M / N # 2 by 2
  sum_cov = sum_av[1,2:k]
  if (k > 2) {
    for (j in 2:k) {
      sum_cov = append(sum_cov,sum_av[1,(2+j-1):k])
    }
  }
  sum_avar = matrix(,1,(k+k*(k-1)/2))
  sum_avar[1,1:k] = diag(sum_av)
  sum_avar[1,(k+1):(k+k*(k-1)/2)] = sum_cov
  
  np = mean(abs(D)<=h) # trimmed portion
  
  sum_an_output = as.matrix(cbind(np,t(sum_est),sum_avar))
  
  #######
  su_est = theta_L_hat # 2 by 1
  su_av = VAR_theta_L / N # 2 by 2
  su_cov = su_av[1,2:k]
  if (k > 2) {
    for (j in 2:(k-1)) {
      su_cov = append(su_cov,su_av[j,(j+1):k])
    }
  }
  su_avar = matrix(,1,(k+k*(k-1)/2))
  su_avar[1,1:k] = diag(su_av)
  su_avar[1,(k+1):(k+k*(k-1)/2)] = su_cov
  
  np = mean(abs(D)<=h) # trimmed portion
  
  su_an_output = as.matrix(cbind(np,t(su_est),su_avar))
  su_output = rbind(su_an_output)
  su_output
}

SU_est_l = function(paneldata,nobs,Tobs,k,L,te){
  t = 1 # only time effects in intercepts
  p = k # dim(w_it)
  N = nobs
  L = L # order of local polynomial regression
  T = Tobs
  
  #R = matrix(c(0,0,0,0),2,2)      # For t = 1 for Monte Carlo
  R = matrix(c(1/Tobs,0),2,1)  # only time effects in intercepts
  
  # input a panel data set
  ###########################################
  paneldata_x = matrix(paneldata[,2],2,nobs)
  paneldata_y = matrix(paneldata[,1],2,nobs) 
  
  X1 = matrix(paneldata_x[1,],nobs,1)
  X2 = matrix(paneldata_x[2,],nobs,1)
  Y1 = matrix(paneldata_y[1,],nobs,1)
  Y2 = matrix(paneldata_y[2,],nobs,1)
  ###########################################
  
  ################################################################
  # ADJOINT MATRIX FUNCTION
  ################################################################
  adjoint <- function(A){
    adjA = matrix(0,dim(A)[2],dim(A)[1])
    for( i in 1:(dim(A)[1]) ){
      for( j in 1:(dim(A)[2]) ){
        adjA[j,i] = (-1)^(i+j) * det(as.matrix(A[-i,-j]))
      }
    }
    return( adjA )
  }
  
  ################################################################
  # D, BOLD-FACE X, BOLD-FACE X*, BOLD-FACE X^{-1}, & BOLD-FACE W
  ################################################################
  i = 1
  D = det(rbind(cbind(1,X1[i,1]),cbind(1,X2[i,1])))  # det(Wi)
  bfX = list(rbind(cbind(1,X1[i,1]),cbind(1,X2[i,1])))
  bfXstr = list(adjoint(rbind(cbind(1,X1[i,1]),cbind(1,X2[i,1]))))
  bfXinv = list(ginv(rbind(cbind(1,X1[i,1]),cbind(1,X2[i,1]))))
  bfW = list(rbind(0,cbind(1))) #list(rbind(0,cbind(1,X2[i,1])))
  bfY = list(rbind(Y1[i,1],Y2[i,1]))
  for( i in 2:N ){
    D = c(D,det(rbind(cbind(1,X1[i,1]),cbind(1,X2[i,1]))))
    bfX[length(bfX)+1] = list(rbind(cbind(1,X1[i,1]),cbind(1,X2[i,1])))
    bfXstr[length(bfXstr)+1] = list(adjoint(rbind(cbind(1,X1[i,1]),cbind(1,X2[i,1]))))
    bfXinv[length(bfXinv)+1] = list(ginv(rbind(cbind(1,X1[i,1]),cbind(1,X2[i,1]))))
    bfW[length(bfW)+1] = list(rbind(0,cbind(1))) #list(rbind(0,cbind(1,X2[i,1])))
    bfY[length(bfY)+1] = list(rbind(Y1[i,1],Y2[i,1]))
  }
  
  ################################################################
  # h AND b (GRAHAM & POWELL, 2012, PAGE 2138)
  ################################################################
  h = min(c(sd(D), (quantile(D,0.75)-quantile(D,0.25))/1.34 )) / N^(1/(2*L+1)) / 2
  
  ################################################################
  # h_hat, e1, D0L, D1L
  ################################################################
  i = 1
  h_hat = (abs(D[i])<=h)*matrix(D[i]^(0:(L-1)),L,1) / N
  e1 = matrix(c(1, array(0,L)),L+1,1)
  D0L = list((abs(D[i])<=h)*matrix(D[i]^(0:L),L+1,1))
  D1L = list((abs(D[i])<=h)*matrix(D[i]^(1:L),L,1))
  for(i in 2:N){
    h_hat = h_hat + (abs(D[i])<=h)*matrix(D[i]^(0:(L-1)),L,1) / N
    D0L[length(D0L)+1] = list((abs(D[i])<=h)*matrix(D[i]^(0:L),L+1,1))
    D1L[length(D1L)+1] = list((abs(D[i])<=h)*matrix(D[i]^(1:L),L,1))
  }
  
  ################################################################
  # ESTIMATE DELTA ## time effects
  ################################################################
  END0LD0L = 0                                     # E_N[D0L D0L']
  for( i in 1:N ){
    D0Li = matrix(unlist(D0L[i]),L+1,1)
    END0LD0L = END0LD0L + D0Li%*%t(D0Li) / N
  }
  
  denominator = 0
  numerator = 0
  for( i in 1:N ){
    D0Li = matrix(unlist(D0L[i]),L+1,1)
    XstrWi = matrix(unlist(bfXstr[i]),T,p)%*%matrix(unlist(bfW[i]),T,(T-1)*1) #matrix(unlist(bfXstr[i]),T,p)%*%matrix(unlist(bfW[i]),T,(T-1)*p)
    XstrYi = matrix(unlist(bfXstr[i]),T,p)%*%matrix(unlist(bfY[i]),T,1)
    denominator = denominator + as.numeric(t(D0Li)%*%ginv(END0LD0L)%*%e1) * t(XstrWi) %*% XstrWi / N
    numerator   = numerator   + as.numeric(t(D0Li)%*%ginv(END0LD0L)%*%e1) * t(XstrWi) %*% XstrYi / N
  }
  delta_hat = ginv(denominator)%*%numerator
  
  ################################################################
  # ESTIMATE GAMMA
  ################################################################
  END1LD1L = 0                                     # E_N[D1L D1L']
  for( i in 1:N ){
    D1Li = matrix(unlist(D1L[i]),L,1)
    END1LD1L = END1LD1L + D1Li%*%t(D1Li) / N
  }
  
  gamma_hat = 0
  for( i in 1:N ){
    D1Li = matrix(unlist(D1L[i]),L,1)
    XstrWi = matrix(unlist(bfXstr[i]),T,p)%*%matrix(unlist(bfW[i]),T,(T-1)*1) #matrix(unlist(bfXstr[i]),T,p)%*%matrix(unlist(bfW[i]),T,(T-1)*p)
    XstrYi = matrix(unlist(bfXstr[i]),T,p)%*%matrix(unlist(bfY[i]),T,1)
    gamma_hat = gamma_hat + (XstrYi - XstrWi %*% delta_hat) %*% t(D1Li) / N
  }
  gamma_hat = gamma_hat %*% ginv(END1LD1L)
  
  ################################################################
  # ESTIMATE BETA^M & BETA_L
  ################################################################
  beta_M_hat_numerator = 0
  for( i in 1:N ){
    XstrWi = matrix(unlist(bfXstr[i]),T,p)%*%matrix(unlist(bfW[i]),T,(T-1)*1) #matrix(unlist(bfXstr[i]),T,p)%*%matrix(unlist(bfW[i]),T,(T-1)*p)
    XstrYi = matrix(unlist(bfXstr[i]),T,p)%*%matrix(unlist(bfY[i]),T,1)
    if( abs(D[i])>h ){
      beta_M_hat_numerator = beta_M_hat_numerator + (abs(D[i])>h)*(1/D[i])*(XstrYi - XstrWi %*% delta_hat) / N
    }
  }
  beta_M_hat_denominator = mean((abs(D)>h))
  
  beta_M_hat = beta_M_hat_numerator * beta_M_hat_denominator^(-1)
  beta_L_hat = beta_M_hat_numerator + gamma_hat %*% h_hat
  
  ################################################################
  # ESTIMATE THETA
  ################################################################
  theta_L_hat = beta_L_hat + R%*%delta_hat
  theta_M_hat = beta_M_hat + R%*%delta_hat
  
  ################################################################
  # COMPUTE V_hat
  ################################################################
  V_hat = 0
  for( i in 1:N ){
    D0Li = matrix(unlist(D0L[i]),L+1,1)
    XstrWi = matrix(unlist(bfXstr[i]),T,p)%*%matrix(unlist(bfW[i]),T,(T-1)*1) #matrix(unlist(bfXstr[i]),T,p)%*%matrix(unlist(bfW[i]),T,(T-1)*p)
    V_hat = V_hat + as.numeric(t(D0Li)%*%ginv(END0LD0L)%*%e1) * t(XstrWi)%*%XstrWi / N
  }
  
  ################################################################
  # COMPUTE Q_hat
  ################################################################
  Q_hat = 0
  for( i in 1:N ){
    D1Li = matrix(unlist(D1L[i]),L,1)
    XstrWi = matrix(unlist(bfXstr[i]),T,p)%*%matrix(unlist(bfW[i]),T,(T-1)*1) #matrix(unlist(bfXstr[i]),T,p)%*%matrix(unlist(bfW[i]),T,(T-1)*p)
    if( abs(D[i])>h ){
      Q_hat = Q_hat + as.numeric( (abs(D[i])>h)/D[i] + t(D1Li)%*%ginv(END1LD1L)%*%h_hat ) * XstrWi / N
    }
  }
  
  ################################################################
  # COMPUTE zeta_hat (1ST TERM)
  ################################################################
  zeta_hat_1 = NULL
  for(i in 1:N){
    XstrWi = matrix(unlist(bfXstr[i]),T,p)%*%matrix(unlist(bfW[i]),T,(T-1)*1) #matrix(unlist(bfXstr[i]),T,p)%*%matrix(unlist(bfW[i]),T,(T-1)*p)
    XstrYi = matrix(unlist(bfXstr[i]),T,p)%*%matrix(unlist(bfY[i]),T,1)
    if( abs(D[i])>h ){
      zeta_hat_1 = cbind(zeta_hat_1, (abs(D[i])>h)/D[i] * (XstrYi - XstrWi%*%delta_hat))
    }else{
      zeta_hat_1 = cbind(zeta_hat_1, matrix(0,p,1) )
    }
  }
  zeta_hat_1 = zeta_hat_1 - matrix(rowMeans(zeta_hat_1),p,N)
  
  ################################################################
  # COMPUTE zeta_hat (2ND TERM)
  ################################################################
  zeta_hat_2 = NULL
  for(i in 1:N){
    D1Li = matrix(unlist(D1L[i]),L,1)
    XstrWi = matrix(unlist(bfXstr[i]),T,p)%*%matrix(unlist(bfW[i]),T,(T-1)*1) #matrix(unlist(bfXstr[i]),T,p)%*%matrix(unlist(bfW[i]),T,(T-1)*p)
    XstrYi = matrix(unlist(bfXstr[i]),T,p)%*%matrix(unlist(bfY[i]),T,1)
    zeta_hat_2 = cbind(zeta_hat_2, ((XstrYi-XstrWi%*%delta_hat) - gamma_hat%*%D1Li) %*% t(D1Li) %*% ginv(END1LD1L) %*% h_hat)
  }
  
  ################################################################
  # COMPUTE zeta_hat (3RD TERM)
  ################################################################
  zeta_hat_3R = NULL
  zeta_hat_3Q = NULL
  for(i in 1:N){
    D0Li = matrix(unlist(D0L[i]),L+1,1)
    XstrWi = matrix(unlist(bfXstr[i]),T,p)%*%matrix(unlist(bfW[i]),T,(T-1)*1) #matrix(unlist(bfXstr[i]),T,p)%*%matrix(unlist(bfW[i]),T,(T-1)*p)
    XstrYi = matrix(unlist(bfXstr[i]),T,p)%*%matrix(unlist(bfY[i]),T,1)
    zeta_hat_3R = cbind(zeta_hat_3R, as.numeric(t(D0Li)%*%ginv(END0LD0L)%*%e1) * R%*%ginv(V_hat)%*%t(XstrWi)%*%(XstrYi-XstrWi%*%delta_hat))
    zeta_hat_3Q = cbind(zeta_hat_3Q, as.numeric(t(D0Li)%*%ginv(END0LD0L)%*%e1) * Q_hat%*%ginv(V_hat)%*%t(XstrWi)%*%(XstrYi-XstrWi%*%delta_hat))
  }
  
  ################################################################
  # COMPUTE zeta_hat (ALL TOGETHER)
  ################################################################
  zeta_hat_M = zeta_hat_1 + zeta_hat_3R
  zeta_hat_L = zeta_hat_1 + zeta_hat_2 + zeta_hat_3R - zeta_hat_3Q
  rm(zeta_hat_1); rm(zeta_hat_2); rm(zeta_hat_3R); rm(zeta_hat_3Q); #gc();
  
  ################################################################
  # VARIANCE AND SD
  ################################################################
  VAR_theta_M = zeta_hat_M %*% t(zeta_hat_M) / N
  VAR_theta_L = zeta_hat_L %*% t(zeta_hat_L) / N
  rm(zeta_hat_M); #gc(); #rm(zeta_hat);
  SD_theta_M_hat = matrix(sqrt(diag(VAR_theta_M/N)),,1)
  SD_theta_L_hat = matrix(sqrt(diag(VAR_theta_L/N)),,1)
  
  ################################################################
  ## report SU (2021) estimation results
  ################################################################
  su_est = theta_L_hat # 2 by 1
  su_av = VAR_theta_L / N # 2 by 2
  su_cov = su_av[1,2:k]
  if (k > 2) {
    for (j in 2:(k-1)) {
      su_cov = append(su_cov,su_av[j,(j+1):k])
    }
  }
  su_avar = matrix(,1,(k+k*(k-1)/2))
  su_avar[1,1:k] = diag(su_av)
  su_avar[1,(k+1):(k+k*(k-1)/2)] = su_cov
  
  np = mean(abs(D)<=h) # trimmed portion
  
  vte1 = -1/Tobs+rbind(matrix(0,1,Tobs-1),diag(1,Tobs-1)) # T by (T-1) phi* to phi
  phi_hat = vte1 %*% delta_hat
  
  su_an_output = as.matrix(cbind(np,t(su_est),su_avar,t(phi_hat)))
  su_output = su_an_output 
  su_output
}

SU_est = function(paneldata,nobs,Tobs,k,l_list,te){
  ll = length(l_list)
  dimte = 0*(te==0)+ 1*(te==1) + (Tobs-1)*k*(te==((Tobs-1)*k))
  ptheta = (1+k+(k+k*(k-1)/2))
  dimte = Tobs
  # with no time effects
  if (te==0) {
    su_list = sapply(l_list,SUN_est_l,paneldata=paneldata,nobs=nobs,Tobs=Tobs,k=k)
    su_np = matrix(su_list[1,],ll,1) # np: 1
    su_ests = matrix(su_list[2:(k+1),],k*ll,1)  # ests: k 
    su_avar = matrix(su_list[(k+2):(1+k+(k+k*(k-1)/2)),],(k+k*(k-1)/2)*ll,1)  # avar (k+corr): k + k*(k-1)/2
    su_output = list(su_np,su_ests,su_avar)
    names(su_output) = c("np","ests","avar")
  }
  # with time effects: ## order of local polynomial regressor associated with rate of convergence
  if (te>0) {
    su_list =sapply(l_list,SU_est_l,paneldata=paneldata,nobs=nobs,Tobs=Tobs,k=k,te=te)
    su_np = matrix(su_list[1,],ll,1) # np: 1
    su_ests = matrix(su_list[2:(k+1),],k*ll,1)  # ests: k 
    su_avar = matrix(su_list[(k+2):ptheta,],(k+k*(k-1)/2)*ll,1)# avar (k+corr): k + k*(k-1)/2
    phite_ests = matrix(su_list[(1+ptheta):(dimte+ptheta),],dimte*ll,1) # ests of time effects
    su_output = list(su_np,su_ests,su_avar,phite_ests)
    names(su_output) = c("np","ests","avar","te")
  }
  su_output 
}
###### Fin: 5. SU and SUM estimators 



################################################################################
###  Trimmed Mean Group Estimator: TMG, TMG-TE and TMG-C 
### (Minor, Cofactor, Adjoint1, Det_i, TOLS_i, Qw_i, MTxy_i, MTuu_i, Phiuu_i)
### (TMG_an, TMG_TE_an, TMG_est)
################################################################################
Minor = function(A, i, j) {
  det(as.matrix(A[-i,-j]) )
}

Cofactor = function(A, i, j) {
  (-1)^(i+j) * Minor(A,i,j)
}

Adjoint1 = function(A) {
  n = nrow(A)
  B = matrix(, n, n)
  for( i in 1:n )
    for( j in 1:n )
      B[j,i] = Cofactor(A, i, j)
  B
}

Det_i = function(paneldata_w,nobs,Tobs,k,id) {
  wi = matrix(paneldata_w[(1+(id-1)*Tobs):(id*Tobs),],Tobs,k)  # (T by k)
  deti = det(t(wi) %*% wi) # scalar where t(wi) %*% wi is a (k by k) matrix
  deti
}

TOLS_i = function(panel_int,nobs,Tobs,k,an,id){
  obsi = as.matrix(panel_int[(1+(id-1)*Tobs):(id*Tobs),]) # paneldata = {(yi,wi)} (nT by k+1) matrix including intercepts
  yi = as.matrix(obsi[,1]) # yi (T by 1)
  wi = as.matrix(obsi[,2:(k+1)]) # regressor wi (T by k) with wit = (1,xit')'
  di = det(t(wi) %*% wi) # determinant
  if (di > an) {
    theta_i = solve(t(wi) %*% wi) %*% (t(wi) %*% yi) # (k by 1) individual OLS estimator
  } else {
    theta_i = an^(-1) * Adjoint1(t(wi) %*% wi) %*% (t(wi) %*% yi) # (k by 1) individual trimmed estimator
  }
  theta_i # eq. (4.2)
}

Qw_i = function(paneldata_w,nobs,Tobs,k,an,id){
  wi = matrix(paneldata_w[(1+(id-1)*Tobs):(id*Tobs),],Tobs,k)  # (T by k)
  di = det(t(wi) %*% wi) # determinant
  if (di > an) {
    qw_i = wi %*% solve(t(wi) %*% wi)  # (T by k)
  } else {
    qw_i = an^(-1)* wi %*% Adjoint1(t(wi) %*% wi)  # (T by k)
  }
  qw_i # eq. (6.3)
}

# calculate numerator and denominator phi_c
MTxy_i = function(paneldata,nobs,Tobs,k,id) {
  yi = matrix(paneldata[(1+(id-1)*Tobs):(id*Tobs),1],Tobs,1)
  xi = matrix(paneldata[(1+(id-1)*Tobs):(id*Tobs),2:k],Tobs,k-1) # (T by k-1)
  taut = matrix(1,Tobs,1) 
  mt = diag(1,Tobs)-taut %*% solve(t(taut)%*%taut) %*% t(taut) # (T by T)
  mtxi = mt %*% xi
  mti = diag(1,Tobs)- mtxi %*% solve(t(mtxi) %*% mtxi) %*% t(mtxi) # (T by T)
  mtyi = mti %*% mt %*% yi # (T by 1)
  mtxyi = cbind(mti,mtyi) # T by (T+1) 
  mtxyi # components in (6.18)
}

# calculate part of the variance of phi_c
MTuu_i = function(paneldata,nobs,Tobs,k,phi_c,id) {
  yi = matrix(paneldata[(1+(id-1)*Tobs):(id*Tobs),1],Tobs,1)
  xi = matrix(paneldata[(1+(id-1)*Tobs):(id*Tobs),2:k],Tobs,k-1) # (T by k-1)
  taut = matrix(1,Tobs,1) 
  mt = diag(1,Tobs)-taut %*% solve(t(taut)%*%taut) %*% t(taut) # (T by T)
  mtxi = mt %*% xi
  mti = diag(1,Tobs)- mtxi %*% solve(t(mtxi)%*% mtxi) %*% t(mtxi) # (T by T)
  ydtei = matrix(yi - phi_c,Tobs,1)
  mtuui = mti %*% mt %*% ydtei %*% t(ydtei) %*% t(mti %*% mt) # component in (6.20)
  mtuui
}

# calculate part of the variance of phi_hat
Phiuu_i = function(paneldata,nobs,Tobs,k,est,id) {
  yi = matrix(paneldata[(1+(id-1)*Tobs):(id*Tobs),1],Tobs,1)
  xi = matrix(paneldata[(1+(id-1)*Tobs):(id*Tobs),2:k],Tobs,k-1) # (T by k-1)
  phi_hat = as.matrix(est[1:Tobs]) # (T by 1)
  beta_hat = as.matrix(est[(Tobs+2):(Tobs+k)]) # (k-1) by 1
  ui = yi - xi %*% beta_hat - phi_hat
  uui = ui %*% t(ui) # eq. (A.3.6)
  uui # (T by T)
}

### conditional on a threshold tau, calculate TMG(an) estimator
TMG_an = function(paneldata,nobs,Tobs,k,arate){
  #### Import data of a balanced panel
  ######################################################
  nT = nobs*Tobs
  id_list = as.matrix(seq(1,nobs,by=1))
  int_nT_long = matrix(1,nobs*Tobs,1)
  paneldata_w = cbind(int_nT_long,paneldata[,2:k])
  panel_int = cbind(paneldata[,1],paneldata_w) # add intercepts
  y = as.matrix(panel_int[,1]) # (nT by 1)
  w = as.matrix(panel_int [,2:(1+k)]) # (nT by k) regressors include intercepts
  x = as.matrix(panel_int[,3:(1+k)]) # (nT by k-1)
  ######################################################
  
  ## TMG (1) calculate di=det(Wi'Wi) and the threshold an = mean(di)*(n^(-arate))
  det_n = sapply(id_list,Det_i,paneldata_w=w,nobs=nobs,Tobs=Tobs,k=k) 
  det_bn = mean(det_n) # the sample mean of di=det(Wi'Wi)
  arate=1/3 # power of n in the threshold
  an = det_bn*(nobs^(-arate)) # the threshold
  
  ## TMG (2) calculate the trimming index
  trim_n = (det_n<=an)
  np = mean(trim_n)
  
  ## TMG (3) calculate trimmed individual estimates
  theta_trim_n = sapply(id_list,TOLS_i,panel_int=panel_int,nobs=nobs,Tobs=Tobs,k=k,an=an) # (k by n) eq. (4.2)
  tmgh_hat = matrix(rowMeans(theta_trim_n),k,1) # (k by 1) average over n eq. (4.4)
  
  ## TMG (4) calculate bias-corrected TMG estimator 
  delta_n = (det_n/an-1)*trim_n # (n by 1) eq. (4.3)
  delta_bn = mean(delta_n)
  tmg_hat = (1+delta_bn)^(-1)*tmgh_hat # (k by 1) eq. (4.5)
  
  ## TMG (5) calculate asymptotic variance of TMG estimator 
  tmg_bm = matrix(tmg_hat, k ,nobs)
  tmg_av =(1+delta_bn)^(-2)*(nobs*(nobs-1))^(-1)*(theta_trim_n-tmg_bm) %*% t(theta_trim_n-tmg_bm) # (k by k) eq. (5.21)
  
  ## Report the covariance matrix of TMG estimator
  tmg_cov = tmg_av[1,2:k]
  if (k > 2) {
    for (j in 2:(k-1)) {
      tmg_cov = append(tmg_cov,tmg_av[j,(j+1):k])
    }
  }
  tmg_avar = matrix(,1,(k+k*(k-1)/2))
  tmg_avar[1,1:k] = diag(tmg_av)
  tmg_avar[1,(k+1):(k+k*(k-1)/2)] = tmg_cov
  
  # TMG: np,ests,avar
  tmg_an_output = as.matrix(cbind(np,t(tmg_hat),tmg_avar)) # 1+k+(k+k*(k-1)/2))
  tmg_an_output
}

TMG_TE_C_an = function(paneldata,nobs,Tobs,k,arate){
  id_list = as.matrix(seq(1,nobs,by=1))
  int_nT_long = matrix(1,nobs*Tobs,1)
  panel_int = cbind(paneldata[,1],cbind(int_nT_long,paneldata[,2:k])) # add intercepts
  y = as.matrix(panel_int[,1]) # (nT by 1)
  w = as.matrix(panel_int [,2:(1+k)]) # (nT by k) regressors include intercepts
  x = as.matrix(panel_int[,3:(1+k)]) # (nT by k-1)
  
  ## calculate TMG estimator
  #################################################################
  ## TMG (1) calculate di=det(Wi'Wi) and the threshold an = mean(di)*(n^(-arate))
  det_n = sapply(id_list,Det_i,paneldata_w=w,nobs=nobs,Tobs=Tobs,k=k) 
  det_bn = mean(det_n) # the sample mean of di=det(Wi'Wi)
  an = det_bn*(nobs^(-arate)) # the threshold
  
  ## TMG (2) calculate the trimming index
  trim_n = (det_n<=an)
  np = mean(trim_n)
  
  ## TMG (3) calculate trimmed individual estimates
  theta_trim_n = sapply(id_list,TOLS_i,panel_int=panel_int,nobs=nobs,Tobs=Tobs,k=k,an=an) # (k by n)
  tmgh_hat = matrix(rowMeans(theta_trim_n),k,1) # (k by 1) average over n
  
  ## TMG (4) calculate bias-corrected TMG estimator 
  delta_n = (det_n/an-1)*trim_n # (n by 1)
  delta_bn = mean(delta_n)
  tmg_hat = (1+delta_bn)^(-1)*tmgh_hat # (k by 1) eq. (4.5)
  #################################################################
  
  ## calculate TMG-TE estimator under tau'phi=0
  #################################################################
  w_n = matrix(t(w),k*Tobs,nobs) # (Tk by n)
  w_bn = t(matrix(rowMeans(w_n),k,Tobs)) # (T by k) average over n
  y_n = matrix(y,Tobs,nobs) # (T by n)
  y_bn = matrix(rowMeans(y_n),Tobs,1) # (T by 1) {y_it} average over n for each t
  
  taut = matrix(1,Tobs,1) 
  mt = diag(1,Tobs)-taut %*% solve(t(taut)%*%taut) %*% t(taut) # (T by T)
  
  qw_n = sapply(id_list,Qw_i,paneldata_w=w,nobs=nobs,Tobs=Tobs,k=k,an=an) # Tk by n eq. (6.3)
  qw_bn = (1+delta_bn)^(-1)*matrix(rowMeans(qw_n),Tobs,k) # (T by k) eq. (6.4)
  
  ## TMG-TE (1) calculate estimator phi_hat and theta_hat
  phi_hat = solve(diag(1,Tobs)-mt%*%w_bn%*%t(qw_bn)) %*% mt %*% (y_bn-w_bn%*%tmg_hat) # eq. (6.11)
  theta_hat = tmg_hat - t(qw_bn)%*%phi_hat # eq. (6.9)
  
  ## TMG-TE (2) calculate asymptotic variance of theta_hat
  phie_nT = matrix(matrix(phi_hat,Tobs,nobs),Tobs*nobs,1)
  ydte_nT = y - phie_nT # (nT by 1) 
  panel_dte = cbind(ydte_nT,w)  
  theta_te_n = sapply(id_list,TOLS_i,panel_int=panel_dte,nobs=nobs,Tobs=Tobs,k=k,an=an) # (k by n)
  theta_bm = matrix(theta_hat,k,nobs)
  theta_av0 = (1+delta_bn)^(-2)*(nobs*(nobs-1))^(-1)*(theta_te_n-theta_bm) %*% t(theta_te_n-theta_bm) # (k by k) eq. (A.3.5)
  theta_av = solve(diag(1,k)-t(qw_bn)%*%mt%*%w_bn)%*%theta_av0%*%t(solve(diag(1,k)-t(qw_bn)%*%mt%*% w_bn)) # eq. (A.3.4)
  
  ## TMG-TE asymptotic variance of time effects phi
  tmgte_hat = as.matrix(c(phi_hat,theta_hat)) # (T+k) by 1: phi_hat, theta_hat 
  phiuu_n = sapply(id_list,Phiuu_i,paneldata=paneldata,nobs=nobs,Tobs=Tobs,k=k,est=tmgte_hat)
  phiuu_bn = matrix(rowMeans(phiuu_n),Tobs,Tobs)
  phi_av0 = nobs^(-1)*phiuu_bn
  phi_av = mt %*% ( w_bn %*% theta_av %*% t(w_bn) + phi_av0 ) %*% mt
  
  ## Report the estimated asymptotic variance of TMG-TE
  #################################################################
  theta_cov = theta_av[1,2:k]
  if (k > 2) {
    for (j in 2:(k-1)) {
      theta_cov = append(theta_cov,theta_av[j,(j+1):k])
    }
  }
  theta_avar = matrix(,1,(k+k*(k-1)/2))
  theta_avar[1,1:k] = diag(theta_av)
  theta_avar[1,(k+1):(k+k*(k-1)/2)] = theta_cov
  
  phi_avar = diag(phi_av)
  #################################################################
  
  ## calculate TMG-C estimator under tau'phi=0
  if (Tobs>k) {
    mtxy_n = sapply(id_list,MTxy_i,paneldata=paneldata,nobs=nobs,Tobs=Tobs,k=k)
    mtx_bn = matrix(rowMeans(mtxy_n[1:(Tobs*Tobs),]),Tobs,Tobs)
    mty_bn = matrix(rowMeans(mtxy_n[(Tobs*Tobs+1):(Tobs*(Tobs+1)),]),Tobs,1)
    phi_c = solve(mtx_bn) %*% mty_bn # eq. (6.18)
    
    mtuu_n = sapply(id_list,MTuu_i,paneldata=paneldata,nobs=nobs,Tobs=Tobs,k=k,phi_c=phi_c)
    mtuu_bn = matrix(rowMeans(mtuu_n),Tobs,Tobs)
    phic_av = nobs^(-1)*solve(mtx_bn) %*% mtuu_bn %*% t(solve(mtx_bn)) # eq. (6.19)
    
    phic_nT = matrix(matrix(phi_c,Tobs,nobs),Tobs*nobs,1)
    ydtc_nT = y - phic_nT # (nT by 1) vector of yit-phit_hat eq. (6.21)
    panel_dtc = cbind(ydtc_nT,w) 
    
    thetac_n = sapply(id_list,TOLS_i,panel_int=panel_dtc,nobs=nobs,Tobs=Tobs,k=k,an=an) # (k by n)
    thetac_hat = (1+delta_bn)^(-1)*matrix(rowMeans(thetac_n),k,1) # eq. (6.21)
    
    ## TMG-C asymptotic variance of E(theta_i)
    thetac_bm = matrix(thetac_hat,k,nobs)
    thetac_av0 = (1+delta_bn)^(-2)*(nobs*(nobs-1))^(-1)*(thetac_n-thetac_bm) %*% t(thetac_n-thetac_bm) # (k by k) first component in eq. (6.22)
    thetac_av1 = t(qw_bn) %*% phic_av %*% qw_bn # (k by k) second component in eq. (6.22)
    thetac_av = thetac_av0 + thetac_av1 # eq. (6.22)
    
    thetac_cov = thetac_av[1,2:k]
    if (k > 2) {
      for (j in 2:(k-1)) {
        thetac_cov = append(thetac_cov,thetac_av[j,(j+1):k])
      }
    }
    thetac_avar = matrix(,1,(k+k*(k-1)/2))
    thetac_avar[1,1:k] = diag(thetac_av)
    thetac_avar[1,(k+1):(k+k*(k-1)/2)] = thetac_cov
    
    phic_avar = diag(phic_av)
  }
  
  # report TMG estimator with time effects
  #################################################################
  if (Tobs==k) {
    tmgte_an_output = as.matrix(c(np,t(theta_hat),theta_avar,t(phi_hat),t(phi_avar))) # 1+k+(k+k*(k-1)/2))+ T+(T+T*(T-1)/2)
  }
  if (Tobs>k) {
    tmgte_output = as.matrix(c(np,t(theta_hat),theta_avar,t(phi_hat),t(phi_avar))) # 1+k+(k+k*(k-1)/2))+ T+(T+T*(T-1)/2)
    tmgc_output = as.matrix(c(np,t(thetac_hat),thetac_avar,t(phi_c),t(phic_avar))) # 1+k+(k+k*(k-1)/2))+ T+(T+T*(T-1)/2)
    tmgte_an_output = cbind(tmgte_output, tmgc_output)
  }
  #################################################################
  tmgte_an_output
}

TMG_est_mc = function(paneldata,nobs,Tobs,k,a_list,te){
  ## alpha associated with rate of convergence
  a_list  = as.matrix(a_list)
  al = dim(a_list)[1]
  ptheta = (1+k+(k+k*(k-1)/2))
  dimte = Tobs
  pte = 2*Tobs
  p = ptheta+pte
  
  if (te==0) {
    tmg_list = as.matrix(sapply(a_list,TMG_an,paneldata=paneldata,nobs=nobs,Tobs=Tobs,k=k))
    tmg_np = matrix(tmg_list[1,],al,1) # np: 1
    tmg_ests = matrix(tmg_list[2:(k+1),],k*al,1)  # ests: k 
    tmg_avar = matrix(tmg_list[(k+2):ptheta,],(k+k*(k-1)/2)*al,1)  # avar (k+corr): k + k*(k-1)/2
    tmg_output = list(tmg_np,tmg_ests,tmg_avar)
    names(tmg_output) = c("np","ests","avar")
  }
  if (te>0) {
    tmg_list = as.matrix(sapply(a_list,TMG_TE_C_an,paneldata=paneldata,nobs=nobs,Tobs=Tobs,k=k))
    tmgte_list = as.matrix(tmg_list[1:p,])
    
    tmgte_np = matrix(tmgte_list[1,],al,1) # np: 1
    tmgte_ests = matrix(tmgte_list[2:(k+1),],k*al,1)  # ests: k 
    tmgte_avar = matrix(tmgte_list[(k+2):ptheta,],(k+k*(k-1)/2)*al,1)  # avar: k+k*(k-1)/2
    phite_ests = matrix(tmgte_list[(1+ptheta):(dimte+ptheta),],dimte*al,1) # ests of time effects
    phite_avar = matrix(tmgte_list[(dimte+ptheta+1):(ptheta+pte),],(pte-dimte)*al,1) # avar of time effects
    
    tmgte_output = list(tmgte_np,tmgte_ests,tmgte_avar,phite_ests,phite_avar)
    names(tmgte_output) = c("np","ests","avar","tests","tavar")
    tmg_output = list(tmgte_output)
    names(tmg_output) = c("tmgte")
    
    if (Tobs>k) {
      tmgc_list = as.matrix(tmg_list[(p+1):(2*p),])
      tmgc_np = matrix(tmgc_list[1,],al,1) # np: 1
      tmgc_ests = matrix(tmgc_list[2:(k+1),],k*al,1)  # ests: k 
      tmgc_avar = matrix(tmgc_list[(k+2):ptheta,],(k+k*(k-1)/2)*al,1)  # avar: k+k*(k-1)/2
      phic_ests = matrix(tmgc_list[(1+ptheta):(dimte+ptheta),],dimte*al,1) # ests of time effects
      phic_avar = matrix(tmgc_list[(dimte+ptheta+1):(ptheta+pte),],(pte-dimte)*al,1) # avar of time effects
      
      tmgc_output = list(tmgc_np,tmgc_ests,tmgc_avar,phic_ests,phic_avar)
      names(tmgc_output) = c("np","ests","avar","tests","tavar")
      tmg_output = list(tmgte_output,tmgc_output)
      names(tmg_output) = c("tmgte","tmgc")
    } 
  } 
  tmg_output 
}


################################################################################
### Define Functions of Monte Carlo Replications (MCS_rep)
################################################################################
MCS_rep = function(rep,nobs,Tobs,k,m_y,gauss_y,m_x,hetero_x,dist_x,ar_x,te_x,corr_e,para_case,kappa2,bal_panel,phi_te,a_list,l_ist,te,fee,mge,gpe,sue,tmge) {
  # 7 statistics: np, est, avar, bias, rmse, cvr, size
  ne = 5+2*length(a_list) # number of estimates: FE(1), MG(2), GP(1), SU(1), TMG(2) 
  np_rep = matrix(,k*ne,rep)
  est_rep = matrix(,k*ne,rep)
  avar_rep = matrix(,k*ne,rep)
  acov_rep = matrix(,((k*(k-1)/2)*ne),rep)
  
  bias_rep = matrix(,k*ne,1)
  rmse_rep = matrix(,k*ne,1)
  cvr_rep = matrix(,k*ne,1)
  size_rep = matrix(,k*ne,1)
  pw_rep = matrix(,pwgrid,k*ne)
  stat_rep = matrix(,k*ne,7) 
  
  dimte = Tobs # dimension of time effects
  te_rep = matrix(,dimte*ne,rep) # time effects
  tavar_rep = matrix(,dimte*ne,rep) # time effects
  
  tbias_rep = matrix(,dimte*ne,1)
  trmse_rep = matrix(,dimte*ne,1)
  tcvr_rep = matrix(,dimte*ne,1)
  tsize_rep = matrix(,dimte*ne,1)
  tpw_rep = matrix(,pwgrid,dimte*ne)
  statte_rep = matrix(,dimte*ne,7) 
  
  #fee=1;mge=1;atmge=1;gpe=1;sue=1;tmge=1
  for (s in 1:rep) {
    ################################################
    if (bal_panel==1) {
      paneldata_idt = Gen_balpanel(nobs,Tobs,k,m_y,gauss_y,m_x,hetero_x,dist_x,ar_x,te_x,corr_e,para_case,kappa2,phi_te,idt)
      paneldata = paneldata_idt[,3:(3+k-1)]
      
      # estimators: FE, MG, ATMG, GP, SU, TMG
      if (fee==1) {
        if (te==0) {
          em = "FE"
          temp_fe = FE_est(paneldata,nobs,Tobs,k) # 1 estimate
        }
        if (te>0) {
          em = "FE-TE"
          temp_fe = FE_TE_est(paneldata,nobs,Tobs,k) # 1 estimate
        }
      }
      if (mge==1) {
        em = "MG"
        if (te==0) {
          temp_mg = MG_est(paneldata,nobs,Tobs,k)
        }
        if (te>0) {
          temp_mg = MG_TE_est(paneldata,nobs,Tobs,k)
          temp_mgte = temp_mg$mgte
          if (Tobs>k) {
            temp_mgc = temp_mg$mgc
          }
        }
      }
      if (gpe==1) {
        em = "GP"
        temp_gp = GP_est(paneldata,nobs,Tobs,k,te)
      }
      if (sue==1) {
        em = "SU"
        temp_su = SU_est(paneldata,nobs,Tobs,k,l_list,te)
      }
      if (tmge==1) {
        if (te==0) {
          em = "TMG"
          temp_tmg = TMG_est_mc(paneldata,nobs,Tobs,k,a_list,te)
        }
        if (te>0) {
          em = "TMG-TE"
          temp_tmg = TMG_est_mc(paneldata,nobs,Tobs,k,a_list,te)
          temp_tmgte = temp_tmg$tmgte
          if (Tobs>k) {
            temp_tmgc = temp_tmg$tmgc
          }
        }
      }
    }
    ################################################
    
    # store one replication result: FE(1), MG(2), ATMG(1), GP(1), SU(2), TMG(5) 
    ###########################################################
    #ne = 1+1+2+1+dim(l_list)[1]+dim(a_list)[1]
    k2 = (k*(k-1)/2)
    if (fee==1) {
      np_rep[1:k,s] = 0
      est_rep[1:k,s] = temp_fe$ests
      avar_rep[1:k,s] = temp_fe$avar[1:k]
      acov_rep[1:k2,s] = temp_fe$avar[(k+1):(k+k2)] 
    }
    if (mge==1) {
      if (te==0) {
        np_rep[(k+1):(k+k),s] = temp_mg$np
        est_rep[(k+1):(k+k),s] = temp_mg$ests
        avar_rep[(k+1):(k+k),s] = temp_mg$avar[1:k]
        acov_rep[(k2+1):(k2+k2),s] = temp_mg$avar[(k+1):(k+(k*(k-1)/2))]
      }
      if (te>0) {
        np_rep[(k+1):(k+k),s] = temp_mgte$np
        est_rep[(k+1):(k+k),s] = temp_mgte$ests
        avar_rep[(k+1):(k+k),s] = temp_mgte$avar[1:k]
        acov_rep[(k2+1):(k2+k2),s] = temp_mgte$avar[(k+1):(k+(k*(k-1)/2))]
        te_rep[(1*dimte+1):(1*dimte+dimte),s] = temp_mgte$te
        tavar_rep[(1*dimte+1):(1*dimte+dimte),s] = temp_mgte$tavar[1:dimte]
        if (Tobs>k) {
          np_rep[(2*k+1):(2*k+k),s] = temp_mgc$np
          est_rep[(2*k+1):(2*k+k),s] = temp_mgc$ests
          avar_rep[(2*k+1):(2*k+k),s] = temp_mgc$avar[1:k]
          acov_rep[(2*k2+1):(2*k2+k2),s] = temp_mgc$avar[(k+1):(k+(k*(k-1)/2))]
          te_rep[(2*dimte+1):(2*dimte+dimte),s] = temp_mgc$te
          tavar_rep[(2*dimte+1):(2*dimte+dimte),s] = temp_mgc$tavar[1:dimte]
        }
      }
    }
    if (gpe==1) {
      np_rep[(3*k+1):(3*k+k),s] = temp_gp$np 
      est_rep[(3*k+1):(3*k+k),s] = temp_gp$ests
      avar_rep[(3*k+1):(3*k+k),s] = temp_gp$avar[1:k]
      acov_rep[(3*k2+1):(3*k2+k2),s] = temp_gp$avar[(k+1):(k+(k*(k-1)/2))]
      if (te>0) {
        te_rep[(3*dimte+1):(3*dimte+dimte),s] = temp_gp$te
        tavar_rep[(3*dimte+1):(3*dimte+dimte),s] = temp_gp$tavar[1:dimte]
      }
    }
    if (sue==1) {
      nee = dim(l_list)[1] # L = 1,2
      i = 1 # multiple estimators with different order of local polynomial regressions
      for (i in 1:nee) {
        np_rep[(4*k+1+k*(i-1)):(4*k+k+k*(i-1)),s] = temp_su$np[i] 
        est_rep[(4*k+1+k*(i-1)):(4*k+k+k*(i-1)),s] = temp_su$ests[(1+k*(i-1)):(k+k*(i-1))]
        avar_rep[(4*k+1+k*(i-1)):(4*k+k+k*(i-1)),s] = temp_su$avar[(1+(k+(k*(k-1)/2))*(i-1)):(k+(k+(k*(k-1)/2))*(i-1))]
        acov_rep[(4*k2+1+k2*(i-1)):(4*k2+k2*(i-1)),s] = temp_su$avar[(k+1+(k+(k*(k-1)/2))*(i-1)):(k+(k*(k-1)/2)+(k+(k*(k-1)/2))*(i-1))]
        if (te>0) {
          te_rep[(4*dimte+1+dimte*(i-1)):(4*dimte+dimte+dimte*(i-1)),s] = temp_su$te[(1+dimte*(i-1)):(dimte+dimte*(i-1))]
        }
      }
    } 
    if (tmge==1) {
      nee = dim(a_list)[1] # multiple estimators with different thresholds
      if (te==0) {
        i = 1
        for (i in 1:nee) {
          np_rep[(5*k+1+k*(i-1)):(5*k+k+k*(i-1)),s] = temp_tmg$np[i] 
          est_rep[(5*k+1+k*(i-1)):(5*k+k+k*(i-1)),s] = temp_tmg$ests[(1+k*(i-1)):(k+k*(i-1))]
          avar_rep[(5*k+1+k*(i-1)):(5*k+k+k*(i-1)),s] = temp_tmg$avar[(1+(k+(k*(k-1)/2))*(i-1)):(k+(k+(k*(k-1)/2))*(i-1))]
          acov_rep[(5*k2+1+k2*(i-1)):(5*k2+k2*(i-1)),s] = temp_tmg$avar[(k+1+(k+(k*(k-1)/2))*(i-1)):(k+(k*(k-1)/2)+(k+(k*(k-1)/2))*(i-1))]
        }
      }
      if (te>0) {
        i = 1
        for (i in 1:nee) {
          np_rep[(5*k+1+k*(i-1)):(5*k+k+k*(i-1)),s] = temp_tmgte$np[i] 
          est_rep[(5*k+1+k*(i-1)):(5*k+k+k*(i-1)),s] = temp_tmgte$ests[(1+k*(i-1)):(k+k*(i-1))]
          avar_rep[(5*k+1+k*(i-1)):(5*k+k+k*(i-1)),s] = temp_tmgte$avar[(1+(k+(k*(k-1)/2))*(i-1)):(k+(k+(k*(k-1)/2))*(i-1))]
          acov_rep[(5*k2+1+k2*(i-1)):(5*k2+k2*(i-1)),s] = temp_tmgte$avar[(k+1+(k+(k*(k-1)/2))*(i-1)):(k+(k*(k-1)/2)+(k+(k*(k-1)/2))*(i-1))]
          te_rep[(5*dimte+1+dimte*(i-1)):(5*dimte+dimte+dimte*(i-1)),s] = temp_tmgte$te[(1+dimte*(i-1)):(dimte+dimte*(i-1))]
          tavar_rep[(5*dimte+1+dimte*(i-1)):(5*dimte+dimte+dimte*(i-1)),s] = temp_tmgte$tavar[(1+dimte*(i-1)):(dimte+dimte*(i-1))]
        }
        if (Tobs>k) {
          i = 1
          for (i in 1:nee) {
            np_rep[((5+nee)*k+1+k*(i-1)):((5+nee)*k+k+k*(i-1)),s] = temp_tmgc$np[i] 
            est_rep[((5+nee)*k+1+k*(i-1)):((5+nee)*k+k+k*(i-1)),s] = temp_tmgc$ests[(1+k*(i-1)):(k+k*(i-1))]
            avar_rep[((5+nee)*k+1+k*(i-1)):((5+nee)*k+k+k*(i-1)),s] = temp_tmgc$avar[(1+(k+(k*(k-1)/2))*(i-1)):(k+(k+(k*(k-1)/2))*(i-1))]
            acov_rep[((5+nee)*k2+1+k2*(i-1)):((5+nee)*k2+k2*(i-1)),s] = temp_tmgc$avar[(k+1+(k+(k*(k-1)/2))*(i-1)):(k+(k*(k-1)/2)+(k+(k*(k-1)/2))*(i-1))]
            te_rep[((5+nee)*dimte+1+dimte*(i-1)):((5+nee)*dimte+dimte+dimte*(i-1)),s] = temp_tmgc$te[(1+dimte*(i-1)):(dimte+dimte*(i-1))]
            tavar_rep[((5+nee)*dimte+1+dimte*(i-1)):((5+nee)*dimte+dimte+dimte*(i-1)),s] = temp_tmgc$tavar[(1+dimte*(i-1)):(dimte+dimte*(i-1))]
          }
        }
      }
    }
    ###########################################################
  }
  
  ### calculate statistics of E(theta_i)
  ###########################################################
  # FE, GP, SU, TMG
  for (j in 1:k) {
    kid = c(j,seq(j+6,ne*k,by=2)) # fix the row number of FE, GP, SU, TMG
    i = 1
    for (i in 1:(ne-2)) {
      ki = kid[i]
      if (is.null(est_rep[ki,1])==F) {
        np_re = np_rep[ki,]
        est_re = est_rep[ki,]
        avar_re = avar_rep[ki,]
        estsdm_re = cbind(est_re,sqrt(avar_re))
        bias_rep[ki,1] = Bias(est_re,m_y[j])
        rmse_rep[ki,1] = Rmse(est_re,m_y[j])
        cvr_rep[ki,1] = Coverage(m_y[j],estsdm_re,rep)
        pw_rep[,ki] = Power(m_y[j],estsdm_re,rep) 
        size_rep[ki,1] = pw_rep[which(as.matrix(seq(as.numeric(0+pwlb),as.numeric(0+pwrb),by=pwintv))==0),ki]
        stat_rep[ki,] = c(mean(np_re),mean(est_re),mean(avar_re),bias_rep[ki,1],rmse_rep[ki,1],cvr_rep[ki,1],size_rep[ki,1])#,pwl_rep[ki,1],pwr_rep[ki,1])
        rm(est_re,avar_re,estsdm_re)
      }
    }
  }
  ## MG
  if (mge==1) {
    # MG or MG-TE
    repr = (np_rep[(k+1),] == 0 & (avar_rep[(k+1),]>0)==1 & (avar_rep[(k+k),]>0)==1)
    mgi = which(repr==1)
    rep1 = length(mgi)
    if (rep1>0) {
      for (j in 1:k) {
        ki = j+k
        est_re = est_rep[ki,mgi]
        avar_re = avar_rep[ki,mgi]
        estsdm_re = cbind(est_re,sqrt(avar_re))
        bias_rep[ki,1] = Bias(est_re,m_y[j])
        rmse_rep[ki,1] = Rmse(est_re,m_y[j])
        cvr_rep[ki,1] = Coverage(m_y[j],estsdm_re,rep1)
        pw_rep[,ki] = Power(m_y[j],estsdm_re,rep1) 
        size_rep[ki,1] = pw_rep[which(as.matrix(seq(as.numeric(0+pwlb),as.numeric(0+pwrb),by=pwintv))==0),ki]
        stat_rep[ki,] = c(1-rep1/rep,mean(est_re),mean(avar_re),bias_rep[ki,1],rmse_rep[ki,1],cvr_rep[ki,1],size_rep[ki,1])#,pwl_rep[ki,1],pwr_rep[ki,1])
        rm(est_re,avar_re,estsdm_re)
      }
    } 
    
    # MG-C
    if (te >0) {
      mgbi = which(repr==1)
      rep2 = length(mgbi)
      if (rep2 > 0) {
        for (j in 1:k) {
          ki = j+2*k
          np_re = np_rep[ki,mgbi]
          est_re = est_rep[ki,mgbi]
          avar_re = avar_rep[ki,mgbi]
          estsdm_re = cbind(est_re,sqrt(avar_re))
          bias_rep[ki,1] = Bias(est_re,m_y[j])
          rmse_rep[ki,1] = Rmse(est_re,m_y[j])
          cvr_rep[ki,1] = Coverage(m_y[j],estsdm_re,rep2)
          pw_rep[,ki] = Power(m_y[j],estsdm_re,rep2) 
          size_rep[ki,1] = pw_rep[which(as.matrix(seq(as.numeric(0+pwlb),as.numeric(0+pwrb),by=pwintv))==0),ki]
          stat_rep[ki,] = c(1-rep2/rep,mean(est_re),mean(avar_re),bias_rep[ki,1],rmse_rep[ki,1],cvr_rep[ki,1],size_rep[ki,1])#,pwl_rep[ki,1],pwr_rep[ki,1])
          rm(est_re,avar_re,estsdm_re)
        }
      }
    }
  }
  ###########################################################
  
  ### calculate statistics of time effects phi
  ###########################################################
  if (te>0) {
    for (tid in 1:Tobs) {
      truevalue = phi_te[tid]
      for (i in 1:ne) {
        ki = tid+Tobs*(i-1) 
        if (is.null(te_rep[ki,1])==0) {
          test_re = te_rep[ki,]
          tbias_rep[ki,1] = Bias(test_re,truevalue)
          trmse_rep[ki,1] = Rmse(test_re,truevalue)
          statte_rep[ki,1:2] = c(stat_rep[1+(i-1)*k,1],mean(test_re))
          statte_rep[ki,4:5] = c(tbias_rep[ki,1],trmse_rep[ki,1])
          if (is.null(tavar_rep[ki,1])==0) {
            tavar_re = tavar_rep[ki,]
            testsdm_re = cbind(test_re,sqrt(tavar_re))
            tcvr_rep[ki,1] = Coverage(truevalue,testsdm_re,rep)
            tpw_rep[,ki] = Power(truevalue,testsdm_re,rep) 
            tsize_rep[ki,1] = tpw_rep[which(as.matrix(seq(as.numeric(0+pwlb),as.numeric(0+pwrb),by=pwintv))==0),ki]
            statte_rep[ki,] = c(stat_rep[1+(i-1)*k,1],mean(test_re),mean(tavar_re),tbias_rep[ki,1],trmse_rep[ki,1],tcvr_rep[ki,1],tsize_rep[ki,1])
            rm(testsdm_re)
          }
          rm(test_re,tavar_re)
        }
      }
    }
    
  }
  
  ###########################################################
  if (fee==1 & mge==1 & gpe==1 & tmge==1) {
      em = "est" 
  }
  
  output_theta = list(em,stat_rep,est_rep,avar_rep,acov_rep,np_rep,bias_rep,rmse_rep,cvr_rep,size_rep,pw_rep)
  names(output_theta) = c("em","stat","est","avar","acov","np","bias","rmse","cvr","size","pw")
  if (te==0) {
    output = output_theta
  }
  if (te>0) {
    output_te = list(em,statte_rep,te_rep,tavar_rep,tpw_rep)
    names(output_te) = c("em","stat","est","avar","pw")
    output = list(output_theta, output_te)
    names(output) = c("theta","te")
  }
  output
}
################################################################################
### Define Functions of DGP (Deme_i, Gen_balpanel)
################################################################################
Deme_i = function(paneldata_e,Tobs,i) {
  ti = Tobs
  ei = matrix(paneldata_e[(1+(i-1)*Tobs):(i*Tobs),],ti,1)
  qti= diag(ti)-matrix(1, nrow=ti, ncol=1) %*% t(matrix(1, nrow=ti, ncol=1))/ti 
  deti = det( t(ei) %*% qti %*% ei)
  return(deti)
}

# generate a panel data set in the long format
Gen_balpanel = function(nobs,Tobs,k,m_y,gauss_y,m_x,hetero_x,dist_x,ar_x,te_x,corr_e,para_case,kappa2,phi_te,idt){
  x_nT_long = matrix(,(nobs*Tobs),(k-1))
  e_nT_long = matrix(,(nobs*Tobs),(k-1))
  for (j in 1: (k-1)) {
    ### 1(1). x_it: generate errors IID(0,1) dist in {1,2,3,4} normal, chi-squared, uniform, binary
    if (dist_x==1) {
      e_nT = matrix(rnorm(nobs*Tobs,0,1),nobs,Tobs) # (n by T) normal(0,1)
      gamma2 = 0
    }
    if (dist_x==2) {
      e_0 = matrix(runif(nobs*Tobs,0,1),nobs,Tobs)
      e_nT = sqrt(12)*(e_0-1/2) # (n by T) uniform
      gamma2 = -6/5
    }
    
    ### 1(3) x_it: generate sigma_iv and xi_ix then plug in
    # hetero_x==0: homogeneous variance of x
    if (hetero_x==0) {
      sigma_vnT = matrix(1,nobs,Tobs)
    }
    # hetero_x==1: heterogeneous variance of x
    if (hetero_x==1) {
      sigma_vnT = matrix(sigma_vn[,j],nobs,Tobs) # (n by T) same in a row
    }
    v_nT = e_nT*sigma_vnT # (n by T)
    
    alphax_n = matrix(m_x[j,1],nobs,1) + axx_n[,j] # (n by 1)
    alphax_nT = matrix(alphax_n,nobs,Tobs) # (n by T) same in a row
    Th = 51 # number of existing periods before observed
    if (ar_x == 0) {
      phix_n = matrix(m_x[j,2],nobs,1) # (n by 1)
      phix_nT = matrix(phix_n,nobs,Tobs) # (n by T) same in a row
      ## include a common factor structure or time effects
      ft_n = t(matrix(rep(ft,nobs),Tobs,nobs)) # factors
      # factor loadings
      if (te_x==0) {
        gamma_n = matrix(0,nobs,Tobs)
      }
      if (te_x==1) {
        gamma_n = matrix(1,nobs,Tobs)
      }
      if (te_x==2) {
        gamma_n = matrix(runif(nobs,0,2),nobs,Tobs)
      }
      x_nT = alphax_nT*(1-phix_nT) + gamma_n*ft_n + v_nT # (n by T)
    }
    if (ar_x == 1) {
      tau_n = matrix(1,nobs,1) 
      phix_n = phixx_n[,j] # (n by 1) uniform (0,0.95)
      if (dist_x==1) {
        e_h = matrix(rnorm(nobs*Th,0,1),nobs,Th) # (n by T) normal(0,1)
      }
      if (dist_x==2) {
        e_h0 = matrix(runif(nobs*Th,0,1),nobs,Th)
        e_h = sqrt(12)*(e_h0-1/2) # (n by T) uniform
      }
      sigma_vh = matrix(sigma_vn[,j],nobs,Th)
      v_h = sigma_vh*e_h # (n by 51)
      v_hT = cbind(v_h,v_nT) # (n by (51+Tobs))
      x_hT = matrix(,nobs,(Th+Tobs))
      x_hT[,1] = matrix(0,nobs,1)
      if (te_x==0) {
        gamma_n = matrix(0,nobs,1)
      }
      if (te_x==1) {
        gamma_n = matrix(1,nobs,1)
      }
      if (te_x==2) {
        gamma_n = matrix(runif(nobs,0,2),nobs,1)
      }
      for ( j2 in 2:(Th+Tobs)) {
        fth_n = matrix(rep(fth[j2],nobs),nobs,1)
        x_hT[,j2] = alphax_n*(tau_n-phix_n) + gamma_n*fth_n + phix_n*x_hT[,(j2-1)]+sqrt(tau_n-phix_n^2)*v_hT[,j2]
      }
      x_nT = x_hT[,(Th+1):(Th+Tobs)]
    }
    
    e_nT_temp = matrix(t(e_nT),nobs*Tobs,1) # (nT by 1)
    e_nT_long[,j] = e_nT_temp 
    rm(e_nT_temp)
    
    x_nT_temp = matrix(t(x_nT),nobs*Tobs,1) # (nT by 1)
    x_nT_long[,j] = x_nT_temp 
    rm(x_nT_temp)
  }
  int_nT_long = matrix(1,nobs*Tobs) # (n by T)
  w_nT_long = cbind(int_nT_long, x_nT_long) # (nT by k)
  
  ### 1(2). x_it: calculate lambda_i
  id_n = matrix(seq(1,nobs,by=1),nobs,1)
  deme_n = matrix(sapply(id_n,Deme_i,paneldata_e=e_nT_long,Tobs=Tobs),nobs,1) # (n by 1)
  lambda_n = (deme_n-(Tobs-1))/sqrt(2*(Tobs-1)+gamma2/Tobs*((Tobs-1)^2)) # (n by 1)
  
  ### 2. Generate heterogeneous parameters with k=2: dim(sigma_x) = 1
  sigma_zeta = para_case[1:k]  # (1 by k)
  psi = para_case[(k+1):(2*k)]# (1 by k)
  zeta_n = matrix(,nobs,k)
  eta_n = matrix(,nobs,k)
  theta_n = matrix(,nobs,k)
  theta_nT_long = matrix(,nobs*Tobs,k)
  for (j in 1:k){
    zeta_n[,j] = rnorm(nobs,0,sigma_zeta[j])
    eta_n[,j] = psi[j]*lambda_n + zeta_n[,j]
    theta_n[,j] = matrix(m_y[j],nobs,1) + eta_n[,j]
    theta_nT_long[,j] = matrix(t(matrix(theta_n[,j],nobs,Tobs)),nobs*Tobs,1)
  }
  
  ### 3. Generate time effects in y_{it}
  phi_nT = matrix(phi_te,Tobs,nobs)
  phi_nT_long = matrix(phi_nT,nobs*Tobs,1)
  
  ### 4. y_{it}: generate errors
  if (gauss_y==1) {
    ey_nT = matrix(rnorm(nobs*Tobs,0,1),nobs,Tobs) # (n by T) normal(0,1)
  }
  if (gauss_y==0){
    ey_nT = matrix(0.5*rchisq(nobs*Tobs,df=2,ncp = 0)-1, nobs, Tobs) # (n by T) chi-squared 
  }
  if (corr_e==0) {
    rhoe_n = matrix(0,nobs,1)
  }
  if (ar_x == 0 & te==0) {
    ey_n0 = matrix(0,nobs,1)
  } else {
    ey_n0 = matrix(rnorm(nobs,0,1),nobs,1)
  }
  ey_temp = cbind(ey_n0,matrix(,nobs,Tobs))
  tid = 1
  for (tid in 2:(Tobs+1)) {
    ey_temp[,tid] = rhoe_n*ey_temp[,(tid-1)] + sqrt(1-rhoe_n^2)*ey_nT[,(tid-1)]  
  }
  ey_nT = ey_temp[,2:(Tobs+1)]
  rm(ey_temp)
  
  if (hetrosk==1) {
    sigma_unT = matrix(sigma_un,nobs,Tobs) 
  }
  if (hetrosk==2) {
    sigma_unT = matrix(sqrt(lambda_n^2),nobs,Tobs)
  } 
  if (hetrosk==3) {
    sigma_unT = matrix(sqrt((e_nT_long^2)),nobs,Tobs)
  }
  u_nT = sqrt(kappa2)*sigma_unT*ey_nT # (n by T)
  u_nT_long = matrix(t(u_nT),nobs*Tobs,1) # (nT by k=1)
  
  ### 5. y_{it}: plug in all variables
  y_nT_long = phi_nT_long+rowSums(theta_nT_long*w_nT_long)+u_nT_long
  z_nt_long = cbind(idt,y_nT_long,x_nT_long)  # (nT by k+1) long-format panel data
  return(z_nt_long) 
}
################################################################################
### Set Key Parameters of DGP and Estimators
################################################################################
k = 2 # dim(wit) = k
m_y = cbind(1,1) # True value of parameters of ineterests
m_x = matrix(cbind(1,0),(k-1),2)

sigma_a = sqrt(0.2)
sigma_b = matrix(sqrt(c(0.5,0.75)),(k-1),2) # 2 cases
sigma = rbind(matrix(sigma_a,1,2),sigma_b) 
rho_eta = matrix(c(0,0,0.25,0.25,0.5,0.5),k,3) # 3 cases
PR2 = cbind(0.2,0.4) # 2 cases
di1 = length(PR2)
di2 = dim(sigma_b)[2]
di3 = dim(rho_eta)[2]
ncase = di1*di2*di3
case_list = seq(1,ncase,by=1)

case_table = matrix(,(1+k+k+k+k),ncase)
sigma_zeta_list = matrix(,k,ncase)
psi_list = matrix(,k,ncase)
for (i1 in 1:di1) {
  for (i2 in 1:di2) {
    for (i3 in 1:di3) {
      ic = i3+(i2-1)*di3+(i1-1)*di2*di3
      for (j in 1:k){
        sigma_zeta_list[j,ic] = sqrt(sigma[j,i2]^2*(1-rho_eta[j,i3]^2))
        psi_list[j,ic] = rho_eta[j,i3]*sigma[j,i2]
      }
      case_table[,ic] = rbind(PR2[i1],sigma[1,i2]^2,sigma[2,i2]^2,rho_eta[1,i3],rho_eta[2,i3],sigma_zeta_list[1,ic]^2,sigma_zeta_list[2,ic]^2,psi_list[1,ic],psi_list[2,ic])
    }
  }
}
para_list = rbind(sigma_zeta_list,psi_list)
para_list = para_list[,c(1,2,3,9)] # (1), (2), (3), higher PR^2
case_table = case_table[,c(1,2,3,9)] 

## Parameters of Estimators
a_list = as.matrix(c(1/3)) # TMG: rates for trimming
l_list = as.matrix(c(1)) # SU: orders of polynominal regression

# No. estimates: FE, MG, GP, SU, TMG
nest = 1+2+1+dim(l_list)[1]+dim(a_list)[1] 

## Input data and fix the dimension
TNlist = c(1000,2000,5000,10000)
TTlist = c(2,3,4,5,6,8)
NT_list = expand.grid(TNlist,TTlist) 
rep = 2000 # number of replications for simulation
bal_panel = 1 # (0,1) Paneldata sets are balanced or not


################################################################################
### Run Monte Carlo simulation
################################################################################

### (3) The set of MC experiments comparing TMG and GP estimators over different DGPs
################################################################################
hetrosk = 1
corr_e = 0 # (0,1) Errors in outcome y are serially correalted or not.
dist_x = 1 # Gaussian distributed shocks in x_{it}
hetero_x = 1 # (0,1) Errors in regressor x are heteroskedastic or not. 
case = 3 # rho_beta = 0.5, PR^2 = 0.2

te.c = c(0,0,0,0,1,1,1)  # whether time effects are included in regressions or not 
gauss_y.c = c(1,0,0,0,0,0,0) # (0,1)  Errors in outcome y are Gaussian or chi-squared distributed.
ar_x.c = c(0,0,1,1,0,1,1) # (0,1) x_{it} follow a heterogeneous AR process or not
te_x.c = c(0,0,0,2,0,0,2) # whether there is an interactive effect in x_{it}
exp3 = rbind(te.c, gauss_y.c, ar_x.c, te_x.c)
rownames(exp3) = c("te","gauss_y","ar_x","te_x")

for (eid in 1:dim(exp3)[2])  {
  rm(list=ls(pattern="^TMG_d"));rm(list=ls(pattern="^theta_d"));rm(list=ls(pattern="^te_d"))
  ## combo of n and T
  Nlist = c(1000,2000,5000,10000)
  Tlist = c(2)
  NT = expand.grid(Nlist,Tlist) 
  
  #### parameters of the DGP
  te = exp3[1,eid] # c(0,1) whether time effects are allowed in the panel data model 
  gauss_y = exp3[2,eid] 
  ar_x = exp3[3,eid]
  te_x = exp3[4,eid] # (0,1,2) no time effects, a common time effect, a common factor in x_{it}
  
  ## Get the respective kappa2 value
  #############################################################################
  name = paste("k2",dist_x,sep="dx")
  if (ar_x==1 & te_x==0) {
    name = paste(name,"arx",sep="_")
  }
  if (ar_x==1 & te_x==2) {
    name = paste(name,"afx",sep="_")
  }
  k2_table = get(name)
  #############################################################################
  
  for (l in 1:dim(NT)[1]) {
    ############################################################################
    nobs = NT[l,1]
    Tobs = NT[l,2]
    Tid = which(TTlist==Tobs)
    if (case==0) {
      kappa2 = 8
    } else {
      kappa2 = k2_table[Tid,case]
    }
    rm(Tid)
    
    ## index of n and t for balanced paneldata sets
    Tl = matrix(seq(1,Tobs,by=1),Tobs,1)
    Tm = matrix(matrix(Tl,Tobs,nobs),nobs*Tobs,1)
    nl = matrix(seq(1,nobs,by=1),nobs,1)
    nm = matrix(t(matrix(nl,nobs,Tobs)),nobs*Tobs,1)
    idt = cbind(nm,Tm)
    rm(Tl,Tm,nl,nm)
    #############################################################################
    
    para_case = para_list[,case] # sigma_zeta, psi
    
    #run simulation
    ########################
    ### common time effects
    if (te==0) {
      phi_te = rep(0,Tobs) # T=3 (1,1,-2)
    }
    if (te==1) {
      phi_1 = seq(1,Tobs-1)
      phi_te = c(phi_1,-sum(phi_1))
    }
    ## A stationary AR(1) process of a common effect
    set.seed(2022202299)
    fth = matrix(,Tobs+51,1); fth[1]=0; # with a zero initial value
    for (tid in 2:(Tobs+51) ) {
      vt = rnorm(1,0,1)
      fth[tid] = 0.9*fth[tid-1]+sqrt(1-0.9^2)*vt;rm(vt) 
    }
    ft = fth[52:(Tobs+51)] # for t=1,2,...,T
    
    set.seed(20222022)
    rhoe_n = matrix(runif(nobs,0,0.95),nobs,1) # hetero AR coeff in serial correlated errors
    
    set.seed(102021)
    sigma_vn = matrix(sqrt(0.5*rnorm(nobs,0,1)^2+0.5),nobs,(k-1)) # (n by k-1)
    sigma_un = matrix(sqrt(0.5*rnorm(nobs,0,1)^2+0.5),nobs,1) # (n by 1)
    axx_n = matrix(rnorm(nobs,0,1),nobs,(k-1)) # (n by k-1)
    phixx_n = matrix(runif(nobs,0,0.95),nobs,(k-1)) # (n by k-1)
    
    if (te==0) {
      simu_temp = MCS_rep(rep,nobs,Tobs,k,m_y,gauss_y,m_x,hetero_x,dist_x,ar_x,te_x,corr_e,para_case,kappa2,bal_panel,phi_te,a_list,l_list,te,fee=0,mge=0,gpe=1*(Tobs<4),sue=0*(Tobs==2),tmge=1)
    }
    if (te>0) {
      simu_temp = MCS_rep(rep,nobs,Tobs,k,m_y,gauss_y,m_x,hetero_x,dist_x,ar_x,te_x,corr_e,para_case,kappa2,bal_panel,phi_te,a_list,l_list,te,fee=0,mge=0,gpe=1*(Tobs<4),sue=0*(Tobs==2),tmge=1)
    }
    
    if (te==0) {
      em = simu_temp$em
      name1 = paste(em,dist_x,sep="_d")
      name2 = paste(name1,case,sep="c")
      name3 = paste(name2,nobs,sep="_n")
      name4 = paste(name3,Tobs,sep="_T")
      assign(name4,simu_temp)
    }
    
    if (te>0) {
      em =simu_temp$theta$em
      name1 = paste("theta",dist_x,sep="_d")
      name2 = paste(name1,case,sep="c")
      name3 = paste(name2,nobs,sep="_n")
      name4 = paste(name3,Tobs,sep="_T")
      assign(name4,simu_temp$theta)
      
      name1 = paste("te",dist_x,sep="_d")
      name2 = paste(name1,case,sep="c")
      name3 = paste(name2,nobs,sep="_n")
      name4 = paste(name3,Tobs,sep="_T")
      assign(name4,simu_temp$te)
    }
  }
  
  if (te==0) {
    results.list = ls(pattern = paste("^",em,"_d",sep="")) 
  }
  if (te>0) {
    results.list = c(ls(pattern = paste("^","theta","_d",sep="")),ls(pattern = paste("^","te","_d",sep=""))) 
  }
  
  
  ################################################################################
  ### Store Results of Monte Carlo simulation
  ################################################################################
  fn0 = paste(em,te,sep="_te")
  ### 1. distribution of errors in x
  if (dist_x == 1) {
    fn1 = paste(fn0,"norm",sep="_")
  }
  if (dist_x == 2) {
    fn1 = paste(fn0,"unif",sep="_")
  }
  ### 2. with or without interactive effects in x
  fn2 = paste(fn1,te_x,sep="_tex")
  ### 3. non-Gaussian errors in panels or dynamics in x
  if (gauss_y == 1 & ar_x == 0) {
    fn3 = fn2
  }
  if (gauss_y==0) {
    fn3 = paste(fn2,"chi2",sep="_")
  }
  if (ar_x==1) {
    fn3 = paste(fn2,"arx",sep="_")
  }
  fn3 = paste(fn3,"_hetrosk",hetrosk,sep="")
  ### 4. case of parameters' values
  fn4 = paste(fn3,case,sep="_")
  ### 5. sample size n of individuals
  ntid = 0 
  for (idx in 1:dim(NT_list)[1]) {
    ntid = ntid + idx*(NT_list[idx,1]==nobs)*(NT_list[idx,2]==Tobs)
  }
  if (ntid<10) {
    fn5 = paste(fn4,ntid,sep="0")
  } else {
    fn5 = paste(fn4,ntid,sep="")
  }
  ### add extension as "RData"
  fn6 = paste(fn5,".RData",sep="")
  ################################################################################
  save(list = results.list, file = fn6) 
}
################################################################################


### (2) The set of MC experiments comparing TMG, GP and SU estimators
################################################################################
gauss_y = 0 # (0,1)  Errors in outcome y are Gaussian or chi-squared distributed.
corr_e = 0 # (0,1) Errors in outcome y are serially correalted or not.
dist_x = 1 # （1,2)  whether primitive errors in x are Gaussian- or uniform-distributed
hetero_x = 1 # (0,1) Errors in regressor x are heteroskedastic or not. 
ar_x = 1 # (0,1) x_{it} follow a heterogeneous AR process or not

te.c = c(0,1,0,0,0,1,1) # whether time effects are included in regressions or not 
hetrosk.c = c(1,1,2,3,1,1,1) # random or correlated heteroskedastic errors
te_x.c = c(0,0,0,0,0,0,2) # whether there is an interactive effect in x_{it}
case.c = c(3,3,3,3,4,4,3) # different degree of correlated heterogeneity and PR^2
exp2 = rbind(te.c, hetrosk.c, te_x.c, case.c)
rownames(exp2) = c("te","hetrosk","te_x","case")

for (eid in dim(exp2)[2])  {
  rm(list=ls(pattern="^TMG_d"));rm(list=ls(pattern="^theta_d"));rm(list=ls(pattern="^te_d"))
  ## combo of n and T
  Nlist = c(1000,2000,5000,10000)
  Tlist = c(2,3)
  NT = expand.grid(Nlist,Tlist) 
  
  #### parameters of the DGP
  te = exp2[1,eid] # c(0,1) whether time effects are allowed in the panel data model 
  hetrosk = exp2[2,eid] # c(1,2,3) random, correlated case (a), correlated case (b)
  te_x = exp2[3,eid] # (0,1,2) no time effects, a common time effect, a common factor in x_{it}
  case = exp2[4,eid]
  
  ## Get the respective kappa2 value
  #############################################################################
  name = paste("k2",dist_x,sep="dx")
  if (ar_x==1 & te_x==0) {
    name = paste(name,"arx",sep="_")
  }
  if (ar_x==1 & te_x==2) {
    name = paste(name,"afx",sep="_")
  }
  k2_table = get(name)
  #############################################################################
  
  for (l in 1:dim(NT)[1]) {
    ############################################################################
    nobs = NT[l,1]
    Tobs = NT[l,2]
    Tid = which(TTlist==Tobs)
    if (case==0) {
      kappa2 = 8
    } else {
      kappa2 = k2_table[Tid,case]
    }
    rm(Tid)
    
    ## index of n and t for balanced paneldata sets
    Tl = matrix(seq(1,Tobs,by=1),Tobs,1)
    Tm = matrix(matrix(Tl,Tobs,nobs),nobs*Tobs,1)
    nl = matrix(seq(1,nobs,by=1),nobs,1)
    nm = matrix(t(matrix(nl,nobs,Tobs)),nobs*Tobs,1)
    idt = cbind(nm,Tm)
    rm(Tl,Tm,nl,nm)
    #############################################################################
    
    para_case = para_list[,case] # sigma_zeta, psi
    
    #run simulation
    ########################
    ### common time effects
    if (te==0) {
      phi_te = rep(0,Tobs) # T=3 (1,1,-2)
    }
    if (te==1) {
      phi_1 = seq(1,Tobs-1)
      phi_te = c(phi_1,-sum(phi_1))
    }
    ## A stationary AR(1) process of a common effect
    set.seed(2022202299)
    fth = matrix(,Tobs+51,1); fth[1]=0; # with a zero initial value
    for (tid in 2:(Tobs+51) ) {
      vt = rnorm(1,0,1)
      fth[tid] = 0.9*fth[tid-1]+sqrt(1-0.9^2)*vt;rm(vt) 
    }
    ft = fth[52:(Tobs+51)] # for t=1,2,...,T
    
    set.seed(20222022)
    rhoe_n = matrix(runif(nobs,0,0.95),nobs,1) # hetero AR coeff in serial correlated errors
    
    set.seed(102021)
    sigma_vn = matrix(sqrt(0.5*rnorm(nobs,0,1)^2+0.5),nobs,(k-1)) # (n by k-1)
    sigma_un = matrix(sqrt(0.5*rnorm(nobs,0,1)^2+0.5),nobs,1) # (n by 1)
    axx_n = matrix(rnorm(nobs,0,1),nobs,(k-1)) # (n by k-1)
    phixx_n = matrix(runif(nobs,0,0.95),nobs,(k-1)) # (n by k-1)
    
    if (te==0) {
      simu_temp = MCS_rep(rep,nobs,Tobs,k,m_y,gauss_y,m_x,hetero_x,dist_x,ar_x,te_x,corr_e,para_case,kappa2,bal_panel,phi_te,a_list,l_list,te,fee=0,mge=0,gpe=1*(Tobs<4),sue=1*(Tobs==2),tmge=1)
    }
    if (te>0) {
      simu_temp = MCS_rep(rep,nobs,Tobs,k,m_y,gauss_y,m_x,hetero_x,dist_x,ar_x,te_x,corr_e,para_case,kappa2,bal_panel,phi_te,a_list,l_list,te,fee=0,mge=0,gpe=1*(Tobs<4),sue=1*(Tobs==2),tmge=1)
    }
    
    if (te==0) {
      em = simu_temp$em
      name1 = paste(em,dist_x,sep="_d")
      name2 = paste(name1,case,sep="c")
      if (hetrosk>1) {
        name2 = paste(name2,hetrosk,sep="_h")
      }
      name3 = paste(name2,nobs,sep="_n")
      name4 = paste(name3,Tobs,sep="_T")
      assign(name4,simu_temp)
    }
    
    if (te>0) {
      em =simu_temp$theta$em
      name1 = paste("theta",dist_x,sep="_d")
      name2 = paste(name1,case,sep="c")
      if (hetrosk>1) {
        name2 = paste(name2,hetrosk,sep="_h")
      }
      name3 = paste(name2,nobs,sep="_n")
      name4 = paste(name3,Tobs,sep="_T")
      assign(name4,simu_temp$theta)
      
      name1 = paste("te",dist_x,sep="_d")
      name2 = paste(name1,case,sep="c")
      if (hetrosk>1) {
        name2 = paste(name2,hetrosk,sep="_h")
      }
      name3 = paste(name2,nobs,sep="_n")
      name4 = paste(name3,Tobs,sep="_T")
      assign(name4,simu_temp$te)
    }
  }
  
  if (te==0) {
    results.list = ls(pattern = paste("^",em,"_d",sep="")) 
  }
  if (te>0) {
    results.list = c(ls(pattern = paste("^","theta","_d",sep="")),ls(pattern = paste("^","te","_d",sep=""))) 
  }
  
  
  ################################################################################
  ### Store Results of Monte Carlo simulation
  ################################################################################
  fn0 = paste(em,te,sep="_te")
  ### 1. distribution of errors in x
  if (dist_x == 1) {
    fn1 = paste(fn0,"norm",sep="_")
  }
  if (dist_x == 2) {
    fn1 = paste(fn0,"unif",sep="_")
  }
  ### 2. with or without interactive effects in x
  fn2 = paste(fn1,te_x,sep="_tex")
  ### 3. non-Gaussian errors in panels or dynamics in x
  if (gauss_y == 1 & ar_x == 0) {
    fn3 = fn2
  }
  if (gauss_y==0) {
    fn3 = paste(fn2,"chi2",sep="_")
  }
  if (ar_x==1) {
    fn3 = paste(fn2,"arx",sep="_")
  }
  fn3 = paste(fn3,"_hetrosk",hetrosk,sep="")
  ### 4. case of parameters' values
  fn4 = paste(fn3,case,sep="_")
  ### 5. sample size n of individuals
  ntid = 0 
  for (idx in 1:dim(NT_list)[1]) {
    ntid = ntid + idx*(NT_list[idx,1]==nobs)*(NT_list[idx,2]==Tobs)
  }
  if (ntid<10) {
    fn5 = paste(fn4,ntid,sep="0")
  } else {
    fn5 = paste(fn4,ntid,sep="")
  }
  ### add extension as "RData"
  fn6 = paste(fn5,".RData",sep="")
  ################################################################################
  save(list = results.list, file = fn6) 
  
}
################################################################################


rm(list=ls())
if (!requireNamespace("openxlsx", quietly = TRUE)) {
  install.packages("openxlsx")
}
library(openxlsx)

# Create a new workbook
wb <- createWorkbook()

# Create a style for center-aligning the numbers
##############################################################################
center_style <- createStyle(halign = "center")
right <- createStyle(halign = "right")
left <- createStyle(halign = "left")
bbs <- createStyle(border = "bottom",borderStyle="thin")
lbs <- createStyle(border = "bottom",borderStyle="double")
tbs <- createStyle(border = "top",borderStyle="double")
wrap_text_style <- createStyle(wrapText = TRUE)
##############################################################################

##############################################################################
pwlb=-2.5; pwrb=2.5; pwintv=0.01;
pwgrid = length(as.matrix(seq(as.numeric(0+pwlb),as.numeric(0+pwrb),by=pwintv)))
k=2;
##############################################################################

# Table S.10: Report MC results of TMG and GP under different DGPs
##############################################################################
estn1 = c("TMG","GP")
estn2 = c("TMG-TE","GP")
sn = "Table S.10"
nstat = 4 # perncent trimmed, bias, rmse, size
addWorksheet(wb, sn)

Nlist = c(1000,2000,5000,10000)
Tlist = c(2)

nest = 2 
panel_nrow = nest*7
panel_ncol = nstat*length(Nlist) 
dist_x = 1; case = 3 
tab = matrix(,panel_nrow,panel_ncol) 

for (idx in 1:7) {
  if (idx==1) {
    fn1 = "TMG_te0_norm_tex0_hetrosk1_304.RData"
    en = 1; temp1 = tryCatch(load(fn1),error=function(e) print(en)) 
  }
  if (idx==2) {
    fn1 = "TMG_te0_norm_tex0_chi2_hetrosk1_304.RData"
    en = 1; temp1 = tryCatch(load(fn1),error=function(e) print(en))
  }
  if (idx==3) {
    fn1 = "TMG_te0_norm_tex0_arx_hetrosk1_304.RData"
    en = 1; temp1 = tryCatch(load(fn1),error=function(e) print(en))
  }
  if (idx==4) {
    fn1 = "TMG_te0_norm_tex2_arx_hetrosk1_304.RData"
    en = 1; temp1 = tryCatch(load(fn1),error=function(e) print(en))
  }
  if (idx==5) {
    fn1 = "TMG-TE_te1_norm_tex0_chi2_hetrosk1_304.RData"
    en = 1; temp1 = tryCatch(load(fn1),error=function(e) print(en))
  }
  if (idx==6) {
    fn1 = "TMG-TE_te1_norm_tex0_arx_hetrosk1_304.RData"
    en = 1; temp1 = tryCatch(load(fn1),error=function(e) print(en))
  }
  if (idx==7) {
    fn1 = "TMG-TE_te1_norm_tex2_arx_hetrosk1_304.RData"
    en = 1; temp1 = tryCatch(load(fn1),error=function(e) print(en))
  }
  rowid = (1:2)+(idx-1)*2
  
  if (temp1[1]!=1) {
    for (nid in 1:length(Nlist)) {
      nobs = Nlist[nid]
      #### the respective rows of estimation results
      id_list = c(12,8)
      Tobs = 2
      colid = (1:4)+(nid-1)*4
      
      #### Input data
      temp_stat = matrix(,nrow=nest,ncol=nstat)
      if (idx %in% c(1,2,3,4)) {
        name1 = paste("TMG",dist_x,sep="_d")
      } else {
        name1 = paste("theta",dist_x,sep="_d")
      }
      name3 = paste(name1,case,sep="c")
      name4 = paste(name3,nobs,sep="_n")
      name5 = paste(name4,Tobs,sep="_T")
      pw1 = matrix(,pwgrid,k*nest)
      en = 1
      temp = tryCatch(get(name5),error=function(e) print(en))
      if (is.list(temp)==1 ){
        temp_stat = temp$stat[id_list,c(1,4,5,7)]
      }
      tab[rowid,colid] = temp_stat
    }
  }
}

writeData(wb, sn, x = "Table S.10: Bias, RMSE and size of TMG, GP and TMG-TE estimators of beta_0 (E(beta_i)=beta_0=1) under different model specifications with correlated heterogeneity, rho_{beta}=0.5, and the level of overall fit, PR^2=0.2, for T=2", startCol = 1, startRow = 1, colNames = FALSE)
writeData(wb, sn, x = "n=1,000", startCol = 3, startRow = 2, colNames = FALSE)
writeData(wb, sn, x = "n=2,000", startCol = 8, startRow = 2, colNames = FALSE)
writeData(wb, sn, x = "n=5,000", startCol = 13, startRow = 2, colNames = FALSE)
writeData(wb, sn, x = "n=10,000", startCol = 18, startRow = 2, colNames = FALSE)

## format data
np_0 = tab[,c(1,5,9,13)]
np_1 = np_0
for (i in 1:length(np_0)) {
  if (is.na(np_0[i]) == 0) {
    np_1[i] = format(round(np_0[i]*100, 1), nsmall = 1)
  } 
}
bias_0 = tab[,c(2,6,10,14)]
bias_1 = bias_0
for (i in 1:length(bias_0)) {
  if (is.na(bias_0[i]) == 0) {
    bias_1[i] = format(round(bias_0[i], 3), nsmall = 3) #round(bias_0[i],digits=3)
  } 
}
rmse_0 = tab[,c(3,7,11,15)]
rmse_1 = rmse_0
for (i in 1:length(rmse_0)) {
  if (is.na(rmse_0[i]) == 0) {
    rmse_1[i] = format(round(rmse_0[i], 3), nsmall = 3) #round(rmse_0[i],digits=3)
  } 
}
size_0 = tab[,c(4,8,12,16)]
size_1 = size_0
for (i in 1:length(size_0)) {
  if (is.na(size_0[i]) == 0) {
    size_1[i] = format(round(size_0[i]*100, 1), nsmall = 1)
  }
}
tab = matrix(rbind(np_1,bias_1,rmse_1,size_1),14,16)

row_name = c(rep(estn1,4),rep(estn2,3))
ncv = matrix("",14,1)
tab0 = cbind(row_name,ncv,tab[,1:4],ncv,tab[,5:8],ncv,tab[,9:12],ncv,tab[,13:16])
nrv = matrix("",1,ncol(tab0))
h = rbind(nrv,nrv,tab0[1:2,],nrv,tab0[3:4,],nrv,tab0[5:6,],nrv,tab0[7:8,],nrv,nrv,tab0[9:10,],nrv,tab0[11:12,],nrv,tab0[13:14,])

mergeCells(wb, sheet = sn, cols = 1:21, rows = 1)
mergeCells(wb, sheet = sn, cols = 3:6, rows = 2)
mergeCells(wb, sheet = sn, cols = 8:11, rows = 2)
mergeCells(wb, sheet = sn, cols = 13:16, rows = 2)
mergeCells(wb, sheet = sn, cols = 18:21, rows = 2)

h1 = c("","","hat{pi}","","","Size","","hat{pi}","","","Size","","hat{pi}","","","Size","","hat{pi}","","","Size")
h2 = c("Estimator","","(*100)","Bias","RMSE","(*100)","","(*100)","Bias","RMSE","(*100)","","(*100)","Bias","RMSE","(*100)","","(*100)","Bias","RMSE","(*100)")
h = rbind(h1,h2,h)
rownames(h) <- NULL
colnames(h) <- NULL
writeData(wb,sn, x = h, startCol = 1, startRow = 3,colNames = FALSE, rowNames = FALSE)
writeData(wb, sn, x = "I. Without time effects in y_{it}", startCol = 1, startRow = 5, colNames = FALSE)
writeData(wb, sn, x = "(a) Gaussian errors in in y_{it}", startCol = 1, startRow = 6, colNames = FALSE)
writeData(wb, sn, x = "(b) Chi-squared errors in in y_{it}", startCol = 1, startRow = 9, colNames = FALSE)
writeData(wb, sn, x = "(c) Heterogeneous AR(1) x_{it} processes", startCol = 1, startRow = 12, colNames = FALSE)
writeData(wb, sn, x = "(d) Heterogeneous AR(1) x_{it} processes with interactive effects", startCol = 1, startRow = 15, colNames = FALSE)
writeData(wb, sn, x = "II. With time effects in y_{it}", startCol = 1, startRow = 18, colNames = FALSE)
writeData(wb, sn, x = "(a). Chi-squared errors in in y_{it}", startCol = 1, startRow = 19, colNames = FALSE)
writeData(wb, sn, x = "(b) Heterogeneous AR(1) x_{it} processes", startCol = 1, startRow = 22, colNames = FALSE)
writeData(wb, sn, x = "(c) Heterogeneous AR(1) x_{it} processes with interactive effects", startCol = 1, startRow = 25, colNames = FALSE)

mergeCells(wb, sheet = sn, cols = 1:21, rows = 5)
mergeCells(wb, sheet = sn, cols = 1:21, rows = 6)
mergeCells(wb, sheet = sn, cols = 1:21, rows = 9)
mergeCells(wb, sheet = sn, cols = 1:21, rows = 12)
mergeCells(wb, sheet = sn, cols = 1:21, rows = 15)
mergeCells(wb, sheet = sn, cols = 1:21, rows = 18)
mergeCells(wb, sheet = sn, cols = 1:21, rows = 19)
mergeCells(wb, sheet = sn, cols = 1:21, rows = 22)
mergeCells(wb, sheet = sn, cols = 1:21, rows = 25)

addStyle(wb,sn,style = center_style, rows = c(2:4),cols = 1:(ncol(h)), gridExpand = T)
addStyle(wb,sn,style = right, rows = c(7:8,10:11,13:14,16:17,20:21,23:24,26:27),cols = 1:(ncol(h)), gridExpand = T)
addStyle(wb,sn,style = left, rows = 1:27,cols = 1, gridExpand = T)
addStyle(wb,sn,style = wrap_text_style, rows = 1,cols = 1:(ncol(h)), gridExpand = T,stack=T)
addStyle(wb,sn,style = bbs, rows = 2,cols = c(3:6,8:11,13:16,18:21), gridExpand = T,stack=T)
addStyle(wb,sn,style = bbs, rows = c(4,5,6,9,12,15,18,19,22,25),cols = 1:(ncol(h)), gridExpand = T,stack=T)
addStyle(wb,sn,style = tbs, rows = 2,cols = 1:(ncol(h)), gridExpand = T,stack=T)
addStyle(wb,sn,style = lbs, rows = (nrow(h)+2),cols = 1:(ncol(h)), gridExpand = T,stack=T)
##############################################################################

# Tables S.13-S.14: Compare TMG-TE, TMG-C, GP and SU
##############################################################################
sn_list = c("Table 3","Table S.8","Table S.13")
estn = c("TMG-TE","TMG-C","GP","SU")
nstat = 4 # perncent trimmed, bias, rmse, size
for (j in 3) {
  sn = sn_list[j]
  addWorksheet(wb, sn)
  
  if (j==1) {
    fn1 = "TMG-TE_te1_norm_tex0_arx_hetrosk1_308.RData"
    en = 1; temp1 = tryCatch(load(fn1),error=function(e) print(en))
    ar_x=1 ; gauss_y=0; corr_e=0; te=1; te_x=0; dist_x = 1; case = 3
    writeData(wb, sn, x = "Table 3: Bias, RMSE and size of TMG-TE, TMG-C, GP and SU estimators of beta_0 (E(beta_i)=beta_0=1) in the baseline model with time effects and with correlated heterogeneity, rho_{beta}=0.5", startCol = 1, startRow = 1, colNames = FALSE)
  }
  if (j==2) {
    fn1 = "TMG-TE_te1_norm_tex0_arx_hetrosk1_408.RData"
    en = 1; temp1 = tryCatch(load(fn1),error=function(e) print(en))
    ar_x=1 ; gauss_y=0; corr_e=0; te=1; te_x=0; dist_x = 1; case = 4
    writeData(wb, sn, x = "Table S.8: Bias, RMSE and size of TMG-TE, TMG-C, GP and SU estimators of beta_0 (E(beta_i)=beta_0=1) in panel data models with time effects, correlated heterogeneity, rho_{beta}=0.5, and the level of overall fit, PR^2=0.4", startCol = 1, startRow = 1, colNames = FALSE)
  }
  if (j==3) {
    fn1 = "TMG-TE_te1_norm_tex2_arx_hetrosk1_308.RData"
    en = 1; temp1 = tryCatch(load(fn1),error=function(e) print(en))
    ar_x=1 ; gauss_y=0; corr_e=0; te=1; te_x=2; dist_x = 1; case = 3
    writeData(wb, sn, x = "Table S.13: Bias, RMSE and size of TMG-TE, TMG-C, GP and SU estimators of beta_0 (E(beta_i)=beta_0=1) in panel data models with time effects, correlated heterogeneity, rho_{beta}=0.5, and interactive effects in the x_{it} equation", startCol = 1, startRow = 1, colNames = FALSE)
  }
  
  if (temp1[1]!=1) {
    writeData(wb, sn, x = "T=2", startCol = 3, startRow = 2, colNames = FALSE)
    writeData(wb, sn, x = "T=3", startCol = 8, startRow = 2, colNames = FALSE)
    
    ################################################################################
    Nlist = c(1000,2000,5000,10000)
    Tlist = c(2,3)
    
    nest = 4 
    panel_nrow = nest*length(Nlist)
    panel_ncol = nstat*length(Tlist) 
    tab = matrix(,panel_nrow,panel_ncol) 
    ################################################################################
    
    for (nid in 1:length(Nlist)) {
      nobs = Nlist[nid]
      rowid = (1:4)+(nid-1)*4
      #### the respective rows of estimation results
      id_list = c(12,14,8,10)
      
      ## for T=2 and T=3
      for (idx in c(1,2)) {
        Tobs = Tlist[idx]
        colid = (1:4)+(idx-1)*4
        
        temp_stat = matrix(,nrow=nest,ncol=nstat)
        name1 = paste("theta",dist_x,sep="_d")
        name3 = paste(name1,case,sep="c")
        name4 = paste(name3,nobs,sep="_n")
        name5 = paste(name4,Tobs,sep="_T")
        pw1 = matrix(,pwgrid,k*nest)
        en = 1
        temp = tryCatch(get(name5),error=function(e) print(en))
        if (is.list(temp)==1 ){
          temp_stat = temp$stat[id_list,c(1,4,5,7)]
        }
        tab[rowid,colid] = temp_stat
      }
      
      ## format data
      np_0 = tab[,c(1,5)]
      np_1 = np_0
      for (i in 1:length(np_0)) {
        if (is.na(np_0[i]) == 0) {
          np_1[i] = format(round(np_0[i]*100, 1), nsmall = 1)
        } 
      }
      
      bias_0 = tab[,c(2,6)]
      bias_1 = bias_0
      for (i in 1:length(bias_0)) {
        if (is.na(bias_0[i]) == 0) {
          bias_1[i] = format(round(bias_0[i], 3), nsmall = 3) #round(bias_0[i],digits=3)
        } 
      }
      
      rmse_0 = tab[,c(3,7)]
      rmse_1 = rmse_0
      for (i in 1:length(rmse_0)) {
        if (is.na(rmse_0[i]) == 0) {
          rmse_1[i] = format(round(rmse_0[i], 2), nsmall = 2) #round(rmse_0[i],digits=3)
        } 
      }
      
      size_0 = tab[,c(4,8)]
      size_1 = size_0
      for (i in 1:length(size_0)) {
        if (is.na(size_0[i]) == 0) {
          size_1[i] = format(round(size_0[i]*100, 1), nsmall = 1)
        }
      }
    }
    
    #######################
    tab =matrix(rbind(np_1,bias_1,rmse_1,size_1),16,8)
    tab[seq(2,16,4),1:4]='...'
    tab[seq(4,16,4),5:8]='...'
    ####################### 
    
    row_name = rep(estn,4)
    ncv = matrix("",16,1)
    tab0 = cbind(row_name,ncv,tab[,1:4],ncv,tab[,5:8])
    nrv = matrix("",1,ncol(tab0))
    h = rbind(nrv,tab0[1:4,],nrv,tab0[5:8,],nrv,tab0[9:12,],nrv,tab0[13:16,])
    
    mergeCells(wb, sheet = sn, cols = 1:11, rows = 1)
    mergeCells(wb, sheet = sn, cols = 3:6, rows = 2)
    mergeCells(wb, sheet = sn, cols = 8:11, rows = 2)
    
    h1 = c("","","hat{pi}","","","Size","","hat{pi}","","","Size")
    h2 = c("Estimator","","(*100)","Bias","RMSE","(*100)","","(*100)","Bias","RMSE","(*100)")
    h = rbind(h1,h2,h)
    rownames(h) <- NULL
    colnames(h) <- NULL
    writeData(wb,sn, x = h, startCol = 1, startRow = 3,colNames = FALSE, rowNames = FALSE)
    writeData(wb, sn, x = "n=1,000", startCol = 3, startRow = 5, colNames = FALSE)
    writeData(wb, sn, x = "n=2,000", startCol = 3, startRow = 10, colNames = FALSE)
    writeData(wb, sn, x = "n=5,000", startCol = 3, startRow = 15, colNames = FALSE)
    writeData(wb, sn, x = "n=10,000", startCol = 3, startRow = 20, colNames = FALSE)
    mergeCells(wb, sheet = sn, cols = 3:11, rows = 5)
    mergeCells(wb, sheet = sn, cols = 3:11, rows = 10)
    mergeCells(wb, sheet = sn, cols = 3:11, rows = 15)
    mergeCells(wb, sheet = sn, cols = 3:11, rows = 20)
    
    addStyle(wb,sn,style = right, rows = c(6:9,11:14,16:19,21:24),cols = 1:(ncol(h)), gridExpand = T)
    addStyle(wb,sn,style = left, rows = 1:24,cols = 1, gridExpand = T)
    addStyle(wb,sn,style = center_style, rows = c(2:5,10,15,20),cols = 1:(ncol(h)), gridExpand = T)
    addStyle(wb,sn,style = wrap_text_style, rows = 1,cols = 1:(ncol(h)), gridExpand = T,stack=T)
    addStyle(wb,sn,style = bbs, rows = 2,cols = c(3:6,8:11), gridExpand = T,stack=T)
    addStyle(wb,sn,style = bbs, rows = c(4,5,10,15,20),cols = 1:(ncol(h)), gridExpand = T,stack=T)
    addStyle(wb,sn,style = tbs, rows = 2,cols = 1:(ncol(h)), gridExpand = T,stack=T)
    addStyle(wb,sn,style = lbs, rows = (nrow(h)+2),cols = 1:(ncol(h)), gridExpand = T,stack=T) 
  }
}

sn_list = c("Table 4","Table S.9","Table S.14")
estn = c("TMG-TE","GP")
nstat = 3 # bias, RMSE, size
for (j in 3) {
  sn = sn_list[j]
  addWorksheet(wb, sn)
  
  if (j==1) {
    temp1 = "TMG-TE_te1_norm_tex0_arx_hetrosk1_308.RData"
    en = 1; temp1 = tryCatch(load(fn1),error=function(e) print(en))
    ar_x=1 ; gauss_y=0; corr_e=0; te=1; te_x=0; dist_x = 1; case = 3
    writeData(wb, sn, x = "Table 4: Bias, RMSE and size of TMG-TE and GP estimators of the time effects, phi_1 and phi_2, in the baseline model with correlated heterogeneity, rho_{beta}=0.5", startCol = 1, startRow = 1, colNames = FALSE)
  }
  if (j==2) {
    temp1 = "TMG-TE_te1_norm_tex0_arx_hetrosk1_408.RData"
    en = 1; temp1 = tryCatch(load(fn1),error=function(e) print(en))
    ar_x=1 ; gauss_y=0; corr_e=0; te=1; te_x=0; dist_x = 1; case = 4
    writeData(wb, sn, x = "Table S.9: Bias, RMSE and size of TMG-TE and GP estimators of the time effects, phi_1 and phi_2, in panel data models with correlated heterogeneity, rho_{beta}=0.5, and the level of overall fit, PR^2=0.4", startCol = 1, startRow = 1, colNames = FALSE)
  }
  if (j==3) {
    temp1 = "TMG-TE_te1_norm_tex2_arx_hetrosk1_308.RData"
    en = 1; temp1 = tryCatch(load(fn1),error=function(e) print(en))
    ar_x=1 ; gauss_y=0; corr_e=0; te=1; te_x=2; dist_x = 1; case = 3
    writeData(wb, sn, x = "Table S.14: Bias, RMSE and size of TMG-TE and GP estimators of the time effects, phi_1 and phi_2, in panel data models with correlated heterogeneity, rho_{beta}=0.5, and interactive effects in the x_{it} equation", startCol = 1, startRow = 1, colNames = FALSE)
  }
  
  if (temp1[1]!=1) {
    writeData(wb, sn, x = "n=1,000", startCol = 4, startRow = 2, colNames = FALSE)
    writeData(wb, sn, x = "n=5,000", startCol = 8, startRow = 2, colNames = FALSE)
    
    ################################################################################
    Nlist = c(1000,5000)
    Tlist = c(2,3)
    
    nest = 2 
    panel_nrow = nest*3
    panel_ncol = 3*length(Nlist) 
    ################################################################################
    
    #### Generate Table with empty entries
    tab = matrix(,panel_nrow,panel_ncol) 
    #### the respective rows of estimation results
    id_list = c(6,4)
    
    for (nid in 1:length(Nlist)) {
      nobs = Nlist[nid]
      colid = c(1:3)+(nid-1)*3
      
      ## for T=2 and T=3
      for (idx in c(1,2)) {
        Tobs = Tlist[idx]
        name1 = paste("te",dist_x,sep="_d")
        name3 = paste(name1,case,sep="c")
        name4 = paste(name3,nobs,sep="_n")
        name5 = paste(name4,Tobs,sep="_T")
        en = 1
        temp = tryCatch(get(name5),error=function(e) print(en))
        if (is.list(temp)==1 ){
          for (tee in 1:(Tobs-1)) {
            tab[(1:2)+(tee-1)*nest+(idx-1)*2,colid]=temp$stat[tee+(id_list-1)*(Tobs),c(4,5,7)]
          }
        }
      }
      
      ## format data
      bias_0 = tab[,c(1,4)]
      bias_1 = bias_0
      for (i in 1:length(bias_0)) {
        if (is.na(bias_0[i]) == 0) {
          bias_1[i] = format(round(bias_0[i], 3), nsmall = 3) #round(bias_0[i],digits=3)
        } 
      }
      rmse_0 = tab[,c(2,5)]
      rmse_1 = rmse_0
      for (i in 1:length(rmse_0)) {
        if (is.na(rmse_0[i]) == 0) {
          rmse_1[i] = format(round(rmse_0[i], 2), nsmall = 2) #round(rmse_0[i],digits=3)
        } 
      }
      size_0 = tab[,c(3,6)]
      size_1 = size_0
      for (i in 1:length(size_0)) {
        if (is.na(size_0[i]) == 0) {
          size_1[i] = format(round(size_0[i]*100, 1), nsmall = 1)
        }
      }
    }
    
    #######################
    tab = matrix(rbind(bias_1,rmse_1,size_1),6,6)
    ####################### 
    
    row1 = matrix(c("phi_{1}=1","","phi_{1}=1","","phi_{2}=2",""),6,1)
    row2 = rep(estn,3)
    tab0 = cbind(row1,row2,matrix("",6,1),tab[,1:3],matrix("",6,1),tab[,4:6])
    nrv = matrix("",1,ncol(tab0))
    
    h1 = c("","Estimator","","Bias","RMSE","Size (*100)","","Bias","RMSE","Size (*100)")
    h2 = c("","","","T=2","","","","T=3","","")
    h = rbind(h1,h2,tab0[1:2,],h2,tab0[3:6,])
    rownames(h) <- NULL
    colnames(h) <- NULL
    writeData(wb,sn, x = h, startCol = 1, startRow = 3,colNames = FALSE, rowNames = FALSE)
    mergeCells(wb, sheet = sn, cols = 1:10, rows = 1)
    mergeCells(wb, sheet = sn, cols = 4:6, rows = 4)
    mergeCells(wb, sheet = sn, cols = 8:10, rows = 4)
    mergeCells(wb, sheet = sn, cols = 4:6, rows = 7)
    mergeCells(wb, sheet = sn, cols = 8:10, rows = 7)
    
    addStyle(wb,sn,style = center_style, rows = c(2:4,7),cols = 1:(ncol(h)), gridExpand = T)
    addStyle(wb,sn,style = right, rows = c(5:6,8:11),cols = 3:(ncol(h)), gridExpand = T)
    addStyle(wb,sn,style = left, rows = 1:11,cols = 1:2, gridExpand = T)
    addStyle(wb,sn,style = wrap_text_style, rows = 1,cols = 1:(ncol(h)), gridExpand = T,stack=T)
    addStyle(wb,sn,style = bbs, rows = 2,cols = c(4:6,8:10), gridExpand = T,stack=T)
    addStyle(wb,sn,style = bbs, rows = 3,cols = 1:(ncol(h)), gridExpand = T,stack=T)
    addStyle(wb,sn,style = bbs, rows = 4,cols = c(1:6,8:10), gridExpand = T,stack=T)  
    addStyle(wb,sn,style = bbs, rows = 7,cols = c(1:6,8:10), gridExpand = T,stack=T)  
    addStyle(wb,sn,style = tbs, rows = 2,cols = 1:(ncol(h)), gridExpand = T,stack=T)
    addStyle(wb,sn,style = lbs, rows = (nrow(h)+2),cols = 1:(ncol(h)), gridExpand = T,stack=T) 
  }
}
##############################################################################


# Save the workbook to an Excel file
saveWorkbook(wb, file = "TMG_MC_results_supp_4.xlsx",overwrite = TRUE)

cat("MC Results of estimation have been written to the excel file TMG_MC_results_supp_4.xlsx.")

rm(list=ls())

list.of.packages <- c("sm")
new.packages <- list.of.packages[!(list.of.packages %in% installed.packages()[,"Package"])]
if(length(new.packages)) install.packages(new.packages)
library(sm)

## Figures S.6-S.8: Compare TMG-TE, TMG-C, GP and SU
##############################################################################################################
rm(list=ls())
fn1 = "TMG-TE_te1_norm_tex2_arx_hetrosk1_308.RData"
en = 1; temp2 = tryCatch(load(fn1),error=function(e) print(en))
ar_x=1 ; gauss_y=0; corr_e=0; te=1; te_x=2; dist_x = 1; case = 3; 
k = 2;
panel_nrow = 4; panel_ncol = 2
panel_id = seq(1,panel_nrow*panel_ncol,by=1)
pidx = matrix(c(0,1,1,0,2,1),3,k) # alpha,beta
nll = c(1000,2000,5000,10000)

if (temp2[1] != 1) {
  #### Figure panel formats: ns by 1 for comparing TMG, GP and SU given a NT combo
  tt = rep(c(2,3),4)
  nn = matrix(rbind(nll,nll),8,1)
  cc = rep(case,8)
  
  kidx = matrix(c(0,1,1,0,2,1),3,2) # alpha,beta
  phi_1 = rep(1,Tobs-1)
  phi_te = c(phi_1,-sum(phi_1))
  teidx = t(matrix(c(rep(1,Tobs-1),seq(1,Tobs-1,by=1),phi_te[1:(Tobs-1)]),Tobs-1,3))
  pidx = cbind(kidx,teidx)
  ###############################################################################
  
  for (idx in 2:3) {
    tej = pidx[1,idx] ## results of phi: tej=1; results of E(theta_i): tej=0
    j = pidx[2,idx] ## for regressor j
    
    #### Set names of figures
    #################################
    if (idx==2) {
      name1 = "Figure S.6"
    }
    if (idx==3) {
      name1 = "Figure S.7"
    }
    pngname = paste(name1,".png",sep = "")
    #################################
    
    #### Set width and height, no. of panels of plots
    #################################
    png(pngname, units="in", width=36, height=38, res=50) # (2 by 2) T=2
    par(mai=c(1.5,1.2,2,1.2),xpd=TRUE, mfrow=c(panel_nrow,panel_ncol),omi=c(1.8,0.5,0.8,0.5),family="Times New Roman") # (b,l,t,r)
    #################################
    
    p = 1
    for (p in panel_id) {
      nobs = nn[p]
      Tobs = tt[p]
      case = cc[p]
      
      #### Set legends
      #################################
      if (tej==0) {
        le_1 = "TMG-TE"
        le_2 = "GP" 
        le_3 = "SU"  
        le_4 = "TMG-C"  
        id_list = c(6,4,5,7)
        le = c(le_1,le_2,le_3,le_4)
      }
      if (tej>0) {
        le_1 = "TMG-TE"
        le_2 = "GP" 
        le = c(le_1,le_2)
        id_list = c(6,4)
      }
      #################################
      
      #### Set axes
      #################################
      truev = pidx[3,idx] ## true value of a parameter
      pwlb=-2.5; pwrb=2.5; pwintv=0.01;
      pwgrid = length(as.matrix(seq(as.numeric(truev+pwlb),as.numeric(truev+pwrb),by=pwintv)))
      mx = seq(truev+pwlb,truev+pwrb,by=pwintv)
      if (Tobs==2) {
        lb = which(mx-truev+1.4==0) 
        ub = length(mx)-lb+1 #which(mx-truev-1.2==0) 
      }
      if (Tobs==3) {
        lb = which(mx-truev+1.4==0) 
        ub = length(mx)-lb+1 #which(mx-truev-1.2==0) 
      }
      xmin = round(mx[lb],digits=2)
      xmax = round(mx[ub],digits=2)
      ymin = 0
      ymax = 1
      #################################
      
      #### Load results
      #################################
      k=2
      if (tej==0) {
        name1 = paste("theta",dist_x,sep="_d")
      }
      if (tej==1) {
        name1 = paste("te",dist_x,sep="_d")
      }
      name2 = paste(name1,case,sep="c")
      name4 = paste(name2,nobs,sep="_n")
      name5 = paste(name4,Tobs,sep="_T")
      en = 1
      temp = tryCatch(get(name5),error=function(e) print(en))
      if (is.list(temp)==1 ){
        pw1 = temp$pw[,(id_list*k-k+j)]; print(id_list*k-k+j)
      }
      pw_temp = pw1
      #################################
      
      #### Add panels' names 
      #################################
      if (p==1) {
        main_1 = "T=2"
      }
      if (p==2) {
        main_1 = "T=3"
      }
      #################################
      
      #### Plot curves
      #################################
      if (p %in% c(1,2)) { # (b,l,t,r)
        par(mar=c(13,10,12,10))
      }
      if (p %in% c(3,4)) {
        par(mar=c(13,10,13,10))
      }
      if (p %in% c(5,6)) {
        par(mar=c(13,10,13,10))
      }
      if (p %in% c(7,8)) {
        par(mar=c(14,10,12,10))
      }
      plot(mx[lb:ub],pw_temp[lb:ub,1],type="l",col=1,lwd=5.5,lty=1,xlim=c(xmin,xmax),ylim=c(ymin,ymax),xaxs="i",yaxs="i",axes=F,ylab="",xlab="")
      lines(mx[lb:ub],pw_temp[lb:ub,2],type="l",col=4,lwd=5.5,lty=5,xlim=c(xmin,xmax),ylim=c(ymin,ymax))
      if (p %in% c(1,2)) {
        mtext(main_1, side = 1, line = -53, at = 1 , cex = 5)
      }
      if (dim(pw_temp)[2]>2 & tej==0) {
        if (Tobs==2) {
          lines(mx[lb:ub],pw_temp[lb:ub,3], type="l", col=2, lwd=5.5,lty=4,xlim=c(xmin, xmax), ylim=c(ymin, ymax))
        }
        if (Tobs==3) {
          lines(mx[lb:ub],pw_temp[lb:ub,4], type="l", col=3, lwd=5.5,lty=3,xlim=c(xmin, xmax), ylim=c(ymin, ymax))
        }
      }
      axis(side=1, at=seq(xmin, xmax, by=0.2), mgp=c(1.8, 3, 0), cex.axis=3.8)
      axis(side=2, at=seq(0, 1, by=0.2), mgp=c(3, 2, 0), cex.axis=3.8)######## Visualization
      arrows(truev,-0.01, truev, 1, length = 0,lty = 3,lwd=3.5) # denote the true value
      arrows(xmin,0.05,xmax,0.05, length = 0,lty = 3, lwd=3) # denote a line of 5% probability
      if (tej==0) {
        if (j==1) {
          mtext(expression(alpha), side = 1, line = 7, at = xmax, cex = 3)
        }
        if (j==2) {
          mtext(expression(beta), side = 1, line = 7, at = xmax, cex = 3)
        }
      }
      if (tej==1) {
        if (j==1) {
          mtext(expression(phi[1]), side = 1, line = 7, at = xmax, cex = 3)
        }
      }
      mtext("Power", side = 2, line = 5.2, at = 0.94 , cex = 3)
      mtext("5%", side = 1, line = -3, at = 2.48 , cex = 2.5)
      box(col="black")
      #################################
    } ## end p (1 to NT) different panels in one figure
    
    mtext("n=1,000", side = 3, cex = 4, font = 1,
          line = -6,
          outer = TRUE)
    
    mtext("n=2,000", side = 3, cex = 4, font = 1,
          line = -73,
          outer = TRUE)
    
    mtext("n=5,000", side = 3, cex = 4, font = 1,
          line = -140,
          outer = TRUE)
    
    mtext("n=10,000", side = 3, cex = 4, font = 1,
          line = -207,
          outer = TRUE)
    
    par(fig = c(0, 1, 0, 1), oma = c(1, 0, 0, 0), mar = c(0, 0, 0, 0), new = TRUE)
    plot(0, 0, type = 'l', bty = 'n', xaxt = 'n', yaxt = 'n')
    
    legend("bottom",col=c(1,4,2,3),lwd=4,lty=c(1,5,4,3),legend=le,cex=6.5,xpd=TRUE,horiz=TRUE) #bty="n"
    
    dev.off()
  }
  
  
  #### Figure of phi_2
  #################################
  j=2
  name1 = "Figure S.8"
  pngname = paste(name1,".png",sep = "")
  #################################
  
  #### Set width and height, no. of panels of plots
  #################################
  png(pngname, units="in", width=36/2, height=38, res=50) # (2 by 2) T=2
  par(mai=c(1.5,1.2,2,1.2),xpd=TRUE, mfrow=c(panel_nrow,panel_ncol/2),omi=c(1.8,0.5,0.8,0.5),family="Times New Roman") # (b,l,t,r)
  #################################
  
  p = 1
  for (p in panel_id[c(2,4,6,8)]) {
    nobs = nn[p]
    Tobs = tt[p]
    case = cc[p]
    
    #### Set legends
    #################################
    le_1 = "TMG-TE"
    le_2 = "GP" 
    le = c(le_1,le_2)
    id_list = c(6,4)
    #################################
    
    #### Set axes
    #################################
    truev = 2 ## true value of a parameter
    pwlb=-2.5; pwrb=2.5; pwintv=0.01;
    pwgrid = length(as.matrix(seq(as.numeric(truev+pwlb),as.numeric(truev+pwrb),by=pwintv)))
    mx = seq(truev+pwlb,truev+pwrb,by=pwintv)
    lb = which(mx-truev+1.4==0) 
    ub = length(mx)-lb+1 #which(mx-truev-1.2==0) 
    xmin = round(mx[lb],digits=2)
    xmax = round(mx[ub],digits=2)
    ymin = 0
    ymax = 1
    #################################
    
    #### Set k = dimension of theta or phi
    #################################
    if (tej==0) {
      k = 2
    }
    if (tej==1) {
      k= Tobs
    }
    #################################
    
    #### Load results
    #################################
    name1 = paste("te",dist_x,sep="_d")
    name2 = paste(name1,case,sep="c")
    name4 = paste(name2,nobs,sep="_n")
    name5 = paste(name4,Tobs,sep="_T")
    en = 1
    temp = tryCatch(get(name5),error=function(e) print(en))
    if (is.list(temp)==1 ){
      pw1 = temp$pw[,(id_list*k-k+j)]; print(id_list*k-k+j)
    }
    pw_temp = pw1
    #################################
    
    
    #### Plot curves
    #################################
    if (p %in% c(5,6)) {
      par(mar=c(12,10,12,10)) # (b,l,t,r)
    }
    if (p %in% c(7,8)) {
      par(mar=c(14,10,12,10))
    }
    plot(mx[lb:ub],pw_temp[lb:ub,1],type="l",col=1,lwd=5.5,lty=1,xlim=c(xmin,xmax),ylim=c(ymin,ymax),xaxs="i",yaxs="i",axes=F,ylab="",xlab="")
    lines(mx[lb:ub],pw_temp[lb:ub,2],type="l",col=4,lwd=5.5,lty=5,xlim=c(xmin,xmax),ylim=c(ymin,ymax))
    if (dim(pw_temp)[2]>2 & tej==0 & Tobs==2) {
      if (te==0) {
        lines(mx[lb:ub],pw_temp[lb:ub,3], type="l", col=2, lwd=5.5,lty=4,xlim=c(xmin, xmax), ylim=c(ymin, ymax))
      }
      if (te>0) {
        lines(mx[lb:ub],pw_temp[lb:ub,3], type="l", col=2, lwd=5.5,lty=4,xlim=c(xmin, xmax), ylim=c(ymin, ymax))
      }
    }
    axis(side=1, at=seq(xmin, xmax, by=0.2), mgp=c(1.8, 3, 0), cex.axis=3.8)
    axis(side=2, at=seq(0, 1, by=0.2), mgp=c(3, 2, 0), cex.axis=3.8)######## Visualization
    arrows(truev,-0.01, truev, 1, length = 0,lty = 3,lwd=3.5) # denote the true value
    arrows(xmin,0.05,xmax,0.05, length = 0,lty = 3, lwd=3) # denote a line of 5% probability
    if (tej==1) {
      if (j==2) {
        mtext(expression(phi[2]), side = 1, line = 7, at = xmax, cex = 3)
      }
    }
    mtext("Power", side = 2, line = 5.2, at = 0.94 , cex = 3)
    mtext("5%", side = 1, line = -3, at = 2.48 , cex = 2.5)
    box(col="black")
    #################################
  } ## end p (1 to NT) different panels in one figure
  
  mtext("n=1,000", side = 3, cex = 4, font = 1,
        line = -6,
        outer = TRUE)
  
  mtext("n=2,000", side = 3, cex = 4, font = 1,
        line = -73,
        outer = TRUE)
  
  mtext("n=5,000", side = 3, cex = 4, font = 1,
        line = -140,
        outer = TRUE)
  
  mtext("n=10,000", side = 3, cex = 4, font = 1,
        line = -207,
        outer = TRUE)
  
  par(fig = c(0, 1, 0, 1), oma = c(1, 0, 0, 0), mar = c(0, 0, 0, 0), new = TRUE)
  plot(0, 0, type = 'l', bty = 'n', xaxt = 'n', yaxt = 'n')
  legend("bottom",col=c(1,4),lwd=4,lty=c(1,5),legend=le,cex=6.5,xpd=TRUE,horiz=TRUE) #bty="n"
  dev.off()
}
##############################################################################################################











rm(list=ls())
load("simukappa2.RData")

list.of.packages <- c("parallel", "MASS","openxlsx")
new.packages <- list.of.packages[!(list.of.packages %in% installed.packages()[,"Package"])]
if(length(new.packages)) install.packages(new.packages)
library(parallel)
library(MASS)
library(openxlsx)


################################################################################
### Define Functions Calculate Statistics: (Bias, RMSE, T_test & Power, Coverage)
################################################################################
Bias = function(ests,truev) {
  ests = as.matrix(ests)
  truematrix = matrix(truev,nrow=nrow(ests),ncol=ncol(ests))
  colMeans(ests - truematrix)
}

Rmse = function(ests,truev) {
  ests = as.matrix(ests)
  truematrix = matrix(truev,nrow=nrow(ests),ncol=ncol(ests))
  sqrt(colMeans((ests - truematrix)^2))
}

T_test = function(truev,estsd,rep){
  ests = as.matrix(estsd[1:rep])
  sds = as.matrix(estsd[(rep+1):(2*rep)])
  truematrix = matrix(truev,nrow=nrow(ests),ncol=ncol(ests))
  colMeans(abs((ests-truematrix)/sds)>qnorm(p = 0.975))
}

pwlb=-2.5; pwrb=2.5; pwintv=0.01;
pwgrid = length(as.matrix(seq(as.numeric(0+pwlb),as.numeric(0+pwrb),by=pwintv)))
Power = function(truev,estsd,rep){
  h1 = as.matrix(seq(as.numeric(truev+pwlb),as.numeric(truev+pwrb),by=pwintv)) # values of alternatives (v0-0.5,v0+0.5) length = 101
  powers = sapply(h1,function(x) T_test(x,estsd,rep))
  powers
}

Coverage = function(truev,estsd,rep){
  ests = as.matrix(estsd[1:rep])
  sds = as.matrix(estsd[(rep+1):(2*rep)])
  truem = matrix(truev,nrow=nrow(ests),ncol=ncol(ests))
  cvr = abs(truem - ests) < qnorm(0.975,0,1)*sds # within the 95% CI excluding 2.5% from each tail
  mean(cvr)
}


################################################################################
### Define Functions of Estimation: 
### GP: (Minor, Cofactor, Adjoint1, Dw_i, Det_i, GPedn_i, GPuu_i, GP_est)
### SU: (SUN_est_l, SU_est_l, SU_est) 
### TMG, TMG-TE and TMG-C:
### (Minor, Cofactor, Adjoint1, Det_i, TOLS_i, Qw_i, MTxy_i, MTuu_i, Phiuu_i, TMG_an, TMG_TE_an, TMG_est)
################################################################################

################################################################################
######  GP estimator 
#### (Minor, Cofactor, Adjoint1, Dw_i, Det_i, GPedn_i, GPuu_i, GP_est)
################################################################################
# T=k calcualte the determinant of regressors 
Dw_i = function(paneldata_w,nobs,Tobs,k,id) {
  wi = matrix(paneldata_w[(1+(id-1)*Tobs):(id*Tobs),],Tobs,k)  # (T by k) with T=K
  dwi = det(wi) 
  dwi
}

# GP: calculate denomiator and numerator for estimators of both time effects and hetero coeff 
GPedn_i = function(panel_int,trim_n,nobs,Tobs,k,hn,te,id){
  obsi = as.matrix(panel_int[(1+(id-1)*Tobs):(id*Tobs),]) # paneldata = {(yi,xi)} (nT by k+1) matrix
  yi = as.matrix(obsi[,1]) # yi (T by 1)
  wi = as.matrix(obsi[,2:(k+1)]) # wi (T by k) 
  trimi = trim_n[id] # index of trimming: 1 trim
  
  # no time effects
  if (te==0 ){
    dwinv_i = matrix(0,Tobs,k) # (T by k)
    if (trimi==0) {
      dwinv_i = wi %*% solve( t(wi) %*% wi )
    }
    qi = (1-trimi)*dwinv_i # (T by k)
    ri = (1-trimi)*wi# (T by k)
    qri = t(qi) %*% ri # k by k
    qyi = t(qi) %*% yi # k by 1
  }
  
  # with time effects
  if (te>0) {
    # ts=1 (intercepts) or ts=k (all coefficients)
    if (te == 1) {
      v0 = matrix(0,1,(Tobs-1)) # 1 by (T-1)
      z0 = diag(1,(Tobs-1)) # (T-1) by (T-1)
      zi = rbind(v0,z0) # a common intercept shift (T by T-1)
    } else {
      zi = matrix(0,Tobs,((Tobs-1)*k)) # time shifters (T by (T-1)k)
      for (idx in 2:Tobs) {
        zi[idx, (1+k*(idx-2)):(k+k*(idx-2))] = wi[idx,]
      }
    }
    
    # irregular estimator of time effects with T=k
    if (Tobs==k) {
      wzi = Adjoint1(wi) %*% zi
      winv_i = matrix(0,Tobs,k) 
      if (trimi==0) {
        winv_i = 1/det(wi)*diag(1,k)
      }
      qi = cbind(trimi/hn*wzi,(1-trimi)*winv_i) # (T by (Tobs-1)k+k)
      ri = cbind(wzi,(1-trimi)*det(wi)*diag(1,k)) # (T by (Tobs-1)k+k)
      qri = t(qi) %*% ri # (Tobs-1)k+k by (Tobs-1)*k+k
      qyi = t(qi) %*% Adjoint1(wi) %*% yi # (Tobs-1)*k+k by 1
    }
    
    # regular estimator of time effects with T=k
    if (Tobs>k) {
      mwi = diag(1,Tobs)- wi %*% solve(t(wi) %*% wi) %*% t(wi) # T by T
      mwzi = mwi %*% zi # T by (T-1)k
      wwinv_i = matrix(0,k,k) 
      if (trimi==0) {
        wwinv_i = solve(t(wi) %*% wi)
      }
      qi = cbind(mwzi,(1-trimi)*wi %*% wwinv_i)
      ri = cbind(zi,(1-trimi)*wi)
      qri = t(qi) %*% ri
      qyi = t(qi) %*% yi # (Tobs-1)*k+k by 1
    }
  }
  cbind(qri,qyi) # k by (k+1)
}

# GP: calculate asymptotic variance for each i
GPuu_i = function(panel_int,trim_n,nobs,Tobs,k,hn,te,gp_hat,id){
  obsi = as.matrix(panel_int[(1+(id-1)*Tobs):(id*Tobs),]) # paneldata = {(yi,xi)} (nT by k+1) matrix
  yi = as.matrix(obsi[,1]) # yi (T by 1)
  wi = as.matrix(obsi[,2:(k+1)]) # wi (T by k) 
  trimi = trim_n[id] # index of trimming: 1=trim
  
  # no time effects
  ###########################
  if (te==0) {
    dwinv_i = matrix(0,Tobs,k) # (T by k)
    if (trimi==0) {
      dwinv_i = wi %*% solve( t(wi) %*% wi )
    }
    qi = (1-trimi)*dwinv_i # (T by k)
    ri = (1-trimi)*wi# (T by k)
    qri = t(qi) %*% ri # k by k
    qyi = t(qi) %*%  yi # k by 1
    uhat_i =  yi - ri %*% gp_hat
  }
  ###########################
  
  # with time effects
  if (te>0) {
    # construct Zi matrix: ts=1 (intercepts) or ts=k (all coefficients)
    ###########################
    if (te == 1) {
      v0 = matrix(0,1,(Tobs-1))
      z0 = diag(1,(Tobs-1))
      zi = rbind(v0,z0) # a common intercept shift (T by T-1)
    } else {
      zi = matrix(0,Tobs,((Tobs-1)*k)) # time shifters (T by (T-1)k)
      for (idx in 2:Tobs) {
        zi[idx, (1+k*(idx-2)):(k+k*(idx-2))] = wi[idx,]
      }
    }
    ###########################
    # irregular estimator by GP (2012)
    ###########################
    if (Tobs==k) {
      wzi = Adjoint1(wi) %*% zi
      winv_i = matrix(0,Tobs,k) 
      if (trimi==0) {
        winv_i = 1/det(wi)*diag(1,Tobs,k)
      }
      qi = cbind(trimi/hn*wzi,(1-trimi)*winv_i) # (T by (Tobs-1)k+k)
      ri = cbind(wzi,(1-trimi)*det(wi)*diag(1,Tobs,k)) # (T by (Tobs-1)k+k)
      uhat_i = Adjoint1(wi) %*% yi - ri %*% gp_hat
    } 
    ###########################
    # regular estimator by Chamberlain (1992)
    ###########################
    if (Tobs>k) {
      mwi = diag(1,Tobs)- wi %*% solve(t(wi) %*% wi) %*% t(wi)
      mwzi = mwi %*% zi # T by (T-1)k
      wwinv_i = matrix(0,k,k) 
      if (trimi==0) {
        wwinv_i = solve(t(wi) %*% wi)
      }
      qi = cbind(mwzi,(1-trimi)*wi%*% wwinv_i)
      ri = cbind(zi,(1-trimi)*wi)
      uhat_i = yi - ri %*% gp_hat
    }
    ###########################
  }
  uui = (t(qi) %*% uhat_i) %*% t((t(qi) %*% uhat_i)) # (Tobs-1)k+k by (Tobs-1)k+k
  uui 
}

GP_est_l = function(paneldata,nobs,Tobs,k,agp,te){
  id_list = as.matrix(seq(1,nobs,by=1))
  int_nT_long = matrix(1,nobs*Tobs,1)
  paneldata_w = cbind(int_nT_long,paneldata[,2:k])
  panel_int = cbind(paneldata[,1],paneldata_w) # add intercepts
  dimte = 0*(te==0)+(Tobs-1)*(te==1)+(Tobs-1)*k*(te==((Tobs-1)*k))
  
  # GP (1) calculate di = det(Wi'Wi)
  det_n = sapply(id_list,Det_i,paneldata_w=paneldata_w,nobs=nobs,Tobs=Tobs,k=k) 
  
  ## GP (2) calculate the threshold and indexes of trimming
  if (Tobs==k) {
    dw_n = sapply(id_list,Dw_i,paneldata_w=paneldata_w,nobs=nobs,Tobs=Tobs,k=k) 
    sd_hat = sd(dw_n); qn_hat = IQR(dw_n)
    c = 1/2*min(sd_hat,qn_hat/1.34)
  } else {
    c = sqrt(mean(det_n))
  }
  hn = c*(nobs^(-agp))
  hn2 = hn^2
  trim_n = (det_n<=hn2)
  
  ## GP (3) calculate the numertor and denominator of GP estimators 
  gpedn_n = sapply(id_list,GPedn_i,panel_int=panel_int,trim_n=trim_n,nobs=nobs,Tobs=Tobs,k=k,hn=hn,te=te)
  # denominator: mean(Qi'Ri) lower-triangular matrix
  gped = matrix(rowMeans(gpedn_n[1:((dimte+k)^2),]),(dimte+k),(dimte+k)) # denominator
  # numerator: mean(Qi'yi)
  gpen = matrix(rowMeans(gpedn_n[(((dimte+k)^2)+1):(((dimte+k)^2)+(dimte+k)),]),(dimte+k),1) # numerator
  gp_hat = solve(gped) %*% gpen # (T-1+k)
  
  ## GP (4) calculate the asymptotic variance of the GP estimators 
  uu_n = sapply(id_list,GPuu_i,panel_int=panel_int,trim_n=trim_n,nobs=nobs,Tobs=Tobs,k=k,hn=hn,te=te,gp_hat=gp_hat)
  uu_hat = matrix(rowMeans(uu_n), (dimte+k),(dimte+k))
  avar_hat = 1/nobs*solve(gped) %*% uu_hat %*% t(solve(gped)) # (T-1+k) by (T-1+k) 
  
  ## report GP estimates after transformation between different normalizations of time effects
  if (te==0) {
    theta_hat = gp_hat
    theta_av = avar_hat
  }
  if (te==1) {
    vte1 = -1/Tobs+rbind(matrix(0,1,Tobs-1),diag(1,Tobs-1)) # T by (T-1) phi* to phi
    vte2 = matrix(0,Tobs,k) # (T by k) alpha* to phi (zeros)
    vte = cbind(vte1,vte2) # T by (T-1+k) matrix 
    va = matrix(c(rep(1/Tobs,Tobs-1),1,rep(0,k-1)),1,(Tobs-1+k)) # 1 by (T-1+k) vector
    vb = cbind(matrix(0,k-1,Tobs),diag(1,k-1)) # (k-1) by (T-1+k) matrix
    trm = rbind(vte,va,vb) # (T-1+k) by (T-1+k) matrix
    
    gp_hat2 = trm %*% gp_hat
    avar_hat2 = trm %*% avar_hat %*% t(trm)
    
    phi_hat = gp_hat2[1:Tobs]
    phi_av = avar_hat2[1:Tobs,1:Tobs]
    theta_hat = gp_hat2[(Tobs+1):(Tobs+k)]
    theta_av = avar_hat2[(Tobs+1):(Tobs+k),(Tobs+1):(Tobs+k)]
    phi_avar = diag(phi_av)
  }
  if (te>1) {
    idte = seq(1,Tobs-1,by=k)
    idw = c(((Tobs-1)*k+1):((Tobs-1)*k+k))
    id = c(idte,idw)
    gp_hat1 = as.matrix(gp_hat[id]) # phi*, E(theta_i)
    
    idm = expand.grid(id,id)
    avar_hat1 = matrix(,length(gp_hat1),length(gp_hat1))
    idx = seq(1,length(gp_hat1),by=1)
    idm1 = expand.grid(idx,idx)
    for (s in 1:dim(idm)[1]) {
      i = idm[s,2]; j = idm[s,1];
      temp = avar_hat[i,j]
      i1 = idm1[s,2]; j1 = idm1[s,1];
      avar_hat1[i1,j1] = temp; rm(temp)
    }
    
    vte1 = -1/Tobs+rbind(matrix(0,1,Tobs-1),diag(1,Tobs-1)) # T by (T-1) phi* to phi
    vte2 = matrix(0,Tobs,k) # (T by k) alpha* to phi (zeros)
    vte = cbind(vte1,vte2) # T by (T-1+k) matrix 
    va = matrix(c(rep(1/Tobs,Tobs-1),1,rep(0,k-1)),1,(Tobs-1+k)) # 1 by (T-1+k) vector
    vb = cbind(matrix(0,k-1,Tobs),diag(1,k-1)) # (k-1) by (T-1+k) matrix
    trm = rbind(vte,va,vb) # (T-1+k) by (T-1+k) matrix
    
    gp_hat2 = trm %*% gp_hat1
    avar_hat2 = trm %*% avar_hat1 %*% t(trm)
    
    phi_hat = gp_hat2
    phi_av = avar_hat
    theta_hat = gp_hat2[(Tobs+1):(Tobs+k)]
    theta_av = avar_hat2[(Tobs+1):(Tobs+k),(Tobs+1):(Tobs+k)]
    phi_avar = diag(phi_av)
  }
  
  theta_cov = theta_av[1,2:k]
  if (k > 2) {
    for (j in 2:(k-1)) {
      theta_cov = append(theta_cov,theta_av[j,(j+1):k])
    }
  }
  theta_avar = matrix(,1,(k+k*(k-1)/2))
  theta_avar[1,1:k] = diag(theta_av)
  theta_avar[1,(k+1):(k+k*(k-1)/2)] = theta_cov
  
  np = mean(trim_n) # trimmed portion
  
  if (te==0) {
    gp_output = as.matrix(cbind(np,t(theta_hat),theta_avar))
  }
  if (te>0) {
    gp_output = as.matrix(c(np,t(theta_hat),theta_avar,t(phi_hat),t(phi_avar))) 
  }
  gp_output
}

GP_est = function(paneldata,nobs,Tobs,k,agp_list,te){
  ll = length(agp_list)
  dimte = 0*(te==0)+ 1*(te==1) + (Tobs-1)*k*(te==((Tobs-1)*k))
  ptheta = (1+k+(k+k*(k-1)/2))
  pte = 2*Tobs
  dimte = Tobs
  # with no time effects
  if (te==0) {
    gp_list = sapply(agp_list,GP_est_l,paneldata=paneldata,nobs=nobs,Tobs=Tobs,k=k,te=te)
    gp_np = matrix(gp_list[1,],ll,1) # np: 1
    gp_ests = matrix(gp_list[2:(k+1),],k*ll,1)  # ests: k 
    gp_avar = matrix(gp_list[(k+2):(1+k+(k+k*(k-1)/2)),],(k+k*(k-1)/2)*ll,1)  # avar (k+corr): k + k*(k-1)/2
    gp_output = list(gp_np,gp_ests,gp_avar)
    names(gp_output) = c("np","ests","avar")
  }
  # with time effects: ## order of local polynomial regressor associated with rate of convergence
  if (te>0) {
    gp_list =sapply(agp_list,GP_est_l,paneldata=paneldata,nobs=nobs,Tobs=Tobs,k=k,te=te)
    gp_np = matrix(gp_list[1,],ll,1) # np: 1
    gp_ests = matrix(gp_list[2:(k+1),],k*ll,1)  # ests: k 
    gp_avar = matrix(gp_list[(k+2):ptheta,],(k+k*(k-1)/2)*ll,1)# avar (k+corr): k + k*(k-1)/2
    phite_ests = matrix(gp_list[(1+ptheta):(dimte+ptheta),],dimte*ll,1) # ests of time effects
    phite_avar = matrix(gp_list[(dimte+ptheta+1):(ptheta+pte),],(pte-dimte)*ll,1) # avar of time effects
    gp_output = list(gp_np,gp_ests,gp_avar,phite_ests,phite_avar)
    names(gp_output) = c("np","ests","avar","tests","tavar")
  }
  gp_output
}

###### Fin: GP estimator

################################################################################
######  SU (SUN_est_l, SU_est_l, SU_est) 
################################################################################
SUN_est_l = function(paneldata,nobs,Tobs,k,L){
  t=0 # time effects only in intercepts
  p = k
  N = nobs
  T = Tobs
  
  R = matrix(c(0,0,0,0),2,2)      # For t = 1 for Monte Carlo
  if( t == 2 ){
    R = diag(p)
  }
  paneldata_x = matrix(paneldata[,2],2,nobs)
  paneldata_y = matrix(paneldata[,1],2,nobs) 
  
  X1 = matrix(paneldata_x[1,],nobs,1)
  X2 = matrix(paneldata_x[2,],nobs,1)
  Y1 = matrix(paneldata_y[1,],nobs,1)
  Y2 = matrix(paneldata_y[2,],nobs,1)
  
  ################################################################
  # ADJOINT MATRIX FUNCTION
  ################################################################
  adjoint <- function(A){
    adjA = matrix(0,dim(A)[2],dim(A)[1])
    for( i in 1:(dim(A)[1]) ){
      for( j in 1:(dim(A)[2]) ){
        adjA[j,i] = (-1)^(i+j) * det(as.matrix(A[-i,-j]))
      }
    }
    return( adjA )
  }
  
  ################################################################
  # D, BOLD-FACE X, BOLD-FACE X*, BOLD-FACE X^{-1}, & BOLD-FACE W
  ################################################################
  i = 1
  D = det(rbind(cbind(1,X1[i,1]),cbind(1,X2[i,1])))
  bfX = list(rbind(cbind(1,X1[i,1]),cbind(1,X2[i,1])))
  bfXstr = list(adjoint(rbind(cbind(1,X1[i,1]),cbind(1,X2[i,1]))))
  bfXinv = list(ginv(rbind(cbind(1,X1[i,1]),cbind(1,X2[i,1]))))
  #bfW = list(rbind(0,cbind(1,X2[i,1])))
  bfW = list(rbind(0,cbind(0,0)))
  bfY = list(rbind(Y1[i,1],Y2[i,1]))
  for( i in 2:N ){
    D = c(D,det(rbind(cbind(1,X1[i,1]),cbind(1,X2[i,1]))))
    bfX[length(bfX)+1] = list(rbind(cbind(1,X1[i,1]),cbind(1,X2[i,1])))
    bfXstr[length(bfXstr)+1] = list(adjoint(rbind(cbind(1,X1[i,1]),cbind(1,X2[i,1]))))
    bfXinv[length(bfXinv)+1] = list(ginv(rbind(cbind(1,X1[i,1]),cbind(1,X2[i,1]))))
    bfW[length(bfW)+1] = list(rbind(0,cbind(0,0))) #list(rbind(0,cbind(1,X2[i,1])))
    bfY[length(bfY)+1] = list(rbind(Y1[i,1],Y2[i,1]))
  }
  
  ################################################################
  # h AND b (GRAHAM & POWELL, 2012, PAGE 2138)
  ################################################################
  h = min(c(sd(D), (quantile(D,0.75)-quantile(D,0.25))/1.34 )) / N^(1/(2*L+1)) / 2
  
  ################################################################
  # h_hat, e1, D0L, D1L
  ################################################################
  i = 1
  h_hat = (abs(D[i])<=h)*matrix(D[i]^(0:(L-1)),L,1) / N
  e1 = matrix(c(1, array(0,L)),L+1,1)
  D0L = list((abs(D[i])<=h)*matrix(D[i]^(0:L),L+1,1))
  D1L = list((abs(D[i])<=h)*matrix(D[i]^(1:L),L,1))
  for(i in 2:N){
    h_hat = h_hat + (abs(D[i])<=h)*matrix(D[i]^(0:(L-1)),L,1) / N
    D0L[length(D0L)+1] = list((abs(D[i])<=h)*matrix(D[i]^(0:L),L+1,1))
    D1L[length(D1L)+1] = list((abs(D[i])<=h)*matrix(D[i]^(1:L),L,1))
  }
  
  ################################################################
  # ESTIMATE DELTA
  ################################################################
  END0LD0L = 0                                     # E_N[D0L D0L']
  for( i in 1:N ){
    D0Li = matrix(unlist(D0L[i]),L+1,1)
    END0LD0L = END0LD0L + D0Li%*%t(D0Li) / N
  }
  
  denominator = 0
  numerator = 0
  for( i in 1:N ){
    D0Li = matrix(unlist(D0L[i]),L+1,1)
    XstrWi = matrix(unlist(bfXstr[i]),T,p)%*%matrix(unlist(bfW[i]),T,(T-1)*p)
    XstrYi = matrix(unlist(bfXstr[i]),T,p)%*%matrix(unlist(bfY[i]),T,1)
    denominator = denominator + as.numeric(t(D0Li)%*%ginv(END0LD0L)%*%e1) * t(XstrWi) %*% XstrWi / N
    numerator   = numerator   + as.numeric(t(D0Li)%*%ginv(END0LD0L)%*%e1) * t(XstrWi) %*% XstrYi / N
  }
  delta_hat = ginv(denominator)%*%numerator
  
  ################################################################
  # ESTIMATE GAMMA
  ################################################################
  END1LD1L = 0                                     # E_N[D1L D1L']
  for( i in 1:N ){
    D1Li = matrix(unlist(D1L[i]),L,1)
    END1LD1L = END1LD1L + D1Li%*%t(D1Li) / N
  }
  
  gamma_hat = 0
  for( i in 1:N ){
    D1Li = matrix(unlist(D1L[i]),L,1)
    XstrWi = matrix(unlist(bfXstr[i]),T,p)%*%matrix(unlist(bfW[i]),T,(T-1)*p)
    XstrYi = matrix(unlist(bfXstr[i]),T,p)%*%matrix(unlist(bfY[i]),T,1)
    gamma_hat = gamma_hat + (XstrYi - XstrWi %*% delta_hat) %*% t(D1Li) / N
  }
  gamma_hat = gamma_hat %*% ginv(END1LD1L)
  
  ################################################################
  # ESTIMATE BETA_L
  ################################################################
  beta_M_hat_numerator = 0
  for( i in 1:N ){
    XstrWi = matrix(unlist(bfXstr[i]),T,p)%*%matrix(unlist(bfW[i]),T,(T-1)*p)
    XstrYi = matrix(unlist(bfXstr[i]),T,p)%*%matrix(unlist(bfY[i]),T,1)
    if( abs(D[i])>h ){
      beta_M_hat_numerator = beta_M_hat_numerator + (abs(D[i])>h)*(1/D[i])*(XstrYi - XstrWi %*% delta_hat) / N
    }
  }
  beta_M_hat_denominator = mean((abs(D)>h))
  
  beta_M_hat = beta_M_hat_numerator * beta_M_hat_denominator^(-1)
  beta_L_hat = beta_M_hat_numerator + gamma_hat %*% h_hat
  
  ################################################################
  # ESTIMATE THETA
  ################################################################
  theta_L_hat = beta_L_hat + R%*%delta_hat
  theta_M_hat = beta_M_hat + R%*%delta_hat
  
  ################################################################
  # COMPUTE V_hat
  ################################################################
  V_hat = 0
  for( i in 1:N ){
    D0Li = matrix(unlist(D0L[i]),L+1,1)
    XstrWi = matrix(unlist(bfXstr[i]),T,p)%*%matrix(unlist(bfW[i]),T,(T-1)*p)
    V_hat = V_hat + as.numeric(t(D0Li)%*%ginv(END0LD0L)%*%e1) * t(XstrWi)%*%XstrWi / N
  }
  
  ################################################################
  # COMPUTE Q_hat
  ################################################################
  Q_hat = 0
  for( i in 1:N ){
    D1Li = matrix(unlist(D1L[i]),L,1)
    XstrWi = matrix(unlist(bfXstr[i]),T,p)%*%matrix(unlist(bfW[i]),T,(T-1)*p)
    if( abs(D[i])>h ){
      Q_hat = Q_hat + as.numeric( (abs(D[i])>h)/D[i] + t(D1Li)%*%ginv(END1LD1L)%*%h_hat ) * XstrWi / N
    }
  }
  
  ################################################################
  # COMPUTE zeta_hat (1ST TERM)
  ################################################################
  zeta_hat_1 = NULL
  for(i in 1:N){
    XstrWi = matrix(unlist(bfXstr[i]),T,p)%*%matrix(unlist(bfW[i]),T,(T-1)*p)
    XstrYi = matrix(unlist(bfXstr[i]),T,p)%*%matrix(unlist(bfY[i]),T,1)
    if( abs(D[i])>h ){
      zeta_hat_1 = cbind(zeta_hat_1, (abs(D[i])>h)/D[i] * (XstrYi - XstrWi%*%delta_hat))
    }else{
      zeta_hat_1 = cbind(zeta_hat_1, matrix(0,p,1) )
    }
  }
  zeta_hat_1 = zeta_hat_1 - matrix(rowMeans(zeta_hat_1),p,N)
  
  ################################################################
  # COMPUTE zeta_hat (2ND TERM)
  ################################################################
  zeta_hat_2 = NULL
  for(i in 1:N){
    D1Li = matrix(unlist(D1L[i]),L,1)
    XstrWi = matrix(unlist(bfXstr[i]),T,p)%*%matrix(unlist(bfW[i]),T,(T-1)*p)
    XstrYi = matrix(unlist(bfXstr[i]),T,p)%*%matrix(unlist(bfY[i]),T,1)
    zeta_hat_2 = cbind(zeta_hat_2, ((XstrYi-XstrWi%*%delta_hat) - gamma_hat%*%D1Li) %*% t(D1Li) %*% ginv(END1LD1L) %*% h_hat)
  }
  
  ################################################################
  # COMPUTE zeta_hat (3RD TERM)
  ################################################################
  zeta_hat_3R = NULL
  zeta_hat_3Q = NULL
  for(i in 1:N){
    D0Li = matrix(unlist(D0L[i]),L+1,1)
    XstrWi = matrix(unlist(bfXstr[i]),T,p)%*%matrix(unlist(bfW[i]),T,(T-1)*p)
    XstrYi = matrix(unlist(bfXstr[i]),T,p)%*%matrix(unlist(bfY[i]),T,1)
    zeta_hat_3R = cbind(zeta_hat_3R, as.numeric(t(D0Li)%*%ginv(END0LD0L)%*%e1) * R%*%ginv(V_hat)%*%t(XstrWi)%*%(XstrYi-XstrWi%*%delta_hat))
    zeta_hat_3Q = cbind(zeta_hat_3Q, as.numeric(t(D0Li)%*%ginv(END0LD0L)%*%e1) * Q_hat%*%ginv(V_hat)%*%t(XstrWi)%*%(XstrYi-XstrWi%*%delta_hat))
  }
  
  ################################################################
  # COMPUTE zeta_hat (ALL TOGETHER)
  ################################################################
  zeta_hat_M = zeta_hat_1 + zeta_hat_3R
  zeta_hat_L = zeta_hat_1 + zeta_hat_2 + zeta_hat_3R - zeta_hat_3Q
  rm(zeta_hat_1); rm(zeta_hat_2); rm(zeta_hat_3R); rm(zeta_hat_3Q); gc();
  
  ################################################################
  # VARIANCE AND SD
  ################################################################
  VAR_theta_M = zeta_hat_M %*% t(zeta_hat_M) / N
  VAR_theta_L = zeta_hat_L %*% t(zeta_hat_L) / N
  #rm(zeta_hat); 
  rm(zeta_hat_M); gc();
  SD_theta_M_hat = matrix(sqrt(diag(VAR_theta_M/N)),,1)
  SD_theta_L_hat = matrix(sqrt(diag(VAR_theta_L/N)),,1)
  
  
  ### report estimated unconditional cross-sectional means of coefficients without time effects
  ####### R = matrix(zeroes)
  sum_est = theta_M_hat # 2 by 1
  sum_av = VAR_theta_M / N # 2 by 2
  sum_cov = sum_av[1,2:k]
  if (k > 2) {
    for (j in 2:k) {
      sum_cov = append(sum_cov,sum_av[1,(2+j-1):k])
    }
  }
  sum_avar = matrix(,1,(k+k*(k-1)/2))
  sum_avar[1,1:k] = diag(sum_av)
  sum_avar[1,(k+1):(k+k*(k-1)/2)] = sum_cov
  
  np = mean(abs(D)<=h) # trimmed portion
  
  sum_an_output = as.matrix(cbind(np,t(sum_est),sum_avar))
  
  #######
  su_est = theta_L_hat # 2 by 1
  su_av = VAR_theta_L / N # 2 by 2
  su_cov = su_av[1,2:k]
  if (k > 2) {
    for (j in 2:(k-1)) {
      su_cov = append(su_cov,su_av[j,(j+1):k])
    }
  }
  su_avar = matrix(,1,(k+k*(k-1)/2))
  su_avar[1,1:k] = diag(su_av)
  su_avar[1,(k+1):(k+k*(k-1)/2)] = su_cov
  
  np = mean(abs(D)<=h) # trimmed portion
  
  su_an_output = as.matrix(cbind(np,t(su_est),su_avar))
  su_output = rbind(su_an_output)
  su_output
}

SU_est_l = function(paneldata,nobs,Tobs,k,L,te){
  t = 1 # only time effects in intercepts
  p = k # dim(w_it)
  N = nobs
  L = L # order of local polynomial regression
  T = Tobs
  
  #R = matrix(c(0,0,0,0),2,2)      # For t = 1 for Monte Carlo
  R = matrix(c(1/Tobs,0),2,1)  # only time effects in intercepts
  
  # input a panel data set
  ###########################################
  paneldata_x = matrix(paneldata[,2],2,nobs)
  paneldata_y = matrix(paneldata[,1],2,nobs) 
  
  X1 = matrix(paneldata_x[1,],nobs,1)
  X2 = matrix(paneldata_x[2,],nobs,1)
  Y1 = matrix(paneldata_y[1,],nobs,1)
  Y2 = matrix(paneldata_y[2,],nobs,1)
  ###########################################
  
  ################################################################
  # ADJOINT MATRIX FUNCTION
  ################################################################
  adjoint <- function(A){
    adjA = matrix(0,dim(A)[2],dim(A)[1])
    for( i in 1:(dim(A)[1]) ){
      for( j in 1:(dim(A)[2]) ){
        adjA[j,i] = (-1)^(i+j) * det(as.matrix(A[-i,-j]))
      }
    }
    return( adjA )
  }
  
  ################################################################
  # D, BOLD-FACE X, BOLD-FACE X*, BOLD-FACE X^{-1}, & BOLD-FACE W
  ################################################################
  i = 1
  D = det(rbind(cbind(1,X1[i,1]),cbind(1,X2[i,1])))  # det(Wi)
  bfX = list(rbind(cbind(1,X1[i,1]),cbind(1,X2[i,1])))
  bfXstr = list(adjoint(rbind(cbind(1,X1[i,1]),cbind(1,X2[i,1]))))
  bfXinv = list(ginv(rbind(cbind(1,X1[i,1]),cbind(1,X2[i,1]))))
  bfW = list(rbind(0,cbind(1))) #list(rbind(0,cbind(1,X2[i,1])))
  bfY = list(rbind(Y1[i,1],Y2[i,1]))
  for( i in 2:N ){
    D = c(D,det(rbind(cbind(1,X1[i,1]),cbind(1,X2[i,1]))))
    bfX[length(bfX)+1] = list(rbind(cbind(1,X1[i,1]),cbind(1,X2[i,1])))
    bfXstr[length(bfXstr)+1] = list(adjoint(rbind(cbind(1,X1[i,1]),cbind(1,X2[i,1]))))
    bfXinv[length(bfXinv)+1] = list(ginv(rbind(cbind(1,X1[i,1]),cbind(1,X2[i,1]))))
    bfW[length(bfW)+1] = list(rbind(0,cbind(1))) #list(rbind(0,cbind(1,X2[i,1])))
    bfY[length(bfY)+1] = list(rbind(Y1[i,1],Y2[i,1]))
  }
  
  ################################################################
  # h AND b (GRAHAM & POWELL, 2012, PAGE 2138)
  ################################################################
  h = min(c(sd(D), (quantile(D,0.75)-quantile(D,0.25))/1.34 )) / N^(1/(2*L+1)) / 2
  
  ################################################################
  # h_hat, e1, D0L, D1L
  ################################################################
  i = 1
  h_hat = (abs(D[i])<=h)*matrix(D[i]^(0:(L-1)),L,1) / N
  e1 = matrix(c(1, array(0,L)),L+1,1)
  D0L = list((abs(D[i])<=h)*matrix(D[i]^(0:L),L+1,1))
  D1L = list((abs(D[i])<=h)*matrix(D[i]^(1:L),L,1))
  for(i in 2:N){
    h_hat = h_hat + (abs(D[i])<=h)*matrix(D[i]^(0:(L-1)),L,1) / N
    D0L[length(D0L)+1] = list((abs(D[i])<=h)*matrix(D[i]^(0:L),L+1,1))
    D1L[length(D1L)+1] = list((abs(D[i])<=h)*matrix(D[i]^(1:L),L,1))
  }
  
  ################################################################
  # ESTIMATE DELTA ## time effects
  ################################################################
  END0LD0L = 0                                     # E_N[D0L D0L']
  for( i in 1:N ){
    D0Li = matrix(unlist(D0L[i]),L+1,1)
    END0LD0L = END0LD0L + D0Li%*%t(D0Li) / N
  }
  
  denominator = 0
  numerator = 0
  for( i in 1:N ){
    D0Li = matrix(unlist(D0L[i]),L+1,1)
    XstrWi = matrix(unlist(bfXstr[i]),T,p)%*%matrix(unlist(bfW[i]),T,(T-1)*1) #matrix(unlist(bfXstr[i]),T,p)%*%matrix(unlist(bfW[i]),T,(T-1)*p)
    XstrYi = matrix(unlist(bfXstr[i]),T,p)%*%matrix(unlist(bfY[i]),T,1)
    denominator = denominator + as.numeric(t(D0Li)%*%ginv(END0LD0L)%*%e1) * t(XstrWi) %*% XstrWi / N
    numerator   = numerator   + as.numeric(t(D0Li)%*%ginv(END0LD0L)%*%e1) * t(XstrWi) %*% XstrYi / N
  }
  delta_hat = ginv(denominator)%*%numerator
  
  ################################################################
  # ESTIMATE GAMMA
  ################################################################
  END1LD1L = 0                                     # E_N[D1L D1L']
  for( i in 1:N ){
    D1Li = matrix(unlist(D1L[i]),L,1)
    END1LD1L = END1LD1L + D1Li%*%t(D1Li) / N
  }
  
  gamma_hat = 0
  for( i in 1:N ){
    D1Li = matrix(unlist(D1L[i]),L,1)
    XstrWi = matrix(unlist(bfXstr[i]),T,p)%*%matrix(unlist(bfW[i]),T,(T-1)*1) #matrix(unlist(bfXstr[i]),T,p)%*%matrix(unlist(bfW[i]),T,(T-1)*p)
    XstrYi = matrix(unlist(bfXstr[i]),T,p)%*%matrix(unlist(bfY[i]),T,1)
    gamma_hat = gamma_hat + (XstrYi - XstrWi %*% delta_hat) %*% t(D1Li) / N
  }
  gamma_hat = gamma_hat %*% ginv(END1LD1L)
  
  ################################################################
  # ESTIMATE BETA^M & BETA_L
  ################################################################
  beta_M_hat_numerator = 0
  for( i in 1:N ){
    XstrWi = matrix(unlist(bfXstr[i]),T,p)%*%matrix(unlist(bfW[i]),T,(T-1)*1) #matrix(unlist(bfXstr[i]),T,p)%*%matrix(unlist(bfW[i]),T,(T-1)*p)
    XstrYi = matrix(unlist(bfXstr[i]),T,p)%*%matrix(unlist(bfY[i]),T,1)
    if( abs(D[i])>h ){
      beta_M_hat_numerator = beta_M_hat_numerator + (abs(D[i])>h)*(1/D[i])*(XstrYi - XstrWi %*% delta_hat) / N
    }
  }
  beta_M_hat_denominator = mean((abs(D)>h))
  
  beta_M_hat = beta_M_hat_numerator * beta_M_hat_denominator^(-1)
  beta_L_hat = beta_M_hat_numerator + gamma_hat %*% h_hat
  
  ################################################################
  # ESTIMATE THETA
  ################################################################
  theta_L_hat = beta_L_hat + R%*%delta_hat
  theta_M_hat = beta_M_hat + R%*%delta_hat
  
  ################################################################
  # COMPUTE V_hat
  ################################################################
  V_hat = 0
  for( i in 1:N ){
    D0Li = matrix(unlist(D0L[i]),L+1,1)
    XstrWi = matrix(unlist(bfXstr[i]),T,p)%*%matrix(unlist(bfW[i]),T,(T-1)*1) #matrix(unlist(bfXstr[i]),T,p)%*%matrix(unlist(bfW[i]),T,(T-1)*p)
    V_hat = V_hat + as.numeric(t(D0Li)%*%ginv(END0LD0L)%*%e1) * t(XstrWi)%*%XstrWi / N
  }
  
  ################################################################
  # COMPUTE Q_hat
  ################################################################
  Q_hat = 0
  for( i in 1:N ){
    D1Li = matrix(unlist(D1L[i]),L,1)
    XstrWi = matrix(unlist(bfXstr[i]),T,p)%*%matrix(unlist(bfW[i]),T,(T-1)*1) #matrix(unlist(bfXstr[i]),T,p)%*%matrix(unlist(bfW[i]),T,(T-1)*p)
    if( abs(D[i])>h ){
      Q_hat = Q_hat + as.numeric( (abs(D[i])>h)/D[i] + t(D1Li)%*%ginv(END1LD1L)%*%h_hat ) * XstrWi / N
    }
  }
  
  ################################################################
  # COMPUTE zeta_hat (1ST TERM)
  ################################################################
  zeta_hat_1 = NULL
  for(i in 1:N){
    XstrWi = matrix(unlist(bfXstr[i]),T,p)%*%matrix(unlist(bfW[i]),T,(T-1)*1) #matrix(unlist(bfXstr[i]),T,p)%*%matrix(unlist(bfW[i]),T,(T-1)*p)
    XstrYi = matrix(unlist(bfXstr[i]),T,p)%*%matrix(unlist(bfY[i]),T,1)
    if( abs(D[i])>h ){
      zeta_hat_1 = cbind(zeta_hat_1, (abs(D[i])>h)/D[i] * (XstrYi - XstrWi%*%delta_hat))
    }else{
      zeta_hat_1 = cbind(zeta_hat_1, matrix(0,p,1) )
    }
  }
  zeta_hat_1 = zeta_hat_1 - matrix(rowMeans(zeta_hat_1),p,N)
  
  ################################################################
  # COMPUTE zeta_hat (2ND TERM)
  ################################################################
  zeta_hat_2 = NULL
  for(i in 1:N){
    D1Li = matrix(unlist(D1L[i]),L,1)
    XstrWi = matrix(unlist(bfXstr[i]),T,p)%*%matrix(unlist(bfW[i]),T,(T-1)*1) #matrix(unlist(bfXstr[i]),T,p)%*%matrix(unlist(bfW[i]),T,(T-1)*p)
    XstrYi = matrix(unlist(bfXstr[i]),T,p)%*%matrix(unlist(bfY[i]),T,1)
    zeta_hat_2 = cbind(zeta_hat_2, ((XstrYi-XstrWi%*%delta_hat) - gamma_hat%*%D1Li) %*% t(D1Li) %*% ginv(END1LD1L) %*% h_hat)
  }
  
  ################################################################
  # COMPUTE zeta_hat (3RD TERM)
  ################################################################
  zeta_hat_3R = NULL
  zeta_hat_3Q = NULL
  for(i in 1:N){
    D0Li = matrix(unlist(D0L[i]),L+1,1)
    XstrWi = matrix(unlist(bfXstr[i]),T,p)%*%matrix(unlist(bfW[i]),T,(T-1)*1) #matrix(unlist(bfXstr[i]),T,p)%*%matrix(unlist(bfW[i]),T,(T-1)*p)
    XstrYi = matrix(unlist(bfXstr[i]),T,p)%*%matrix(unlist(bfY[i]),T,1)
    zeta_hat_3R = cbind(zeta_hat_3R, as.numeric(t(D0Li)%*%ginv(END0LD0L)%*%e1) * R%*%ginv(V_hat)%*%t(XstrWi)%*%(XstrYi-XstrWi%*%delta_hat))
    zeta_hat_3Q = cbind(zeta_hat_3Q, as.numeric(t(D0Li)%*%ginv(END0LD0L)%*%e1) * Q_hat%*%ginv(V_hat)%*%t(XstrWi)%*%(XstrYi-XstrWi%*%delta_hat))
  }
  
  ################################################################
  # COMPUTE zeta_hat (ALL TOGETHER)
  ################################################################
  zeta_hat_M = zeta_hat_1 + zeta_hat_3R
  zeta_hat_L = zeta_hat_1 + zeta_hat_2 + zeta_hat_3R - zeta_hat_3Q
  rm(zeta_hat_1); rm(zeta_hat_2); rm(zeta_hat_3R); rm(zeta_hat_3Q); #gc();
  
  ################################################################
  # VARIANCE AND SD
  ################################################################
  VAR_theta_M = zeta_hat_M %*% t(zeta_hat_M) / N
  VAR_theta_L = zeta_hat_L %*% t(zeta_hat_L) / N
  rm(zeta_hat_M); #gc(); #rm(zeta_hat);
  SD_theta_M_hat = matrix(sqrt(diag(VAR_theta_M/N)),,1)
  SD_theta_L_hat = matrix(sqrt(diag(VAR_theta_L/N)),,1)
  
  ################################################################
  ## report SU (2021) estimation results
  ################################################################
  su_est = theta_L_hat # 2 by 1
  su_av = VAR_theta_L / N # 2 by 2
  su_cov = su_av[1,2:k]
  if (k > 2) {
    for (j in 2:(k-1)) {
      su_cov = append(su_cov,su_av[j,(j+1):k])
    }
  }
  su_avar = matrix(,1,(k+k*(k-1)/2))
  su_avar[1,1:k] = diag(su_av)
  su_avar[1,(k+1):(k+k*(k-1)/2)] = su_cov
  
  np = mean(abs(D)<=h) # trimmed portion
  
  vte1 = -1/Tobs+rbind(matrix(0,1,Tobs-1),diag(1,Tobs-1)) # T by (T-1) phi* to phi
  phi_hat = vte1 %*% delta_hat
  
  su_an_output = as.matrix(cbind(np,t(su_est),su_avar,t(phi_hat)))
  su_output = su_an_output 
  su_output
}

SU_est = function(paneldata,nobs,Tobs,k,l_list,te){
  ll = length(l_list)
  dimte = 0*(te==0)+ 1*(te==1) + (Tobs-1)*k*(te==((Tobs-1)*k))
  ptheta = (1+k+(k+k*(k-1)/2))
  dimte = Tobs
  # with no time effects
  if (te==0) {
    su_list = sapply(l_list,SUN_est_l,paneldata=paneldata,nobs=nobs,Tobs=Tobs,k=k)
    su_np = matrix(su_list[1,],ll,1) # np: 1
    su_ests = matrix(su_list[2:(k+1),],k*ll,1)  # ests: k 
    su_avar = matrix(su_list[(k+2):(1+k+(k+k*(k-1)/2)),],(k+k*(k-1)/2)*ll,1)  # avar (k+corr): k + k*(k-1)/2
    su_output = list(su_np,su_ests,su_avar)
    names(su_output) = c("np","ests","avar")
  }
  # with time effects: ## order of local polynomial regressor associated with rate of convergence
  if (te>0) {
    su_list =sapply(l_list,SU_est_l,paneldata=paneldata,nobs=nobs,Tobs=Tobs,k=k,te=te)
    su_np = matrix(su_list[1,],ll,1) # np: 1
    su_ests = matrix(su_list[2:(k+1),],k*ll,1)  # ests: k 
    su_avar = matrix(su_list[(k+2):ptheta,],(k+k*(k-1)/2)*ll,1)# avar (k+corr): k + k*(k-1)/2
    phite_ests = matrix(su_list[(1+ptheta):(dimte+ptheta),],dimte*ll,1) # ests of time effects
    su_output = list(su_np,su_ests,su_avar,phite_ests)
    names(su_output) = c("np","ests","avar","te")
  }
  su_output 
}
###### Fin: 5. SU and SUM estimators 


################################################################################
###  Trimmed Mean Group Estimator: TMG, TMG-TE and TMG-C 
### (Minor, Cofactor, Adjoint1, Det_i, TOLS_i, Qw_i, MTxy_i, MTuu_i, Phiuu_i)
### (TMG_an, TMG_TE_an, TMG_est)
################################################################################
Minor = function(A, i, j) {
  det(as.matrix(A[-i,-j]) )
}

Cofactor = function(A, i, j) {
  (-1)^(i+j) * Minor(A,i,j)
}

Adjoint1 = function(A) {
  n = nrow(A)
  B = matrix(, n, n)
  for( i in 1:n )
    for( j in 1:n )
      B[j,i] = Cofactor(A, i, j)
  B
}

Det_i = function(paneldata_w,nobs,Tobs,k,id) {
  wi = matrix(paneldata_w[(1+(id-1)*Tobs):(id*Tobs),],Tobs,k)  # (T by k)
  deti = det(t(wi) %*% wi) # scalar where t(wi) %*% wi is a (k by k) matrix
  deti
}

TOLS_i = function(panel_int,nobs,Tobs,k,an,id){
  obsi = as.matrix(panel_int[(1+(id-1)*Tobs):(id*Tobs),]) # paneldata = {(yi,wi)} (nT by k+1) matrix
  yi = as.matrix(obsi[,1]) # yi (T by 1)
  wi = as.matrix(obsi[,2:(k+1)]) # regressor wi (T by k) with wit = (1,xit')'
  di = det(t(wi) %*% wi) # determinant
  if (di > an) {
    theta_i = solve(t(wi) %*% wi) %*% (t(wi) %*% yi) # (k by 1) individual OLS estimator
  } else {
    theta_i = an^(-1) * Adjoint1(t(wi) %*% wi) %*% (t(wi) %*% yi) # (k by 1) individual trimmed estimator
  }
  theta_i
}

Qw_i = function(paneldata_w,nobs,Tobs,k,an,id){
  wi = matrix(paneldata_w[(1+(id-1)*Tobs):(id*Tobs),],Tobs,k)  # (T by k)
  di = det(t(wi) %*% wi) # determinant
  if (di > an) {
    qw_i = solve(t(wi) %*% wi) %*% t(wi) # (k by T) 
  } else {
    qw_i = an^(-1) * Adjoint1(t(wi) %*% wi) %*% t(wi) # (k by T)
  }
  qw_i
}

# calculate numerator and denominator phi_c
MTxy_i = function(paneldata,nobs,Tobs,k,id) {
  yi = matrix(paneldata[(1+(id-1)*Tobs):(id*Tobs),1],Tobs,1)
  xi = matrix(paneldata[(1+(id-1)*Tobs):(id*Tobs),2:k],Tobs,k-1) # (T by k-1)
  taut = matrix(1,Tobs,1) 
  mt = diag(1,Tobs)-taut %*% solve(t(taut)%*%taut) %*% t(taut) # (T by T)
  mtxi = mt %*% xi
  mti = diag(1,Tobs)- mtxi %*% solve(t(mtxi) %*% mtxi) %*% t(mtxi) # (T by T)
  mtyi = mti %*% mt %*% yi # (T by 1)
  mtxyi = cbind(mti,mtyi) # T by (T+1)
  mtxyi
}

# calculate part of the variance of phi_c
MTuu_i = function(paneldata,nobs,Tobs,k,phi_c,id) {
  yi = matrix(paneldata[(1+(id-1)*Tobs):(id*Tobs),1],Tobs,1)
  xi = matrix(paneldata[(1+(id-1)*Tobs):(id*Tobs),2:k],Tobs,k-1) # (T by k-1)
  taut = matrix(1,Tobs,1) 
  mt = diag(1,Tobs)-taut %*% solve(t(taut)%*%taut) %*% t(taut) # (T by T)
  mtxi = mt %*% xi
  mti = diag(1,Tobs)- mtxi %*% solve(t(mtxi)%*% mtxi) %*% t(mtxi) # (T by T)
  ydtei = matrix(yi - phi_c,Tobs,1)
  mtuui = mti %*% mt %*% ydtei %*% t(ydtei) %*% t(mti %*% mt)
  mtuui
}

# calculate part of the variance of phi_hat
Phiuu_i = function(paneldata,nobs,Tobs,k,est,id) {
  yi = matrix(paneldata[(1+(id-1)*Tobs):(id*Tobs),1],Tobs,1)
  xi = matrix(paneldata[(1+(id-1)*Tobs):(id*Tobs),2:k],Tobs,k-1) # (T by k-1)
  phi_hat = as.matrix(est[1:Tobs]) # (T by 1)
  beta_hat = as.matrix(est[(Tobs+2):(Tobs+k)]) # (k-1) by 1
  ui = yi - xi %*% beta_hat - phi_hat
  uui = ui %*% t(ui) 
  uui # (T by T)
}

### conditional on a threshold tau, calculate TMG(an) estimator
TMG_an = function(paneldata,nobs,Tobs,k,arate){
  id_list = as.matrix(seq(1,nobs,by=1))
  int_nT_long = matrix(1,nobs*Tobs,1)
  paneldata_x = paneldata[,2:k] # nT by (k-1)
  paneldata_w = cbind(int_nT_long,paneldata_x) # (nT by k)
  paneldata_y = matrix(paneldata[,1],nobs*Tobs,1) # (nT by 1)
  panel_int = cbind(paneldata_y,paneldata_w) # add intercepts
  
  ## TMG (1) calculate di=det(Wi'Wi) and the threshold an = mean(di)*(n^(-arate))
  det_n = sapply(id_list,Det_i,paneldata_w=paneldata_w,nobs=nobs,Tobs=Tobs,k=k) 
  det_bn = mean(det_n) # the sample mean of di=det(Wi'Wi)
  an = det_bn*(nobs^(-arate)) # the threshold
  
  ## TMG (2) calculate the trimming index
  trim_n = (det_n<=an)
  np = mean(trim_n)
  
  ## TMG (3) calculate trimmed individual estimates
  theta_trim_n = sapply(id_list,TOLS_i,panel_int=panel_int,nobs=nobs,Tobs=Tobs,k=k,an=an) # (k by n)
  tmgh_hat = matrix(rowMeans(theta_trim_n),k,1) # (k by 1) average over n
  
  ## TMG (4) calculate bias-corrected TMG estimator 
  delta_n = (det_n/an-1)*trim_n # (n by 1)
  delta_bn = mean(delta_n)
  tmg_hat = (1+delta_bn)^(-1)*tmgh_hat # (k by 1) 
  
  ## TMG (5) calculate asymptotic variance of TMG estimator 
  tmg_bm = matrix(tmg_hat, k ,nobs)
  tmg_av =(1+delta_bn)^(-2)*(nobs*(nobs-1))^(-1)*(theta_trim_n-tmg_bm) %*% t(theta_trim_n-tmg_bm) # (k by k)
  
  ## Report the covariance matrix of TMG estimator
  tmg_cov = tmg_av[1,2:k]
  if (k > 2) {
    for (j in 2:(k-1)) {
      tmg_cov = append(tmg_cov,tmg_av[j,(j+1):k])
    }
  }
  tmg_avar = matrix(,1,(k+k*(k-1)/2))
  tmg_avar[1,1:k] = diag(tmg_av)
  tmg_avar[1,(k+1):(k+k*(k-1)/2)] = tmg_cov
  
  # TMG: np,ests,avar
  tmg_an_output = as.matrix(cbind(np,t(tmg_hat),tmg_avar)) # 1+k+(k+k*(k-1)/2))
  tmg_an_output
}

TMG_TE_an = function(paneldata,nobs,Tobs,k,arate){
  id_list = as.matrix(seq(1,nobs,by=1))
  int_nT_long = matrix(1,nobs*Tobs,1)
  paneldata_x = paneldata[,2:k] # nT by (k-1)
  paneldata_w = cbind(int_nT_long,paneldata_x) # (nT by k)
  paneldata_y = matrix(paneldata[,1],nobs*Tobs,1) # (nT by 1)
  panel_int = cbind(paneldata_y,paneldata_w) # add intercepts
  
  ## calculate TMG estimator
  #################################################################
  ## TMG (1) calculate di=det(Wi'Wi) and the threshold an = mean(di)*(n^(-arate))
  det_n = sapply(id_list,Det_i,paneldata_w=paneldata_w,nobs=nobs,Tobs=Tobs,k=k) 
  det_bn = mean(det_n) # the sample mean of di=det(Wi'Wi)
  an = det_bn*(nobs^(-arate)) # the threshold
  
  ## TMG (2) calculate the trimming index
  trim_n = (det_n<=an)
  np = mean(trim_n)
  
  ## TMG (3) calculate trimmed individual estimates
  theta_trim_n = sapply(id_list,TOLS_i,panel_int=panel_int,nobs=nobs,Tobs=Tobs,k=k,an=an) # (k by n)
  tmgh_hat = matrix(rowMeans(theta_trim_n),k,1) # (k by 1) average over n
  
  ## TMG (4) calculate bias-corrected TMG estimator 
  delta_n = (det_n/an-1)*trim_n # (n by 1)
  delta_bn = mean(delta_n)
  tmg_hat = (1+delta_bn)^(-1)*tmgh_hat # (k by 1) 
  #################################################################
  
  ## calculate TMG-TE estimator under tau'phi=0
  #################################################################
  w_n = matrix(t(paneldata_w),k*Tobs,nobs) # (Tk by n)
  w_bn = t(matrix(rowMeans(w_n),k,Tobs)) # (T by k) average over n
  taut = matrix(1,Tobs,1) 
  mt = diag(1,Tobs)-taut %*% solve(t(taut)%*%taut) %*% t(taut) # (T by T)
  qw_n = (1+delta_bn)^(-1)*sapply(id_list,Qw_i,paneldata_w=paneldata_w,nobs=nobs,Tobs=Tobs,k=k,an=an) # kT by n 
  qw_bn = matrix(rowMeans(qw_n),k,Tobs) # (k by T)
  
  y_n = matrix(paneldata_y,Tobs,nobs) # (T by n)
  y_bn = matrix(rowMeans(y_n),Tobs,1) # (T by 1) {y_it} average over n for each t
  
  ## TMG-TE (1) calculate estimator phi_hat and theta_hat
  phi_hat = solve(diag(1,Tobs)-mt%*%w_bn%*%qw_bn) %*% mt %*% (y_bn-w_bn%*%tmg_hat)
  theta_hat = tmg_hat - qw_bn%*%phi_hat
  
  ## TMG-TE (2) calculate asymptotic variance of theta_hat
  phie_nT = matrix(matrix(phi_hat,Tobs,nobs),Tobs*nobs,1)
  ydte_nT = paneldata_y - phie_nT # (nT by 1) 
  panel_dte = cbind(ydte_nT,paneldata_w)  
  theta_te_n = sapply(id_list,TOLS_i,panel_int=panel_dte,nobs=nobs,Tobs=Tobs,k=k,an=an) # (k by n)
  theta_bm = matrix(theta_hat,k,nobs)
  theta_av0 = (1+delta_bn)^(-2)*(nobs*(nobs-1))^(-1)*(theta_te_n-theta_bm) %*% t(theta_te_n-theta_bm) # (k by k) 
  theta_av = solve(diag(1,k)-qw_bn%*%mt%*%w_bn)%*%theta_av0%*%t(solve(diag(1,k)-qw_bn%*%mt%*% w_bn)) 
  
  ## TMG-TE asymptotic variance of time effects phi
  tmgte_hat = as.matrix(c(phi_hat,theta_hat)) # (T+k) by 1: phi_hat, theta_hat 
  phiuu_n = sapply(id_list,Phiuu_i,paneldata=paneldata,nobs=nobs,Tobs=Tobs,k=k,est=tmgte_hat)
  phiuu_bn = matrix(rowMeans(phiuu_n),Tobs,Tobs)
  phi_av0 = nobs^(-1)*phiuu_bn
  phi_av = mt %*% ( w_bn %*% theta_av %*% t(w_bn) + phi_av0 ) %*% mt
  #################################################################
  
  ## calculate TMG-C estimator under tau'phi=0
  if (Tobs>k) {
    mtxy_n = sapply(id_list,MTxy_i,paneldata=paneldata,nobs=nobs,Tobs=Tobs,k=k)
    mtx_bn = matrix(rowMeans(mtxy_n[1:(Tobs*Tobs),]),Tobs,Tobs)
    mty_bn = matrix(rowMeans(mtxy_n[(Tobs*Tobs+1):(Tobs*(Tobs+1)),]),Tobs,1)
    phi_c = solve(mtx_bn) %*% mty_bn
    
    mtuu_n = sapply(id_list,MTuu_i,paneldata=paneldata,nobs=nobs,Tobs=Tobs,k=k,phi_c=phi_c)
    mtuu_bn = matrix(rowMeans(mtuu_n),Tobs,Tobs)
    phic_av = nobs^(-1)*solve(mtx_bn) %*% mtuu_bn %*% t(solve(mtx_bn))
    
    phic_nT = matrix(matrix(phi_c,Tobs,nobs),Tobs*nobs,1)
    ydtc_nT = paneldata_y - phic_nT # (nT by 1) vector of yit-phit_hat
    panel_dtc = cbind(ydtc_nT,paneldata_w) 
    thetac_n = sapply(id_list,TOLS_i,panel_int=panel_dtc,nobs=nobs,Tobs=Tobs,k=k,an=an) # (k by n)
    theta_c = (1+delta_bn)^(-1)*matrix(rowMeans(thetac_n),k,1)
    
    ## TMG-C asymptotic variance of E(theta_i)
    thetac_bm = matrix(theta_c,k,nobs)
    thetac_av0 = (1+delta_bn)^(-2)*(nobs*(nobs-1))^(-1)*(thetac_n-thetac_bm) %*% t(thetac_n-thetac_bm) # (k by k) (46)
    qw_n = (1+delta_bn)^(-1)*sapply(id_list,Qw_i,paneldata_w=paneldata_w,nobs=nobs,Tobs=Tobs,k=k,an=an) # kT by n 
    qw_bn = matrix(rowMeans(qw_n),k,Tobs) # (k by T)
    thetac_av1 = qw_bn %*% phic_av %*% t(qw_bn)
    thetac_av = thetac_av0 + thetac_av1
    
    thetac_cov = thetac_av[1,2:k]
    if (k > 2) {
      for (j in 2:(k-1)) {
        thetac_cov = append(thetac_cov,thetac_av[j,(j+1):k])
      }
    }
    thetac_avar = matrix(,1,(k+k*(k-1)/2))
    thetac_avar[1,1:k] = diag(thetac_av)
    thetac_avar[1,(k+1):(k+k*(k-1)/2)] = thetac_cov
    
    phic_avar = diag(phic_av)
  }
  
  ## Report the estimated asymptotic variance of TMG-TE
  #################################################################
  theta_cov = theta_av[1,2:k]
  if (k > 2) {
    for (j in 2:(k-1)) {
      theta_cov = append(theta_cov,theta_av[j,(j+1):k])
    }
  }
  theta_avar = matrix(,1,(k+k*(k-1)/2))
  theta_avar[1,1:k] = diag(theta_av)
  theta_avar[1,(k+1):(k+k*(k-1)/2)] = theta_cov
  
  phi_avar = diag(phi_av)
  #################################################################
  
  # report TMG estimator with time effects
  #################################################################
  if (Tobs==k) {
    tmgte_an_output = as.matrix(c(np,t(theta_hat),theta_avar,t(phi_hat),t(phi_avar))) # 1+k+(k+k*(k-1)/2))+ T+(T+T*(T-1)/2)
  }
  if (Tobs>k) {
    tmgte_te_output = as.matrix(c(np,t(theta_hat),theta_avar,t(phi_hat),t(phi_avar))) # 1+k+(k+k*(k-1)/2))+ T+(T+T*(T-1)/2)
    tmg_c_output = as.matrix(c(np,t(theta_c),thetac_avar,t(phi_c),t(phic_avar))) # 1+k+(k+k*(k-1)/2))+ T+(T+T*(T-1)/2)
    tmgte_an_output = cbind(tmgte_te_output, tmg_c_output)
  }
  #################################################################
  tmgte_an_output
}

TMG_est = function(paneldata,nobs,Tobs,k,a_list,te){
  ## alpha associated with rate of convergence
  a_list  = as.matrix(a_list)
  al = dim(a_list)[1]
  ptheta = (1+k+(k+k*(k-1)/2))
  dimte = Tobs
  pte = 2*Tobs
  p = ptheta+pte
  
  if (te==0) {
    tmg_list = as.matrix(sapply(a_list,TMG_an,paneldata=paneldata,nobs=nobs,Tobs=Tobs,k=k))
    tmg_np = matrix(tmg_list[1,],al,1) # np: 1
    tmg_ests = matrix(tmg_list[2:(k+1),],k*al,1)  # ests: k 
    tmg_avar = matrix(tmg_list[(k+2):ptheta,],(k+k*(k-1)/2)*al,1)  # avar (k+corr): k + k*(k-1)/2
    tmg_output = list(tmg_np,tmg_ests,tmg_avar)
    names(tmg_output) = c("np","ests","avar")
  }
  if (te>0) {
    tmg_list = as.matrix(sapply(a_list,TMG_TE_an,paneldata=paneldata,nobs=nobs,Tobs=Tobs,k=k))
    tmgte_list = as.matrix(tmg_list[1:p,])
    
    tmgte_np = matrix(tmgte_list[1,],al,1) # np: 1
    tmgte_ests = matrix(tmgte_list[2:(k+1),],k*al,1)  # ests: k 
    tmgte_avar = matrix(tmgte_list[(k+2):ptheta,],(k+k*(k-1)/2)*al,1)  # avar: k+k*(k-1)/2
    phite_ests = matrix(tmgte_list[(1+ptheta):(dimte+ptheta),],dimte*al,1) # ests of time effects
    phite_avar = matrix(tmgte_list[(dimte+ptheta+1):(ptheta+pte),],(pte-dimte)*al,1) # avar of time effects
    
    tmgte_output = list(tmgte_np,tmgte_ests,tmgte_avar,phite_ests,phite_avar)
    names(tmgte_output) = c("np","ests","avar","tests","tavar")
    tmg_output = list(tmgte_output)
    names(tmg_output) = c("tmgte")
    
    if (Tobs>k) {
      tmgc_list = as.matrix(tmg_list[(p+1):(2*p),])
      tmgc_np = matrix(tmgc_list[1,],al,1) # np: 1
      tmgc_ests = matrix(tmgc_list[2:(k+1),],k*al,1)  # ests: k 
      tmgc_avar = matrix(tmgc_list[(k+2):ptheta,],(k+k*(k-1)/2)*al,1)  # avar: k+k*(k-1)/2
      phic_ests = matrix(tmgc_list[(1+ptheta):(dimte+ptheta),],dimte*al,1) # ests of time effects
      phic_avar = matrix(tmgc_list[(dimte+ptheta+1):(ptheta+pte),],(pte-dimte)*al,1) # avar of time effects
      
      tmgc_output = list(tmgc_np,tmgc_ests,tmgc_avar,phic_ests,phic_avar)
      names(tmgc_output) = c("np","ests","avar","tests","tavar")
      tmg_output = list(tmgte_output,tmgc_output)
      names(tmg_output) = c("tmgte","tmgc")
    } 
  } 
  
  tmg_output 
}


################################################################################
### Define Functions of Monte Carlo Replications (MCS_rep)
################################################################################
MCS_rep = function(rep,nobs,Tobs,k,m_y,gauss_y,m_x,hetero_x,dist_x,ar_x,te_x,corr_e,para_case,kappa2,bal_panel,phi_te,a_list,agp_list,te,gpe,tmge) {
  # 7 statistics: np, est, avar, bias, rmse, cvr, size
  ne = 2*length(a_list)+length(agp_list) 
  np_rep = matrix(,k*ne,rep)
  est_rep = matrix(,k*ne,rep)
  avar_rep = matrix(,k*ne,rep)
  acov_rep = matrix(,((k*(k-1)/2)*ne),rep)
  
  bias_rep = matrix(,k*ne,1)
  rmse_rep = matrix(,k*ne,1)
  cvr_rep = matrix(,k*ne,1)
  size_rep = matrix(,k*ne,1)
  pw_rep = matrix(,pwgrid,k*ne)
  stat_rep = matrix(,k*ne,7) 
  
  dimte = Tobs # dimension of time effects
  te_rep = matrix(,dimte*ne,rep) # time effects
  tavar_rep = matrix(,dimte*ne,rep) # time effects
  
  tbias_rep = matrix(,dimte*ne,1)
  trmse_rep = matrix(,dimte*ne,1)
  tcvr_rep = matrix(,dimte*ne,1)
  tsize_rep = matrix(,dimte*ne,1)
  tpw_rep = matrix(,pwgrid,dimte*ne)
  statte_rep = matrix(,dimte*ne,7) 
  
  #fee=1;mge=1;atmge=1;gpe=1;sue=1;tmge=1
  for (s in 1:rep) {
    ################################################
    if (bal_panel==1) {
      paneldata_idt = Gen_balpanel(nobs,Tobs,k,m_y,gauss_y,m_x,hetero_x,dist_x,ar_x,te_x,corr_e,para_case,kappa2,phi_te,idt)
      paneldata = paneldata_idt[,3:(3+k-1)]
      
      if (gpe==1) {
        em = "GP"
        temp_gp = GP_est(paneldata,nobs,Tobs,k,agp_list,te)
      }
      if (tmge==1) {
        if (te==0) {
          em = "TMG"
          temp_tmg = TMG_est(paneldata,nobs,Tobs,k,a_list,te)
        }
        if (te==1) {
          em = "TMG-TE"
          temp_tmg = TMG_est(paneldata,nobs,Tobs,k,a_list,te)
          temp_tmgte = temp_tmg$tmgte
          if (Tobs>k) {
            temp_tmgc = temp_tmg$tmgc
          }
        }
      }
    }
    ################################################
    
    # store one replication result: 
    ###########################################################
    #ne = 1+1+2+1+dim(l_list)[1]+dim(a_list)[1]
    k2 = (k*(k-1)/2)
    if (gpe==1) {
        nee = dim(agp_list)[1] 
        for (i in 1:nee) {
          np_rep[(1+k*(i-1)):(k+k*(i-1)),s] = temp_gp$np[i] 
          est_rep[(1+k*(i-1)):(k+k*(i-1)),s] = temp_gp$ests[(1+k*(i-1)):(k+k*(i-1))]
          avar_rep[(1+k*(i-1)):(k+k*(i-1)),s] = temp_gp$avar[(1+(k+(k*(k-1)/2))*(i-1)):(k+(k+(k*(k-1)/2))*(i-1))]
          acov_rep[(1+k2*(i-1)):(k2*(i-1)),s] = temp_gp$avar[(k+1+(k+(k*(k-1)/2))*(i-1)):(k+(k*(k-1)/2)+(k+(k*(k-1)/2))*(i-1))]
        }
      if (te>0) {
        for (i in 1:nee) {
          te_rep[(1+dimte*(i-1)):(dimte+dimte*(i-1)),s] = temp_gp$te[(1+dimte*(i-1)):(dimte+dimte*(i-1))]
          tavar_rep[(1+dimte*(i-1)):(dimte+dimte*(i-1)),s] = temp_gp$tavar[(1+dimte*(i-1)):(dimte+dimte*(i-1))]
        }
      }
    }
    if (tmge==1) {
      nee = dim(a_list)[1] # multiple estimators with different thresholds
      if (te==0) {
        for (i in 1:nee) {
          np_rep[(3*k+1+k*(i-1)):(3*k+k+k*(i-1)),s] = temp_tmg$np[i] 
          est_rep[(3*k+1+k*(i-1)):(3*k+k+k*(i-1)),s] = temp_tmg$ests[(1+k*(i-1)):(k+k*(i-1))]
          avar_rep[(3*k+1+k*(i-1)):(3*k+k+k*(i-1)),s] = temp_tmg$avar[(1+(k+(k*(k-1)/2))*(i-1)):(k+(k+(k*(k-1)/2))*(i-1))]
          acov_rep[(3*k2+1+k2*(i-1)):(3*k2+k2*(i-1)),s] = temp_tmg$avar[(k+1+(k+(k*(k-1)/2))*(i-1)):(k+(k*(k-1)/2)+(k+(k*(k-1)/2))*(i-1))]
        }
      }
      if (te>0) {
        for (i in 1:nee) {
          np_rep[(3*k+1+k*(i-1)):(3*k+k+k*(i-1)),s] = temp_tmgte$np[i] 
          est_rep[(3*k+1+k*(i-1)):(3*k+k+k*(i-1)),s] = temp_tmgte$ests[(1+k*(i-1)):(k+k*(i-1))]
          avar_rep[(3*k+1+k*(i-1)):(3*k+k+k*(i-1)),s] = temp_tmgte$avar[(1+(k+(k*(k-1)/2))*(i-1)):(k+(k+(k*(k-1)/2))*(i-1))]
          acov_rep[(3*k2+1+k2*(i-1)):(3*k2+k2*(i-1)),s] = temp_tmgte$avar[(k+1+(k+(k*(k-1)/2))*(i-1)):(k+(k*(k-1)/2)+(k+(k*(k-1)/2))*(i-1))]
          te_rep[(3*dimte+1+dimte*(i-1)):(3*dimte+dimte+dimte*(i-1)),s] = temp_tmgte$te[(1+dimte*(i-1)):(dimte+dimte*(i-1))]
          tavar_rep[(3*dimte+1+dimte*(i-1)):(3*dimte+dimte+dimte*(i-1)),s] = temp_tmgte$tavar[(1+dimte*(i-1)):(dimte+dimte*(i-1))]
        }
        if (Tobs>k) {
          i = 1
          for (i in 1:nee) {
            np_rep[((3+nee)*k+1+k*(i-1)):((3+nee)*k+k+k*(i-1)),s] = temp_tmgc$np[i] 
            est_rep[((3+nee)*k+1+k*(i-1)):((3+nee)*k+k+k*(i-1)),s] = temp_tmgc$ests[(1+k*(i-1)):(k+k*(i-1))]
            avar_rep[((3+nee)*k+1+k*(i-1)):((3+nee)*k+k+k*(i-1)),s] = temp_tmgc$avar[(1+(k+(k*(k-1)/2))*(i-1)):(k+(k+(k*(k-1)/2))*(i-1))]
            acov_rep[((3+nee)*k2+1+k2*(i-1)):((3+nee)*k2+k2*(i-1)),s] = temp_tmgc$avar[(k+1+(k+(k*(k-1)/2))*(i-1)):(k+(k*(k-1)/2)+(k+(k*(k-1)/2))*(i-1))]
            te_rep[((3+nee)*dimte+1+dimte*(i-1)):((3+nee)*dimte+dimte+dimte*(i-1)),s] = temp_tmgc$te[(1+dimte*(i-1)):(dimte+dimte*(i-1))]
            tavar_rep[((3+nee)*dimte+1+dimte*(i-1)):((3+nee)*dimte+dimte+dimte*(i-1)),s] = temp_tmgc$tavar[(1+dimte*(i-1)):(dimte+dimte*(i-1))]
          }
        }
      }
    }
    ###########################################################
  }
  
  ### calculate statistics of E(theta_i)
  ###########################################################
  for (j in 1:k) {
    kid = seq(j,ne*k,by=2)
    for (i in 1:ne) {
      ki = kid[i]
      if (is.null(est_rep[ki,1])==F) {
        np_re = np_rep[ki,]
        est_re = est_rep[ki,]
        avar_re = avar_rep[ki,]
        estsdm_re = cbind(est_re,sqrt(avar_re))
        bias_rep[ki,1] = Bias(est_re,m_y[j])
        rmse_rep[ki,1] = Rmse(est_re,m_y[j])
        cvr_rep[ki,1] = Coverage(m_y[j],estsdm_re,rep)
        pw_rep[,ki] = Power(m_y[j],estsdm_re,rep) 
        size_rep[ki,1] = pw_rep[which(as.matrix(seq(as.numeric(0+pwlb),as.numeric(0+pwrb),by=pwintv))==0),ki]
        stat_rep[ki,] = c(mean(np_re),mean(est_re),mean(avar_re),bias_rep[ki,1],rmse_rep[ki,1],cvr_rep[ki,1],size_rep[ki,1])#,pwl_rep[ki,1],pwr_rep[ki,1])
        rm(est_re,avar_re,estsdm_re)
      }
    }
  }
  ###########################################################
  
  ### calculate statistics of time effects phi
  ###########################################################
  if (te>0) {
    for (tid in 1:Tobs) {
      truevalue = phi_te[tid]
      for (i in 1:ne) {
        ki = tid+Tobs*(i-1) 
        if (is.null(te_rep[ki,1])==0) {
          test_re = te_rep[ki,]
          tbias_rep[ki,1] = Bias(test_re,truevalue)
          trmse_rep[ki,1] = Rmse(test_re,truevalue)
          statte_rep[ki,1:2] = c(stat_rep[1+(i-1)*k,1],mean(test_re))
          statte_rep[ki,4:5] = c(tbias_rep[ki,1],trmse_rep[ki,1])
          if (is.null(tavar_rep[ki,1])==0) {
            tavar_re = tavar_rep[ki,]
            testsdm_re = cbind(test_re,sqrt(tavar_re))
            tcvr_rep[ki,1] = Coverage(truevalue,testsdm_re,rep)
            tpw_rep[,ki] = Power(truevalue,testsdm_re,rep) 
            tsize_rep[ki,1] = tpw_rep[which(as.matrix(seq(as.numeric(0+pwlb),as.numeric(0+pwrb),by=pwintv))==0),ki]
            statte_rep[ki,] = c(stat_rep[1+(i-1)*k,1],mean(test_re),mean(tavar_re),tbias_rep[ki,1],trmse_rep[ki,1],tcvr_rep[ki,1],tsize_rep[ki,1])
            rm(testsdm_re)
          }
          rm(test_re,tavar_re)
        }
      }
    }
    
  }
  
  ###########################################################
  if (gpe==1 & tmge==1) {
    em = "est"
  }
  
  output_theta = list(em,stat_rep,est_rep,avar_rep,acov_rep,np_rep,bias_rep,rmse_rep,cvr_rep,size_rep,pw_rep)
  names(output_theta) = c("em","stat","est","avar","acov","np","bias","rmse","cvr","size","pw")
  if (te==0) {
    output = output_theta
  }
  if (te>0) {
    output_te = list(em,statte_rep,te_rep,tavar_rep,tpw_rep)
    names(output_te) = c("em","stat","est","avar","pw")
    output = list(output_theta, output_te)
    names(output) = c("theta","te")
  }
  output
}


################################################################################
### Define Functions of DGP (Deme_i, Gen_balpanel)
################################################################################
Deme_i = function(paneldata_e,Tobs,i) {
  ti = Tobs
  ei = matrix(paneldata_e[(1+(i-1)*Tobs):(i*Tobs),],ti,1)
  qti= diag(ti)-matrix(1, nrow=ti, ncol=1) %*% t(matrix(1, nrow=ti, ncol=1))/ti 
  deti = det( t(ei) %*% qti %*% ei)
  return(deti)
}

# generate a panel data set in the long format
Gen_balpanel = function(nobs,Tobs,k,m_y,gauss_y,m_x,hetero_x,dist_x,ar_x,te_x,corr_e,para_case,kappa2,phi_te,idt){
  x_nT_long = matrix(,(nobs*Tobs),(k-1))
  e_nT_long = matrix(,(nobs*Tobs),(k-1))
  for (j in 1: (k-1)) {
    ### 1(1). x_it: generate errors IID(0,1) dist in {1,2,3,4} normal, chi-squared, uniform, binary
    if (dist_x==1) {
      e_nT = matrix(rnorm(nobs*Tobs,0,1),nobs,Tobs) # (n by T) normal(0,1)
      gamma2 = 0
    }
    if (dist_x==2) {
      e_0 = matrix(runif(nobs*Tobs,0,1),nobs,Tobs)
      e_nT = sqrt(12)*(e_0-1/2) # (n by T) uniform
      gamma2 = -6/5
    }
    
    ### 1(3) x_it: generate sigma_iv and xi_ix then plug in
    # hetero_x==0: homogeneous variance of x
    if (hetero_x==0) {
      sigma_vnT = matrix(1,nobs,Tobs)
    }
    # hetero_x==1: heterogeneous variance of x
    if (hetero_x==1) {
      sigma_vnT = matrix(sigma_vn[,j],nobs,Tobs) # (n by T) same in a row
    }
    v_nT = e_nT*sigma_vnT # (n by T)
    
    alphax_n = matrix(m_x[j,1],nobs,1) + axx_n[,j] # (n by 1)
    alphax_nT = matrix(alphax_n,nobs,Tobs) # (n by T) same in a row
    Th = 51 # number of existing periods before observed
    if (ar_x == 0) {
      phix_n = matrix(m_x[j,2],nobs,1) # (n by 1)
      phix_nT = matrix(phix_n,nobs,Tobs) # (n by T) same in a row
      ## include a common factor structure or time effects
      ft_n = t(matrix(rep(ft,nobs),Tobs,nobs)) # factors
      # factor loadings
      if (te_x==0) {
        gamma_n = matrix(0,nobs,Tobs)
      }
      if (te_x==1) {
        gamma_n = matrix(1,nobs,Tobs)
      }
      if (te_x==2) {
        gamma_n = matrix(runif(nobs,0,2),nobs,Tobs)
      }
      x_nT = alphax_nT*(1-phix_nT) + gamma_n*ft_n + v_nT # (n by T)
    }
    if (ar_x == 1) {
      tau_n = matrix(1,nobs,1) 
      phix_n = phixx_n[,j] # (n by 1) uniform (0,0.95)
      if (dist_x==1) {
        e_h = matrix(rnorm(nobs*Th,0,1),nobs,Th) # (n by T) normal(0,1)
      }
      if (dist_x==2) {
        e_h0 = matrix(runif(nobs*Th,0,1),nobs,Th)
        e_h = sqrt(12)*(e_h0-1/2) # (n by T) uniform
      }
      sigma_vh = matrix(sigma_vn[,j],nobs,Th)
      v_h = sigma_vh*e_h # (n by 51)
      v_hT = cbind(v_h,v_nT) # (n by (51+Tobs))
      x_hT = matrix(,nobs,(Th+Tobs))
      x_hT[,1] = matrix(0,nobs,1)
      if (te_x==0) {
        gamma_n = matrix(0,nobs,1)
      }
      if (te_x==1) {
        gamma_n = matrix(1,nobs,1)
      }
      if (te_x==2) {
        gamma_n = matrix(runif(nobs,0,2),nobs,1)
      }
      for ( j2 in 2:(Th+Tobs)) {
        fth_n = matrix(rep(fth[j2],nobs),nobs,1)
        x_hT[,j2] = alphax_n*(tau_n-phix_n) + gamma_n*fth_n + phix_n*x_hT[,(j2-1)]+sqrt(tau_n-phix_n^2)*v_hT[,j2]
      }
      x_nT = x_hT[,(Th+1):(Th+Tobs)]
    }
    
    e_nT_temp = matrix(t(e_nT),nobs*Tobs,1) # (nT by 1)
    e_nT_long[,j] = e_nT_temp 
    rm(e_nT_temp)
    
    x_nT_temp = matrix(t(x_nT),nobs*Tobs,1) # (nT by 1)
    x_nT_long[,j] = x_nT_temp 
    rm(x_nT_temp)
  }
  int_nT_long = matrix(1,nobs*Tobs) # (n by T)
  w_nT_long = cbind(int_nT_long, x_nT_long) # (nT by k)
  
  ### 1(2). x_it: calculate lambda_i
  id_n = matrix(seq(1,nobs,by=1),nobs,1)
  deme_n = matrix(sapply(id_n,Deme_i,paneldata_e=e_nT_long,Tobs=Tobs),nobs,1) # (n by 1)
  lambda_n = (deme_n-(Tobs-1))/sqrt(2*(Tobs-1)+gamma2/Tobs*((Tobs-1)^2)) # (n by 1)
  
  ### 2. Generate heterogeneous parameters with k=2: dim(sigma_x) = 1
  sigma_zeta = para_case[1:k]  # (1 by k)
  psi = para_case[(k+1):(2*k)]# (1 by k)
  zeta_n = matrix(,nobs,k)
  eta_n = matrix(,nobs,k)
  theta_n = matrix(,nobs,k)
  theta_nT_long = matrix(,nobs*Tobs,k)
  for (j in 1:k){
    zeta_n[,j] = rnorm(nobs,0,sigma_zeta[j])
    eta_n[,j] = psi[j]*lambda_n + zeta_n[,j]
    theta_n[,j] = matrix(m_y[j],nobs,1) + eta_n[,j]
    theta_nT_long[,j] = matrix(t(matrix(theta_n[,j],nobs,Tobs)),nobs*Tobs,1)
  }
  
  ### 3. Generate time effects in y_{it}
  phi_nT = matrix(phi_te,Tobs,nobs)
  phi_nT_long = matrix(phi_nT,nobs*Tobs,1)
  
  ### 4. y_{it}: generate errors
  if (gauss_y==1) {
    ey_nT = matrix(rnorm(nobs*Tobs,0,1),nobs,Tobs) # (n by T) normal(0,1)
  }
  if (gauss_y==0){
    ey_nT = matrix(0.5*rchisq(nobs*Tobs,df=2,ncp = 0)-1, nobs, Tobs) # (n by T) chi-squared 
  }
  if (corr_e==0) {
    rhoe_n = matrix(0,nobs,1)
  }
  ey_n0 = matrix(rnorm(nobs,0,1),nobs,1)
  ey_temp = cbind(ey_n0,matrix(,nobs,Tobs))
  tid = 1
  for (tid in 2:(Tobs+1)) {
    ey_temp[,tid] = rhoe_n*ey_temp[,(tid-1)] + sqrt(1-rhoe_n^2)*ey_nT[,(tid-1)]  
  }
  ey_nT = ey_temp[,2:(Tobs+1)]
  rm(ey_temp)
  
  if (hetrosk==1) {
    sigma_unT = matrix(sigma_un,nobs,Tobs) 
  }
  if (hetrosk==2) {
    sigma_unT = matrix(sqrt(lambda_n^2),nobs,Tobs)
  } 
  if (hetrosk==3) {
    sigma_unT = matrix(sqrt((e_nT_long^2)),nobs,Tobs)
  }
  u_nT = sqrt(kappa2)*sigma_unT*ey_nT # (n by T)
  u_nT_long = matrix(t(u_nT),nobs*Tobs,1) # (nT by k=1)
  
  ### 5. y_{it}: plug in all variables
  y_nT_long = phi_nT_long+rowSums(theta_nT_long*w_nT_long)+u_nT_long
  z_nt_long = cbind(idt,y_nT_long,x_nT_long)  # (nT by k+1) long-format panel data
  return(z_nt_long) 
}


################################################################################
### Set Key Parameters of DGP and Estimators
################################################################################
## Parameters of DGP
################################################################################
k = 2 # dim(wit) = k
m_y = cbind(1,1) # True value of parameters of ineterests
m_x = matrix(cbind(1,0),(k-1),2)

sigma_a = sqrt(0.2)
sigma_b = matrix(sqrt(c(0.5,0.75)),(k-1),2) # 2 cases
sigma = rbind(matrix(sigma_a,1,2),sigma_b) 
rho_eta = matrix(c(0,0,0.25,0.25,0.5,0.5),k,3) # 3 cases
PR2 = cbind(0.2,0.4) # 2 cases
di1 = length(PR2)
di2 = dim(sigma_b)[2]
di3 = dim(rho_eta)[2]
ncase = di1*di2*di3
case_list = seq(1,ncase,by=1)

case_table = matrix(,(1+k+k+k+k),ncase)
sigma_zeta_list = matrix(,k,ncase)
psi_list = matrix(,k,ncase)
for (i1 in 1:di1) {
  for (i2 in 1:di2) {
    for (i3 in 1:di3) {
      ic = i3+(i2-1)*di3+(i1-1)*di2*di3
      for (j in 1:k){
        sigma_zeta_list[j,ic] = sqrt(sigma[j,i2]^2*(1-rho_eta[j,i3]^2))
        psi_list[j,ic] = rho_eta[j,i3]*sigma[j,i2]
      }
      case_table[,ic] = rbind(PR2[i1],sigma[1,i2]^2,sigma[2,i2]^2,rho_eta[1,i3],rho_eta[2,i3],sigma_zeta_list[1,ic]^2,sigma_zeta_list[2,ic]^2,psi_list[1,ic],psi_list[2,ic])
    }
  }
}
para_list = rbind(sigma_zeta_list,psi_list)
para_list = para_list[,c(1,2,3,9)] # (1), (2), (3), higher PR^2
case_table = case_table[,c(1,2,3,9)] 

## Parameters of Estimators
a_list = as.matrix(c(1/3,0.35,1/2)) # TMG: rates for trimming
agp_list = as.matrix(c(0.35/2,1/4,1/3))  # GP

# number of estimates: GP, TMG
nest = dim(agp_list)[1]+dim(a_list)[1] 

## Input data and fix the dimension
TNlist = c(1000,2000,5000,10000)
TTlist = c(2,3,4,5,6,8)
NT_list = expand.grid(TNlist,TTlist) 
rep = 2000 # number of replications for simulation
bal_panel = 1 # (0,1) Paneldata sets are balanced or not

################################################################################

## Setting the model in simulation
################################################################################
## combo of n and T
Nlist = c(1000,2000,5000,10000)
Tlist = c(2,3)
NT = expand.grid(Nlist,Tlist) 

#### parameters of robustness
hetero_x = 1 # (0,1) Errors in regressor x are heteroskedastic or not. 
ar_x = 1 # (0,1) Regressor x follow an AR process or not
corr_e = 0 # (0,1) 
te_x = 0 # (0,1,2) no time effects, a common time effect, a common factor in x_{it}
hetrosk = 1 # c(1,2,3) random, correlated case (a), correlated case (b)

#### different cases considered
gauss_y = 0 # (0,1)  Errors in outcome y are Gaussian or chi-squared
te = 0 # for estimation: (0,1)
case = 3 # cases of parameters' values: c(1,2,3,4)
################################################################################

### Compare TMG and GP using different threshold values
################################################################################
dist_x = 1 # distribution of errors in x: (1,2) Gaussian, uniform
name = paste("k2",dist_x,sep="dx")
if (ar_x==1) {
  name = paste(name,"arx",sep="_")
}
k2_table = get(name)

for (l in 1:dim(NT)[1]) {
  nobs = NT[l,1]
  Tobs = NT[l,2]
  Tid = which(TTlist==Tobs)
  if (case==0) {
    kappa2 = 8
  } else {
    kappa2 = k2_table[Tid,case]
  }
  rm(Tid)
  
  ## index of n and t for balanced paneldata sets
  Tl = matrix(seq(1,Tobs,by=1),Tobs,1)
  Tm = matrix(matrix(Tl,Tobs,nobs),nobs*Tobs,1)
  nl = matrix(seq(1,nobs,by=1),nobs,1)
  nm = matrix(t(matrix(nl,nobs,Tobs)),nobs*Tobs,1)
  idt = cbind(nm,Tm)
  rm(Tl,Tm,nl,nm)
  para_case = para_list[,case] # sigma_zeta, psi
  
  #run simulation
  ########################
  ### common time effects
  if (te==0) {
    phi_te = rep(0,Tobs) # T=3 (1,1,-2)
  }
  if (te==1) {
    phi_1 = seq(1,Tobs-1)
    phi_te = c(phi_1,-sum(phi_1))
  }
  ### factors of interactive effects in x_{it}
  ft = seq(1,Tobs,by=1) 
  set.seed(2022202299)
  fth = matrix(,Tobs+51,1); fth[1]=0; # with a zero initial value
  for (tid in 2:(Tobs+51) ) {
    vt = rnorm(1,0,1)
    fth[tid] = 0.9*fth[tid-1]+sqrt(1-0.9^2)*vt;rm(vt) 
  }
  ft = fth[52:(Tobs+51)] # for t=1,2,...,T
  
  ### individual nuisance parameters
  set.seed(20222022)
  rhoe_n = matrix(runif(nobs,0,0.95),nobs,1) # hetero AR coeff in serial correlated errors
  
  set.seed(102021)
  sigma_vn = matrix(sqrt(0.5*rnorm(nobs,0,1)^2+0.5),nobs,(k-1)) # (n by k-1)
  sigma_un = matrix(sqrt(0.5*rnorm(nobs,0,1)^2+0.5),nobs,1) # (n by 1)
  axx_n = matrix(rnorm(nobs,0,1),nobs,(k-1)) # (n by k-1)
  phixx_n = matrix(runif(nobs,0,0.95),nobs,(k-1)) # (n by k-1)
  
  if (te==0) {
    simu_temp = MCS_rep(rep,nobs,Tobs,k,m_y,gauss_y,m_x,hetero_x,dist_x,ar_x,te_x,corr_e,para_case,kappa2,bal_panel,phi_te,a_list,agp_list,te,gpe=1,tmge=1)
  }
  if (te>0) {
    simu_temp = MCS_rep(rep,nobs,Tobs,k,m_y,gauss_y,m_x,hetero_x,dist_x,ar_x,te_x,corr_e,para_case,kappa2,bal_panel,phi_te,a_list,agp_list,te,gpe=1,tmge=1)
  }
  
  if (te==0) {
    em = simu_temp$em
    name1 = paste(em,dist_x,sep="_d")
    name2 = paste(name1,case,sep="c")
    name3 = paste(name2,nobs,sep="_n")
    name4 = paste(name3,Tobs,sep="_T")
    assign(name4,simu_temp)
  }
  if (te>0) {
    em =simu_temp$theta$em
    name1 = paste("theta",dist_x,sep="_d")
    name2 = paste(name1,case,sep="c")
    name3 = paste(name2,nobs,sep="_n")
    name4 = paste(name3,Tobs,sep="_T")
    assign(name4,simu_temp$theta)
    
    name1 = paste("te",dist_x,sep="_d")
    name2 = paste(name1,case,sep="c")
    name3 = paste(name2,nobs,sep="_n")
    name4 = paste(name3,Tobs,sep="_T")
    assign(name4,simu_temp$te)
  }
}
fn0 = paste(em,te,sep="_te")
### 1. distribution of errors in x
if (dist_x == 1) {
  fn1 = paste(fn0,"norm",sep="_")
}
if (dist_x == 2) {
  fn1 = paste(fn0,"unif",sep="_")
}
### 2. with or without interactive effects in x
fn2 = paste(fn1,te_x,sep="_tex")
### 3. non-Gaussian errors in panels or dynamics in x
if (gauss_y == 1 & ar_x == 0) {
  fn3 = fn2
}
if (gauss_y==0) {
  fn3 = paste(fn2,"chi2",sep="_")
}
if (ar_x==1) {
  fn3 = paste(fn2,"arx",sep="_")
}
### 4. case of parameters' values
fn4 = paste(fn3,case,sep="_")
### 5. sample size n of individuals
ntid = 0 
for (idx in 1:dim(NT_list)[1]) {
  ntid = ntid + idx*(NT_list[idx,1]==nobs)*(NT_list[idx,2]==Tobs)
}
if (ntid<10) {
  fn5 = paste(fn4,ntid,sep="0")
} else {
  fn5 = paste(fn4,ntid,sep="")
}
### add extension as "RData"
fn6 = paste(fn5,"_thresholds.RData",sep="")
save.image(file = fn6) 
################################################################################

### Compare TMG using different threshold values with uniformly distributed errors in x
################################################################################
dist_x = 2 
name = paste("k2",1,sep="dx")
if (ar_x==1) {
  name = paste(name,"arx",sep="_")
}
k2_table = get(name)
for (l in 1:dim(NT)[1]) {
  nobs = NT[l,1]
  Tobs = NT[l,2]
  Tid = which(TTlist==Tobs)
  if (case==0) {
    kappa2 = 8
  } else {
    kappa2 = k2_table[Tid,case]
  }
  rm(Tid)
  
  ## index of n and t for balanced paneldata sets
  Tl = matrix(seq(1,Tobs,by=1),Tobs,1)
  Tm = matrix(matrix(Tl,Tobs,nobs),nobs*Tobs,1)
  nl = matrix(seq(1,nobs,by=1),nobs,1)
  nm = matrix(t(matrix(nl,nobs,Tobs)),nobs*Tobs,1)
  idt = cbind(nm,Tm)
  rm(Tl,Tm,nl,nm)
  para_case = para_list[,case] # sigma_zeta, psi
  
  #run simulation
  ########################
  ### common time effects
  if (te==0) {
    phi_te = rep(0,Tobs) # T=3 (1,1,-2)
  }
  if (te==1) {
    phi_1 = seq(1,Tobs-1)
    phi_te = c(phi_1,-sum(phi_1))
  }
  ### factors of interactive effects in x_{it}
  ft = seq(1,Tobs,by=1) 
  set.seed(2022202299)
  fth = matrix(,Tobs+51,1); fth[1]=0; # with a zero initial value
  for (tid in 2:(Tobs+51) ) {
    vt = rnorm(1,0,1)
    fth[tid] = 0.9*fth[tid-1]+sqrt(1-0.9^2)*vt;rm(vt) 
  }
  ft = fth[52:(Tobs+51)] # for t=1,2,...,T
  
  ### individual nuisance parameters
  set.seed(20222022)
  rhoe_n = matrix(runif(nobs,0,0.95),nobs,1) # hetero AR coeff in serial correlated errors
  
  set.seed(102021)
  sigma_vn = matrix(sqrt(0.5*rnorm(nobs,0,1)^2+0.5),nobs,(k-1)) # (n by k-1)
  sigma_un = matrix(sqrt(0.5*rnorm(nobs,0,1)^2+0.5),nobs,1) # (n by 1)
  axx_n = matrix(rnorm(nobs,0,1),nobs,(k-1)) # (n by k-1)
  phixx_n = matrix(runif(nobs,0,0.95),nobs,(k-1)) # (n by k-1)
  
  if (te==0) {
    simu_temp = MCS_rep(rep,nobs,Tobs,k,m_y,gauss_y,m_x,hetero_x,dist_x,ar_x,te_x,corr_e,para_case,kappa2,bal_panel,phi_te,a_list,agp_list,te,gpe=0,tmge=1)
  }
  if (te>0) {
    simu_temp = MCS_rep(rep,nobs,Tobs,k,m_y,gauss_y,m_x,hetero_x,dist_x,ar_x,te_x,corr_e,para_case,kappa2,bal_panel,phi_te,a_list,agp_list,te,gpe=0,tmge=1)
  }
  
  if (te==0) {
    em = simu_temp$em
    name1 = paste(em,dist_x,sep="_d")
    name2 = paste(name1,case,sep="c")
    name3 = paste(name2,nobs,sep="_n")
    name4 = paste(name3,Tobs,sep="_T")
    assign(name4,simu_temp)
  }
  if (te>0) {
    em =simu_temp$theta$em
    name1 = paste("theta",dist_x,sep="_d")
    name2 = paste(name1,case,sep="c")
    name3 = paste(name2,nobs,sep="_n")
    name4 = paste(name3,Tobs,sep="_T")
    assign(name4,simu_temp$theta)
    
    name1 = paste("te",dist_x,sep="_d")
    name2 = paste(name1,case,sep="c")
    name3 = paste(name2,nobs,sep="_n")
    name4 = paste(name3,Tobs,sep="_T")
    assign(name4,simu_temp$te)
  }
}
fn0 = paste(em,te,sep="_te")
### 1. distribution of errors in x
if (dist_x == 1) {
  fn1 = paste(fn0,"norm",sep="_")
}
if (dist_x == 2) {
  fn1 = paste(fn0,"unif",sep="_")
}
### 2. with or without interactive effects in x
fn2 = paste(fn1,te_x,sep="_tex")
### 3. non-Gaussian errors in panels or dynamics in x
if (gauss_y == 1 & ar_x == 0) {
  fn3 = fn2
}
if (gauss_y==0) {
  fn3 = paste(fn2,"chi2",sep="_")
}
if (ar_x==1) {
  fn3 = paste(fn2,"arx",sep="_")
}
### 4. case of parameters' values
fn4 = paste(fn3,case,sep="_")
### 5. sample size n of individuals
ntid = 0 
for (idx in 1:dim(NT_list)[1]) {
  ntid = ntid + idx*(NT_list[idx,1]==nobs)*(NT_list[idx,2]==Tobs)
}
if (ntid<10) {
  fn5 = paste(fn4,ntid,sep="0")
} else {
  fn5 = paste(fn4,ntid,sep="")
}
### add extension as "RData"
fn6 = paste(fn5,"_thresholds.RData",sep="")
save.image(file = fn6) 
################################################################################

# Report MC results of TMG and GP using different threshold values: Table S.5 
##############################################################################
# Create a new workbook
wb <- createWorkbook()

# Create a style for center-aligning the numbers
##############################################################################
center_style <- createStyle(halign = "center")
right <- createStyle(halign = "right")
left <- createStyle(halign = "left")
bbs <- createStyle(border = "bottom",borderStyle="thin")
lbs <- createStyle(border = "bottom",borderStyle="double")
tbs <- createStyle(border = "top",borderStyle="double")
wrap_text_style <- createStyle(wrapText = TRUE)

sn = "Table S.5"
nstat = 4 # perncent trimmed, bias, rmse, size
addWorksheet(wb, sn)

Nlist = c(1000,2000,5000,10000)
Tlist = c(2,3)

nest = 2 
panel_nrow = nest*3*length(Nlist)
panel_ncol = nstat*length(Tlist) 
tab = matrix(,panel_nrow,panel_ncol) 

load("est_te0_norm_tex0_arx_308_thresholds.RData")
dist_x = 1; case = 3 

for (nid in 1:length(Nlist)) {
  nobs = Nlist[nid]
  rowid = (1:6)+(nid-1)*6
  #### the respective rows of estimation results
  id_list = c(8,10,12,2,4,6)
  
  ## for T=2 and T=3
  for (idx in c(1,2)) {
    Tobs = Tlist[idx]
    colid = (1:4)+(idx-1)*4
    
    #### Input data
    ########################
    temp_stat = matrix(,nrow=nest,ncol=nstat)
    name1 = paste("est",dist_x,sep="_d")
    name3 = paste(name1,case,sep="c")
    name4 = paste(name3,nobs,sep="_n")
    name5 = paste(name4,Tobs,sep="_T")
    en = 1
    temp = tryCatch(get(name5),error=function(e) print(en))
    if (is.list(temp)==1 ){
      temp_stat = temp$stat[id_list,c(1,4,5,7)]
    }
    #######################
    
    #### Fill the table
    ########################
    tab[rowid,colid] = temp_stat
  }
}
writeData(wb, sn, x = "Table S.5: Bias, RMSE and size of TMG and GP estimators of beta_0 (E(beta_i)=beta_0=1) for different values of the threshold parameters, alpha and alpha_{GP}, in the baseline model without time effects and with correlated heterogeneity, rho_{beta}=0.5", startCol = 1, startRow = 1, colNames = FALSE)
writeData(wb, sn, x = "T=2", startCol = 3, startRow = 2, colNames = FALSE)
writeData(wb, sn, x = "T=3", startCol = 8, startRow = 2, colNames = FALSE)

## format data
np_0 = tab[,c(1,5)]
np_1 = np_0
for (i in 1:length(np_0)) {
  if (is.na(np_0[i]) == 0) {
    np_1[i] = format(round(np_0[i]*100, 1), nsmall = 1)
  } 
}
bias_0 = tab[,c(2,6)]
bias_1 = bias_0
for (i in 1:length(bias_0)) {
  if (is.na(bias_0[i]) == 0) {
    bias_1[i] = format(round(bias_0[i], 3), nsmall = 3) #round(bias_0[i],digits=3)
  } 
}
rmse_0 = tab[,c(3,7)]
rmse_1 = rmse_0
for (i in 1:length(rmse_0)) {
  if (is.na(rmse_0[i]) == 0) {
    rmse_1[i] = format(round(rmse_0[i], 2), nsmall = 2) #round(rmse_0[i],digits=3)
  } 
}
size_0 = tab[,c(4,8)]
size_1 = size_0
for (i in 1:length(size_0)) {
  if (is.na(size_0[i]) == 0) {
    size_1[i] = format(round(size_0[i]*100, 1), nsmall = 1)
  }
}
tab =matrix(rbind(np_1,bias_1,rmse_1,size_1),24,8)

r1 = rep(c("TMG","TMG","TMG","GP","GP","GP"),4)
r2 = rep(c("1/3","0.35","0.50","0.35","0.50","2/3"),4)
ncv = matrix("",24,1)
tab0 = cbind(r1,r2,tab[,1:4],ncv,tab[,5:8])
nrv = matrix("",1,ncol(tab0))
h = rbind(nrv,tab0[1:6,],nrv,tab0[7:12,],nrv,tab0[13:18,],nrv,tab0[19:24,])

mergeCells(wb, sheet = sn, cols = 1:11, rows = 1)
mergeCells(wb, sheet = sn, cols = 3:6, rows = 2)
mergeCells(wb, sheet = sn, cols = 8:11, rows = 2)

h1 = c("","","hat{pi}","","","Size","","hat{pi}","","","Size")
h2 = c("Estimator","alpha/alpha_{GP}","(*100)","Bias","RMSE","(*100)","","(*100)","Bias","RMSE","(*100)")
h = rbind(h1,h2,h)
rownames(h) <- NULL
colnames(h) <- NULL
writeData(wb,sn, x = h, startCol = 1, startRow = 3,colNames = FALSE, rowNames = FALSE)
writeData(wb, sn, x = "n=1,000", startCol = 3, startRow = 5, colNames = FALSE)
writeData(wb, sn, x = "n=2,000", startCol = 3, startRow = 12, colNames = FALSE)
writeData(wb, sn, x = "n=5,000", startCol = 3, startRow = 19, colNames = FALSE)
writeData(wb, sn, x = "n=10,000", startCol = 3, startRow = 26, colNames = FALSE)
mergeCells(wb, sheet = sn, cols = 3:11, rows = 5)
mergeCells(wb, sheet = sn, cols = 3:11, rows = 12)
mergeCells(wb, sheet = sn, cols = 3:11, rows = 19)
mergeCells(wb, sheet = sn, cols = 3:11, rows = 26)


addStyle(wb,sn,style = right, rows = c(6:11,13:18,20:25,27:32),cols = 1:(ncol(h)), gridExpand = T)
addStyle(wb,sn,style = left, rows = 1:32,cols = 1, gridExpand = T)
addStyle(wb,sn,style = center_style, rows = c(2:5,12,19,26),cols = 1:(ncol(h)), gridExpand = T)
addStyle(wb,sn,style = center_style, rows = 1:32, cols = 2, gridExpand = T)
addStyle(wb,sn,style = wrap_text_style, rows = 1,cols = 1:(ncol(h)), gridExpand = T,stack=T)
addStyle(wb,sn,style = bbs, rows = 2,cols = c(3:6,8:11), gridExpand = T,stack=T)
addStyle(wb,sn,style = bbs, rows = c(4,5,12,19,26),cols = 1:(ncol(h)), gridExpand = T,stack=T)
addStyle(wb,sn,style = tbs, rows = 2,cols = 1:(ncol(h)), gridExpand = T,stack=T)
addStyle(wb,sn,style = lbs, rows = (nrow(h)+2),cols = 1:(ncol(h)), gridExpand = T,stack=T)
##############################################################################


# Report MC results of TMG under different thresholds with uniform errors in x: Table S.11
##############################################################################
load("TMG_te0_unif_tex0_arx_308_thresholds.RData")
dist_x = 2; case = 3 
sn = "Table S.11"

nstat = 4 # perncent trimmed, bias, rmse, size
addWorksheet(wb, sn)

Nlist = c(1000,2000,5000,10000)
Tlist = c(2,3)

nest = 1
panel_nrow = nest*3*length(Nlist)
panel_ncol = nstat*length(Tlist) 
tab = matrix(,panel_nrow,panel_ncol) 

for (nid in 1:length(Nlist)) {
  nobs = Nlist[nid]
  rowid = (1:3)+(nid-1)*3
  #### the respective rows of estimation results
  id_list = c(8,10,12)
  
  ## for T=2 and T=3
  for (idx in c(1,2)) {
    Tobs = Tlist[idx]
    colid = (1:4)+(idx-1)*4
    
    #### Input data
    ########################
    temp_stat = matrix(,nrow=nest,ncol=nstat)
    name1 = paste("TMG",dist_x,sep="_d")
    name3 = paste(name1,case,sep="c")
    name4 = paste(name3,nobs,sep="_n")
    name5 = paste(name4,Tobs,sep="_T")
    en = 1
    temp = tryCatch(get(name5),error=function(e) print(en))
    if (is.list(temp)==1 ){
      temp_stat = temp$stat[id_list,c(1,4,5,7)]
    }
    #######################
    
    #### Fill the table
    ########################
    tab[rowid,colid] = temp_stat
  }
}

writeData(wb, sn, x = "Table S.11: Bias, RMSE and size of the TMG estimator of beta_0 (E(beta_i)=beta_0=1) for different values of the threshold parameters, alpha and alpha_{GP}, in the baseline model without time effects and with correlated heterogeneity, rho_{beta}=0.5", startCol = 1, startRow = 1, colNames = FALSE)
writeData(wb, sn, x = "T=2", startCol = 3, startRow = 2, colNames = FALSE)
writeData(wb, sn, x = "T=3", startCol = 8, startRow = 2, colNames = FALSE)

## format data
np_0 = tab[,c(1,5)]
np_1 = np_0
for (i in 1:length(np_0)) {
  if (is.na(np_0[i]) == 0) {
    np_1[i] = format(round(np_0[i]*100, 1), nsmall = 1)
  } 
}
bias_0 = tab[,c(2,6)]
bias_1 = bias_0
for (i in 1:length(bias_0)) {
  if (is.na(bias_0[i]) == 0) {
    bias_1[i] = format(round(bias_0[i], 3), nsmall = 3) #round(bias_0[i],digits=3)
  } 
}
rmse_0 = tab[,c(3,7)]
rmse_1 = rmse_0
for (i in 1:length(rmse_0)) {
  if (is.na(rmse_0[i]) == 0) {
    rmse_1[i] = format(round(rmse_0[i], 2), nsmall = 2) #round(rmse_0[i],digits=3)
  } 
}
size_0 = tab[,c(4,8)]
size_1 = size_0
for (i in 1:length(size_0)) {
  if (is.na(size_0[i]) == 0) {
    size_1[i] = format(round(size_0[i]*100, 1), nsmall = 1)
  }
}
tab =matrix(rbind(np_1,bias_1,rmse_1,size_1),12,8)

r1 = rep(c("TMG","TMG","TMG"),4)
r2 = rep(c("1/3","0.35","0.50"),4)
ncv = matrix("",12,1)
tab0 = cbind(r1,r2,tab[,1:4],ncv,tab[,5:8])
nrv = matrix("",1,ncol(tab0))
h = rbind(nrv,tab0[1:3,],nrv,tab0[4:6,],nrv,tab0[7:9,],nrv,tab0[10:12,])

mergeCells(wb, sheet = sn, cols = 1:11, rows = 1)
mergeCells(wb, sheet = sn, cols = 3:6, rows = 2)
mergeCells(wb, sheet = sn, cols = 8:11, rows = 2)

h1 = c("","","hat{pi}","","","Size","","hat{pi}","","","Size")
h2 = c("Estimator","alpha","(*100)","Bias","RMSE","(*100)","","(*100)","Bias","RMSE","(*100)")
h = rbind(h1,h2,h)
rownames(h) <- NULL
colnames(h) <- NULL
writeData(wb,sn, x = h, startCol = 1, startRow = 3,colNames = FALSE, rowNames = FALSE)
writeData(wb, sn, x = "n=1,000", startCol = 3, startRow = 5, colNames = FALSE)
writeData(wb, sn, x = "n=2,000", startCol = 3, startRow = 9, colNames = FALSE)
writeData(wb, sn, x = "n=5,000", startCol = 3, startRow = 13, colNames = FALSE)
writeData(wb, sn, x = "n=10,000", startCol = 3, startRow = 17, colNames = FALSE)
mergeCells(wb, sheet = sn, cols = 3:11, rows = 5)
mergeCells(wb, sheet = sn, cols = 3:11, rows = 9)
mergeCells(wb, sheet = sn, cols = 3:11, rows = 13)
mergeCells(wb, sheet = sn, cols = 3:11, rows = 17)


addStyle(wb,sn,style = right, rows = c(6:8,10:12,14:16,18:20),cols = 1:(ncol(h)), gridExpand = T)
addStyle(wb,sn,style = left, rows = 1:20, cols = 1, gridExpand = T)
addStyle(wb,sn,style = center_style, rows = c(2:5,9,13,17),cols = 1:(ncol(h)), gridExpand = T)
addStyle(wb,sn,style = center_style, rows = 1:20, cols = 2, gridExpand = T)
addStyle(wb,sn,style = wrap_text_style, rows = 1,cols = 1:(ncol(h)), gridExpand = T,stack=T)
addStyle(wb,sn,style = bbs, rows = 2,cols = c(3:6,8:11), gridExpand = T,stack=T)
addStyle(wb,sn,style = bbs, rows = c(4,5,9,13,17),cols = 1:(ncol(h)), gridExpand = T,stack=T)
addStyle(wb,sn,style = tbs, rows = 2,cols = 1:(ncol(h)), gridExpand = T,stack=T)
addStyle(wb,sn,style = lbs, rows = (nrow(h)+2),cols = 1:(ncol(h)), gridExpand = T,stack=T)
##############################################################################

saveWorkbook(wb, file = "TMG_MC_thresholds_results.xlsx",overwrite = TRUE)

cat("MC Results of estimation with different threshold parameters have been written to the excel file TMG_MC_thresholds_results.xlsx.")

rm(list=ls())

list.of.packages <- c("sm")
new.packages <- list.of.packages[!(list.of.packages %in% installed.packages()[,"Package"])]
if(length(new.packages)) install.packages(new.packages)
library(sm)

load("est_te0_norm_tex0_arx_308_thresholds.RData")

# Plot Figures S.2 and S.3
###############################################################################
te=0; gauss_y=0; ar_x=1; corr_e=0; te_x=0; Tl = c(2,3); dist_x = 1; case =3; hetero_x=1; 
Nlist = c(1000,2000,5000,10000)

tt = rep(c(2,3),4)
nn = matrix(rbind(Nlist,Nlist),8,1)
cc = rep(case,8)

#### Figure panel formats: ns by 1 for comparing TMG, GP and SU given a NT combo
panel_nrow = 4
panel_ncol = 2
panel_id = seq(1,panel_nrow*panel_ncol,by=1)
k=2; nest=5

pidx = matrix(c(0,1,1,0,2,1),3,k) # alpha,beta
phead = rep(c("1,000","2,000","5,000","10,000"),2)

for (idx in 2) {
  tej = pidx[1,idx] ## results of phi: tej=1; results of E(theta_i): tej=0
  j = pidx[2,idx] ## for regressor j
  
  #### Set legends
  #################################
  id_list = c(1,2)
  le_1 = expression(paste("TMG threshold with ",alpha==0.35,sep=""))  
  le_2 = expression(paste("GP bandwidth with ",alpha[GP]==0.35/2,sep=""))
  le = c(le_1,le_2)
  #################################
  
  #### Set names of the figure
  #################################
  pngname = paste("Figure S.2",".png",sep = "")
  #################################
  
  #### Set width and height, no. of panels of plots
  #################################
  png(pngname, units="in", width=32, height=36, res=50) # (2 by 2) T=2
  par(mai=c(1.5,1.2,1.2,1.2),xpd=TRUE, mfrow=c(panel_nrow,panel_ncol),omi=c(1.5,0.5,0.5,0.5),family="Times New Roman") # (b,l,t,r)
  #################################
  
  p = 1
  for (p in panel_id) {
    nobs = nn[p]
    Tobs = tt[p]
    case = cc[p]
    
    #### Set axes
    #################################
    truev = pidx[3,idx] ## true value of a parameter
    pwlb=-2.5; pwrb=2.5; pwintv=0.01;
    pwgrid = length(as.matrix(seq(as.numeric(truev+pwlb),as.numeric(truev+pwrb),by=pwintv)))
    mx = seq(truev+pwlb,truev+pwrb,by=pwintv)
    lb = which(mx-truev+1==0) 
    ub = length(mx)-lb+1 #which(mx-truev-1.2==0) 
    xmin = round(mx[lb],digits=2)
    xmax = round(mx[ub],digits=2)
    ymin = 0
    ymax = 1
    #################################
    
    #### Load results
    #################################
    Tobs = tt[p]; nobs = nn[p]; case = cc[p]
    tej = pidx[1,idx] ## results of phi: tej=1; results of E(theta_i): tej=0
    
    pw1 = matrix(0,501,2)
    
    k = 2; 
    id_list = c(8,0)
    name1 = paste("est","_d",dist_x,"c",case,"_n",nobs,"_T",Tobs,sep="")
    en = 1; temp = tryCatch(get(name1),error=function(e) print(en))
    j = pidx[2,idx] ## for regressor j
    if (is.list(temp)==1 ){
      pw1 = temp$pw[,(id_list+j)] 
    }
    pw_temp= pw1
    #################################
    
    #### Add panels' names 
    #################################
    if (p==1) {
      main_1 = "T=2"
    }
    if (p==2) {
      main_1 = "T=3"
    }
    #################################
    
    #### Plot curves
    #################################
    if (p %in% c(1,2)) { # (b,l,t,r)
      par(mar=c(11,10,12,10))
    }
    if (p %in% c(3,4)) {
      par(mar=c(11,10,11,10))
    }
    if (p %in% c(5,6)) {
      par(mar=c(11,10,11,10))
    }
    if (p %in% c(7,8)) {
      par(mar=c(13,10,11,10))
    }
    plot(mx[lb:ub],pw_temp[lb:ub,1],type="l",col=1,lwd=5,lty=1,xlim=c(xmin,xmax),ylim=c(ymin,ymax),xaxs="i",yaxs="i",axes=F,ylab="",xlab="")
    lines(mx[lb:ub],pw_temp[lb:ub,2],type="l",col=4,lwd=5,lty=5,xlim=c(xmin,xmax),ylim=c(ymin,ymax))
    #lines(mx[lb:ub],pw_temp[lb:ub,3], type="l", col=2, lwd=5,lty=4,xlim=c(xmin, xmax), ylim=c(ymin, ymax))
    #title(mgp=c(3.5,2.2,0),main=main_1,font.main=1,cex.lab=2.8,cex.main=5.8)
    if (p %in% c(1,2)) {
      #title(mgp=c(10,10,10),main=main_1,font.main=1,cex.main=7)
      mtext(main_1, side = 1, line = -52, at = 1 , cex = 5)
    }
    axis(side=1, at=seq(xmin, xmax, by=0.2), mgp=c(2, 3, 0), cex.axis=4)
    axis(side=2, at=seq(0.2, 1, by=0.2), mgp=c(3.5, 1.5, 0), cex.axis=4)######## Visualization
    arrows(truev,-0.01, truev, 1, length = 0,lty = 3,lwd=3.5) # denote the true value
    arrows(xmin,0.05,xmax,0.05, length = 0,lty = 3,lwd=3.5) # denote a line of 5% probability
    mtext("5%", side = 1, line = -3, at = 2.08 , cex = 3)
    box(col="black")
    mtext("Power", side = 2, line = 4.8, at = 0.92 , cex = 3.2)
    if (j==1) {
      mtext(expression(alpha), side = 1, line = 7, at = xmax, cex = 3)
    }
    if (j==2) {
      mtext(expression(beta), side = 1, line = 7, at = xmax, cex = 3)
    }
    #################################
  } ## end p (1 to NT) different panels in one figure
  
  mtext("n=1,000", side = 3, cex = 4, font = 1,
        line = -7,
        outer = TRUE)
  
  mtext("n=2,000", side = 3, cex = 4, font = 1,
        line = -69,
        outer = TRUE)
  
  mtext("n=5,000", side = 3, cex = 4, font = 1,
        line = -132,
        outer = TRUE)
  
  mtext("n=10,000", side = 3, cex = 4, font = 1,
        line = -197,
        outer = TRUE)
  
  par(fig = c(0, 1, 0, 1), oma = c(1, 0, 0, 0), mar = c(0, 0, 0, 0), new = TRUE)
  plot(0, 0, type = 'l', bty = 'n', xaxt = 'n', yaxt = 'n')
  legend("bottom",col=c(1,4),lwd=4,lty=c(1,5),legend=le,cex=5.5,xpd=TRUE,horiz=TRUE) #bty="n",inset=c(0,-0.33),
  dev.off()
}


for (idx in 2) {
  tej = pidx[1,idx] ## results of phi: tej=1; results of E(theta_i): tej=0
  j = pidx[2,idx] ## for regressor j
  
  #### Set legends
  #################################
  id_list = c(1,2)
  le_1 = expression(paste("TMG threshold with ",alpha==1/3,sep=""))  
  le_2 = expression(paste("GP bandwidth with ",alpha[GP]==1/3,sep=""))
  le = c(le_1,le_2)
  #################################
  
  #### Set names of the figure
  #################################
  pngname = paste("Figure S.3",".png",sep = "")
  #################################
  
  #### Set width and height, no. of panels of plots
  #################################
  png(pngname, units="in", width=32, height=36, res=50) # (2 by 2) T=2
  par(mai=c(1.5,1.2,1.2,1.2),xpd=TRUE, mfrow=c(panel_nrow,panel_ncol),omi=c(1.5,0.5,0.5,0.5),family="Times New Roman") # (b,l,t,r)
  #################################
  
  p = 1
  for (p in panel_id) {
    nobs = nn[p]
    Tobs = tt[p]
    case = cc[p]
    
    #### Set axes
    #################################
    truev = pidx[3,idx] ## true value of a parameter
    pwlb=-2.5; pwrb=2.5; pwintv=0.01;
    pwgrid = length(as.matrix(seq(as.numeric(truev+pwlb),as.numeric(truev+pwrb),by=pwintv)))
    mx = seq(truev+pwlb,truev+pwrb,by=pwintv)
    lb = which(mx-truev+1==0) 
    ub = length(mx)-lb+1 #which(mx-truev-1.2==0) 
    xmin = round(mx[lb],digits=2)
    xmax = round(mx[ub],digits=2)
    ymin = 0
    ymax = 1
    #################################
    
    #### Load results
    #################################
    Tobs = tt[p]; nobs = nn[p]; case = cc[p]
    tej = pidx[1,idx] ## results of phi: tej=1; results of E(theta_i): tej=0
    
    pw1 = matrix(0,501,2)
    
    k = 2; 
    id_list = c(6,4)
    name1 = paste("est","_d",dist_x,"c",case,"_n",nobs,"_T",Tobs,sep="")
    en = 1; temp = tryCatch(get(name1),error=function(e) print(en))
    j = pidx[2,idx] ## for regressor j
    if (is.list(temp)==1 ){
      pw1 = temp$pw[,(id_list+j)] # TMG
    }
    pw_temp= pw1
    #################################
    
    #### Add panels' names 
    #################################
    if (p==1) {
      main_1 = "T=2"
    }
    if (p==2) {
      main_1 = "T=3"
    }
    #################################
    
    
    #### Plot curves
    #################################
    if (p %in% c(1,2)) { # (b,l,t,r)
      par(mar=c(11,10,12,10))
    }
    if (p %in% c(3,4)) {
      par(mar=c(11,10,11,10))
    }
    if (p %in% c(5,6)) {
      par(mar=c(11,10,11,10))
    }
    if (p %in% c(7,8)) {
      par(mar=c(13,10,11,10))
    }
    plot(mx[lb:ub],pw_temp[lb:ub,1],type="l",col=1,lwd=5,lty=1,xlim=c(xmin,xmax),ylim=c(ymin,ymax),xaxs="i",yaxs="i",axes=F,ylab="",xlab="")
    lines(mx[lb:ub],pw_temp[lb:ub,2],type="l",col=4,lwd=5,lty=5,xlim=c(xmin,xmax),ylim=c(ymin,ymax))
    #lines(mx[lb:ub],pw_temp[lb:ub,3], type="l", col=2, lwd=5,lty=4,xlim=c(xmin, xmax), ylim=c(ymin, ymax))
    #title(mgp=c(3.5,2.2,0),main=main_1,font.main=1,cex.lab=2.8,cex.main=5.8)
    if (p %in% c(1,2)) {
      #title(mgp=c(10,10,10),main=main_1,font.main=1,cex.main=7)
      mtext(main_1, side = 1, line = -52, at = 1 , cex = 5)
    }
    axis(side=1, at=seq(xmin, xmax, by=0.2), mgp=c(2, 3, 0), cex.axis=4)
    axis(side=2, at=seq(0.2, 1, by=0.2), mgp=c(3.5, 1.5, 0), cex.axis=4)######## Visualization
    arrows(truev,-0.01, truev, 1, length = 0,lty = 3,lwd=3.5) # denote the true value
    arrows(xmin,0.05,xmax,0.05, length = 0,lty = 3,lwd=3.5) # denote a line of 5% probability
    mtext("5%", side = 1, line = -3, at = 2.08 , cex = 3)
    box(col="black")
    mtext("Power", side = 2, line = 4.8, at = 0.92 , cex = 3.2)
    if (j==1) {
      mtext(expression(alpha), side = 1, line = 7, at = xmax, cex = 3)
    }
    if (j==2) {
      mtext(expression(beta), side = 1, line = 7, at = xmax, cex = 3)
    }
    #################################
  } ## end p (1 to NT) different panels in one figure
  
  mtext("n=1,000", side = 3, cex = 4, font = 1,
        line = -7,
        outer = TRUE)
  
  mtext("n=2,000", side = 3, cex = 4, font = 1,
        line = -69,
        outer = TRUE)
  
  mtext("n=5,000", side = 3, cex = 4, font = 1,
        line = -132,
        outer = TRUE)
  
  mtext("n=10,000", side = 3, cex = 4, font = 1,
        line = -197,
        outer = TRUE)
  
  par(fig = c(0, 1, 0, 1), oma = c(1, 0, 0, 0), mar = c(0, 0, 0, 0), new = TRUE)
  plot(0, 0, type = 'l', bty = 'n', xaxt = 'n', yaxt = 'n')
  legend("bottom",col=c(1,4),lwd=4,lty=c(1,5),legend=le,cex=5.5,xpd=TRUE,horiz=TRUE) #bty="n",inset=c(0,-0.33),
  dev.off()
}
###############################################################################

# Plot Figures S.4 and S.5
###############################################################################
tt = rep(c(2,3),4)
nn = matrix(rbind(Nlist,Nlist),8,1)
cc = rep(case,8)

#### Figure panel formats: ns by 1 for comparing TMG, GP and SU given a NT combo
panel_nrow = 4
panel_ncol = 2
panel_id = seq(1,panel_nrow*panel_ncol,by=1)
k=2; nest=5

pidx = matrix(c(0,1,1,0,2,1),3,k) # alpha,beta
phead = rep(c("1,000","2,000","5,000","10,000"),2)

for (idx in 1:ncol(pidx)) {
  tej = pidx[1,idx] ## results of phi: tej=1; results of E(theta_i): tej=0
  j = pidx[2,idx] ## for regressor j
  
  #### Set legends
  #################################
  id_list = c(1,2,3)
  le_1 = expression(paste("TMG threshold with ",alpha==1/3,sep=""))
  le_2 = expression(paste("TMG threshold with ",alpha==0.35,sep=""))
  le_3 = expression(paste("TMG threshold with ",alpha==1/2,sep=""))
  le = c(le_1,le_2,le_3)
  #################################
  
  #### Set names of the figure
  #################################
  pngname = paste("Figure S.4",".png",sep = "")
  #################################
  
  #### Set width and height, no. of panels of plots
  #################################
  png(pngname, units="in", width=31, height=36, res=50) # (2 by 2) T=2
  par(mai=c(1.5,1.2,1.2,1.2),xpd=TRUE, mfrow=c(panel_nrow,panel_ncol),omi=c(1.5,0.5,0.5,0.5),family="Times New Roman") # (b,l,t,r)
  #################################
  
  p = 1
  for (p in panel_id) {
    nobs = nn[p]
    Tobs = tt[p]
    case = cc[p]
    
    #### Set axes
    #################################
    truev = pidx[3,idx] ## true value of a parameter
    pwlb=-2.5; pwrb=2.5; pwintv=0.01;
    pwgrid = length(as.matrix(seq(as.numeric(truev+pwlb),as.numeric(truev+pwrb),by=pwintv)))
    mx = seq(truev+pwlb,truev+pwrb,by=pwintv)
    lb = which(mx-truev+1==0) 
    ub = length(mx)-lb+1 #which(mx-truev-1.2==0) 
    xmin = round(mx[lb],digits=2)
    xmax = round(mx[ub],digits=2)
    ymin = 0
    ymax = 1
    #################################
    
    #### Load results
    #################################
    Tobs = tt[p]; nobs = nn[p]; case = cc[p]
    tej = pidx[1,idx] ## results of phi: tej=1; results of E(theta_i): tej=0
    k = 2; id_list = c(6,8,10)
    name1 = paste("est","_d",dist_x,"c",case,"_n",nobs,"_T",Tobs,sep="")
    en = 1; temp = tryCatch(get(name1),error=function(e) print(en))
    j = pidx[2,idx] ## for regressor j
    if (is.list(temp)==1 ){
      pw1 = temp$pw[,(id_list+j)] # GP
    }
    pw_temp= pw1
    #################################
    
    
    #### Add panels' names 
    #################################
    if (p==1) {
      main_1 = "T=2"
    }
    if (p==2) {
      main_1 = "T=3"
    }
    #################################
    
    
    #### Plot curves
    #################################
    if (p %in% c(1,2)) { # (b,l,t,r)
      par(mar=c(11,10,12,10))
    }
    if (p %in% c(3,4)) {
      par(mar=c(11,10,11,10))
    }
    if (p %in% c(5,6)) {
      par(mar=c(11,10,11,10))
    }
    if (p %in% c(7,8)) {
      par(mar=c(13,10,11,10))
    }
    plot(mx[lb:ub],pw_temp[lb:ub,1],type="l",col=1,lwd=5,lty=1,xlim=c(xmin,xmax),ylim=c(ymin,ymax),xaxs="i",yaxs="i",axes=F,ylab="",xlab="")
    lines(mx[lb:ub],pw_temp[lb:ub,2],type="l",col=4,lwd=5,lty=5,xlim=c(xmin,xmax),ylim=c(ymin,ymax))
    lines(mx[lb:ub],pw_temp[lb:ub,3], type="l", col=2, lwd=5,lty=4,xlim=c(xmin, xmax), ylim=c(ymin, ymax))
    #title(mgp=c(3.5,2.2,0),main=main_1,font.main=1,cex.lab=2.8,cex.main=5.8)
    if (p %in% c(1,2)) {
      #title(mgp=c(10,10,10),main=main_1,font.main=1,cex.main=7)
      mtext(main_1, side = 1, line = -52, at = 1 , cex = 5)
    }
    axis(side=1, at=seq(xmin, xmax, by=0.2), mgp=c(2, 3, 0), cex.axis=4)
    axis(side=2, at=seq(0.2, 1, by=0.2), mgp=c(3.5, 1.5, 0), cex.axis=4)######## Visualization
    arrows(truev,-0.01, truev, 1, length = 0,lty = 3,lwd=3.5) # denote the true value
    arrows(xmin,0.05,xmax,0.05, length = 0,lty = 3,lwd=3.5) # denote a line of 5% probability
    mtext("5%", side = 1, line = -3, at = 2.08 , cex = 3)
    box(col="black")
    mtext("Power", side = 2, line = 4.8, at = 0.92 , cex = 3.2)
    if (j==1) {
      mtext(expression(alpha), side = 1, line = 7, at = xmax, cex = 3)
    }
    if (j==2) {
      mtext(expression(beta), side = 1, line = 7, at = xmax, cex = 3)
    }
    #################################
  } ## end p (1 to NT) different panels in one figure
  
  mtext("n=1,000", side = 3, cex = 4, font = 1,
        line = -7,
        outer = TRUE)
  
  mtext("n=2,000", side = 3, cex = 4, font = 1,
        line = -69,
        outer = TRUE)
  
  mtext("n=5,000", side = 3, cex = 4, font = 1,
        line = -132,
        outer = TRUE)
  
  mtext("n=10,000", side = 3, cex = 4, font = 1,
        line = -197,
        outer = TRUE)
  
  par(fig = c(0, 1, 0, 1), oma = c(1, 0, 0, 0), mar = c(0, 0, 0, 0), new = TRUE)
  plot(0, 0, type = 'l', bty = 'n', xaxt = 'n', yaxt = 'n')
  legend("bottom",col=c(1,4,2),lwd=4,lty=c(1,5,4),legend=le,cex=5.5,xpd=TRUE,horiz=TRUE) #bty="n",inset=c(0,-0.33),
  dev.off()
}

for (idx in 1:ncol(pidx)) {
  tej = pidx[1,idx] ## results of phi: tej=1; results of E(theta_i): tej=0
  j = pidx[2,idx] ## for regressor j
  
  #### Set legends
  #################################
  id_list = c(1,2,3)
  le_1 = expression(paste("GP bandwidth with ",alpha[GP]==0.35/2,sep=""))
  le_2 = expression(paste("GP bandwidth with ",alpha[GP]==1/4,sep=""))
  le_3 = expression(paste("GP bandwidth with ",alpha[GP]==1/3,sep=""))
  le = c(le_1,le_2,le_3)
  #################################
  
  #### Set names of the figure
  #################################
  pngname = paste("Figure S.5",".png",sep = "")
  #################################
  
  #### Set width and height, no. of panels of plots
  #################################
  png(pngname, units="in", width=31, height=36, res=50) # (2 by 2) T=2
  par(mai=c(1.5,1.2,1.2,1.2),xpd=TRUE, mfrow=c(panel_nrow,panel_ncol),omi=c(1.5,0.5,0.5,0.5),family="Times New Roman") # (b,l,t,r)
  #################################
  
  p = 1
  for (p in panel_id) {
    nobs = nn[p]
    Tobs = tt[p]
    case = cc[p]
    
    #### Set axes
    #################################
    truev = pidx[3,idx] ## true value of a parameter
    pwlb=-2.5; pwrb=2.5; pwintv=0.01;
    pwgrid = length(as.matrix(seq(as.numeric(truev+pwlb),as.numeric(truev+pwrb),by=pwintv)))
    mx = seq(truev+pwlb,truev+pwrb,by=pwintv)
    lb = which(mx-truev+1==0) 
    ub = length(mx)-lb+1 #which(mx-truev-1.2==0) 
    xmin = round(mx[lb],digits=2)
    xmax = round(mx[ub],digits=2)
    ymin = 0
    ymax = 1
    #################################
    
    #### Load results
    #################################
    Tobs = tt[p]; nobs = nn[p]; case = cc[p]
    tej = pidx[1,idx] ## results of phi: tej=1; results of E(theta_i): tej=0
    
    id_list = c(0,2,4)
    name1 = paste("est","_d",dist_x,"c",case,"_n",nobs,"_T",Tobs,sep="")
    en = 1; temp = tryCatch(get(name1),error=function(e) print(en))
    j = pidx[2,idx] ## for regressor j
    if (is.list(temp)==1 ){
      pw1 = temp$pw[,(id_list+j)] # GP
    }
    pw_temp= pw1
    #################################
    
    #### Add panels' names 
    #################################
    if (p==1) {
      main_1 = "T=2"
    }
    if (p==2) {
      main_1 = "T=3"
    }
    #################################
    
    
    #### Plot curves
    #################################
    if (p %in% c(1,2)) { # (b,l,t,r)
      par(mar=c(11,10,12,10))
    }
    if (p %in% c(3,4)) {
      par(mar=c(11,10,11,10))
    }
    if (p %in% c(5,6)) {
      par(mar=c(11,10,11,10))
    }
    if (p %in% c(7,8)) {
      par(mar=c(13,10,11,10))
    }
    plot(mx[lb:ub],pw_temp[lb:ub,1],type="l",col=1,lwd=5,lty=1,xlim=c(xmin,xmax),ylim=c(ymin,ymax),xaxs="i",yaxs="i",axes=F,ylab="",xlab="")
    lines(mx[lb:ub],pw_temp[lb:ub,2],type="l",col=4,lwd=5,lty=5,xlim=c(xmin,xmax),ylim=c(ymin,ymax))
    lines(mx[lb:ub],pw_temp[lb:ub,3], type="l", col=2, lwd=5,lty=4,xlim=c(xmin, xmax), ylim=c(ymin, ymax))
    #title(mgp=c(3.5,2.2,0),main=main_1,font.main=1,cex.lab=2.8,cex.main=5.8)
    if (p %in% c(1,2)) {
      #title(mgp=c(10,10,10),main=main_1,font.main=1,cex.main=7)
      mtext(main_1, side = 1, line = -52, at = 1 , cex = 5)
    }
    axis(side=1, at=seq(xmin, xmax, by=0.2), mgp=c(2, 3, 0), cex.axis=4)
    axis(side=2, at=seq(0.2, 1, by=0.2), mgp=c(3.5, 1.5, 0), cex.axis=4)######## Visualization
    arrows(truev,-0.01, truev, 1, length = 0,lty = 3,lwd=3.5) # denote the true value
    arrows(xmin,0.05,xmax,0.05, length = 0,lty = 3,lwd=3.5) # denote a line of 5% probability
    mtext("5%", side = 1, line = -3, at = 2.08 , cex = 3)
    box(col="black")
    mtext("Power", side = 2, line = 4.8, at = 0.92 , cex = 3.2)
    if (j==1) {
      mtext(expression(alpha), side = 1, line = 7, at = xmax, cex = 3)
    }
    if (j==2) {
      mtext(expression(beta), side = 1, line = 7, at = xmax, cex = 3)
    }
    #################################
  } ## end p (1 to NT) different panels in one figure
  
  mtext("n=1,000", side = 3, cex = 4, font = 1,
        line = -7,
        outer = TRUE)
  
  mtext("n=2,000", side = 3, cex = 4, font = 1,
        line = -69,
        outer = TRUE)
  
  mtext("n=5,000", side = 3, cex = 4, font = 1,
        line = -132,
        outer = TRUE)
  
  mtext("n=10,000", side = 3, cex = 4, font = 1,
        line = -197,
        outer = TRUE)
  
  par(fig = c(0, 1, 0, 1), oma = c(1, 0, 0, 0), mar = c(0, 0, 0, 0), new = TRUE)
  plot(0, 0, type = 'l', bty = 'n', xaxt = 'n', yaxt = 'n')
  legend("bottom",col=c(1,4,2),lwd=4,lty=c(1,5,4),legend=le,cex=5.5,xpd=TRUE,horiz=TRUE) #bty="n",inset=c(0,-0.33),
  dev.off()
}
###############################################################################






rm(list=ls())
load("simukappa2.RData")

list.of.packages <- c("parallel","openxlsx")
new.packages <- list.of.packages[!(list.of.packages %in% installed.packages()[,"Package"])]
if(length(new.packages)) install.packages(new.packages)
library(parallel)
library(openxlsx)


### Define Functions of DGP: Deme_i, Gen_balpanel
################################################################################
Deme_i = function(paneldata_e,Tobs,id) {
  ei = matrix(paneldata_e[(1+(id-1)*Tobs):(id*Tobs),],Tobs,1)
  mt= diag(Tobs)-matrix(1, nrow=Tobs, ncol=1) %*% t(matrix(1, nrow=Tobs, ncol=1))/Tobs 
  deti = det( t(ei) %*% mt %*% ei) # eq. (8.6) 
  return(deti)
}

# generate a panel data set in the long format
Gen_balpanel = function(nobs,Tobs,k,m_y,gauss_y,m_x,hetero_x,dist_x,ar_x,te_x,corr_e,para_case,kappa2,phi_te,idt){
  x_nT_long = matrix(,(nobs*Tobs),(k-1))
  e_nT_long = matrix(,(nobs*Tobs),(k-1))
  ### 1. generate a panel of the regressor x_{it}
  ################################################################################
  for (j in 1: (k-1)) {
    ### 1(1). generate errors IID(0,1) Section S.3.1
    if (dist_x==1) {
      e_nT = matrix(rnorm(nobs*Tobs,0,1),nobs,Tobs) # (n by T) normal(0,1)
      gamma2 = 0
    }
    if (dist_x==2) {
      e_0 = matrix(runif(nobs*Tobs,0,1),nobs,Tobs)
      e_nT = sqrt(12)*(e_0-1/2) # (n by T) uniform
      gamma2 = -6/5
    }
    
    ### 1(3) x_it: generate sigma_iv and xi_ix then plug in
    # hetero_x==0: homogeneous variance of x
    if (hetero_x==0) {
      sigma_vnT = matrix(1,nobs,Tobs)
    }
    # hetero_x==1: heterogeneous variance of x
    if (hetero_x==1) {
      sigma_vnT = matrix(sigma_vn[,j],nobs,Tobs) # (n by T) same in a row
    }
    v_nT = e_nT*sigma_vnT # (n by T)
    
    alphax_n = matrix(m_x[j,1],nobs,1) + axx_n[,j] # (n by 1)
    alphax_nT = matrix(alphax_n,nobs,Tobs) # (n by T) same in a row
    Th = 51 # number of existing periods before observed
    if (ar_x == 0) {
      phix_n = matrix(m_x[j,2],nobs,1) # (n by 1)
      phix_nT = matrix(phix_n,nobs,Tobs) # (n by T) same in a row
      ## include a common factor structure or time effects
      ft_n = t(matrix(rep(ft,nobs),Tobs,nobs)) # same in a column
      # factor loadings
      if (te_x==0) {
        gamma_n = matrix(0,nobs,Tobs)
      }
      if (te_x==1) {
        gamma_n = matrix(1,nobs,Tobs)
      }
      if (te_x==2) {
        gamma_n = matrix(runif(nobs,0,2),nobs,Tobs)
      }
      x_nT = alphax_nT*(1-phix_nT) + gamma_n*ft_n + v_nT # (n by T) (8.3) without autoregressions
    }
    if (ar_x == 1) {
      tau_n = matrix(1,nobs,1) 
      phix_n = phixx_n[,j] # (n by 1) uniform (0,0.95)
      if (dist_x==1) {
        e_h = matrix(rnorm(nobs*Th,0,1),nobs,Th) # (n by T) normal(0,1)
      }
      if (dist_x==2) {
        e_h0 = matrix(runif(nobs*Th,0,1),nobs,Th)
        e_h = sqrt(12)*(e_h0-1/2) # (n by T) uniform
      }
      sigma_vh = matrix(sigma_vn[,j],nobs,Th)
      v_h = sigma_vh*e_h # (n by 51)
      v_hT = cbind(v_h,v_nT) # (n by (51+Tobs)) # shocks
      x_hT = matrix(,nobs,(Th+Tobs))
      x_hT[,1] = matrix(0,nobs,1)
      if (te_x==0) {
        gamma_n = matrix(0,nobs,1)
      }
      if (te_x==1) {
        gamma_n = matrix(1,nobs,1)
      }
      if (te_x==2) {
        gamma_n = matrix(runif(nobs,0,2),nobs,1)
      }
      for ( j2 in 2:(Th+Tobs)) {
        fth_n = matrix(rep(fth[j2],nobs),nobs,1)
        # (8.3) with autoregressions for each t
        x_hT[,j2] = alphax_n*(tau_n-phix_n) + gamma_n*fth_n + phix_n*x_hT[,(j2-1)]+sqrt(tau_n-phix_n^2)*v_hT[,j2]
      }
      x_nT = x_hT[,(Th+1):(Th+Tobs)]
    }
    
    e_nT_temp = matrix(t(e_nT),nobs*Tobs,1) # (nT by 1)
    e_nT_long[,j] = e_nT_temp 
    rm(e_nT_temp)
    
    x_nT_temp = matrix(t(x_nT),nobs*Tobs,1) # (nT by 1)
    x_nT_long[,j] = x_nT_temp 
    rm(x_nT_temp)
  }
  int_nT_long = matrix(1,nobs*Tobs) # (n by T)
  w_nT_long = cbind(int_nT_long, x_nT_long) # (nT by k)
  ################################################################################
  
  ### 1(2). x_it: calculate lambda_i
  id_n = matrix(seq(1,nobs,by=1),nobs,1)
  deme_n = matrix(sapply(id_n,Deme_i,paneldata_e=e_nT_long,Tobs=Tobs),nobs,1) # (n by 1)
  lambda_n = (deme_n-(Tobs-1))/sqrt(2*(Tobs-1)+gamma2/Tobs*((Tobs-1)^2)) # (n by 1) eq. (S3.2)
  
  ### 2. Generate heterogeneous coefficients: case
  ###################################################################################
  sigma_zeta = para_case[1:k]  # (1 by k) 
  psi = para_case[(k+1):(2*k)] # (1 by k) 
  zeta_n = matrix(,nobs,k)
  eta_n = matrix(,nobs,k)
  theta_n = matrix(,nobs,k)
  theta_nT_long = matrix(,nobs*Tobs,k)
  # individual fixed effects correlated with lambda_i
  zeta_n[,1] = rnorm(nobs,0,sigma_zeta[1])
  eta_n[,1] = psi[1]*lambda_n + zeta_n[,1]
  theta_n[,1] = matrix(m_y[1],nobs,1) + eta_n[,1]
  theta_nT_long[,1] = matrix(t(matrix(theta_n[,1],nobs,Tobs)),nobs*Tobs,1)
  for (j in 2:k){
    if (case==0) { # homogeneous slope coefficients - case 0
      theta_n[,j] = matrix(m_y[j],nobs,1) 
      theta_nT_long[,j] = matrix(t(matrix(theta_n[,j],nobs,Tobs)),nobs*Tobs,1)
    } else { # heterogeneous slope coefficients 
      zeta_n[,j] = rnorm(nobs,0,sigma_zeta[j])
      eta_n[,j] = psi[j]*lambda_n + zeta_n[,j] # eq. (8.5)
      theta_n[,j] = matrix(m_y[j],nobs,1) + eta_n[,j] # eq. (8.4)
      theta_nT_long[,j] = matrix(t(matrix(theta_n[,j],nobs,Tobs)),nobs*Tobs,1)
    }
  }
  ###################################################################################
  
  ### 3. Generate time effects in y_{it}
  phi_nT = matrix(phi_te,Tobs,nobs)
  phi_nT_long = matrix(phi_nT,nobs*Tobs,1)
  
  ### 4. y_{it}: generate errors
  ################################################################################
  if (gauss_y==1) {
    ey_nT = matrix(rnorm(nobs*Tobs,0,1),nobs,Tobs) # (n by T) normal(0,1)
  }
  if (gauss_y==0){
    ey_nT = matrix(0.5*rchisq(nobs*Tobs,df=2,ncp = 0)-1, nobs, Tobs) # (n by T) chi-squared 
  }
  if (corr_e==0) {
    rhoe_n = matrix(0,nobs,1)
  }
  ey_n0 = matrix(rnorm(nobs,0,1),nobs,1)
  ey_temp = cbind(ey_n0,matrix(,nobs,Tobs))
  tid = 1
  for (tid in 2:(Tobs+1)) {
    ey_temp[,tid] = rhoe_n*ey_temp[,(tid-1)] + sqrt(1-rhoe_n^2)*ey_nT[,(tid-1)]  
  }
  ey_nT = ey_temp[,2:(Tobs+1)]; rm(ey_temp)
  
  ## DGP of heteroskedasticity: Section 8.1.3
  if (case %in% c(0,1,2,3,4,6)) { 
    sigma_unT = matrix(sigma_un,nobs,Tobs) # random heteroskedasticity
  }
  if (case==5) {
    cu = (sqrt(5)-1)/3
    sigma_unT = matrix(abs((2/3*lambda_n+1/3*sigma_un+cu)),nobs,Tobs) # deterministic heteroskedasticity
  } 
  if (case==7) {
    sigma_unT = matrix(sqrt((x_nT_long^2)/3),nobs,Tobs) # correlated heteroskedasticity
  }
  u_nT = sqrt(kappa2)*sigma_unT*ey_nT # (n by T)
  u_nT_long = matrix(t(u_nT),nobs*Tobs,1) # (nT by k=1)
  ################################################################################
  
  ### 5. y_{it}: plug in all variables
  y_nT_long = phi_nT_long+rowSums(theta_nT_long*w_nT_long)+u_nT_long # eq. (8.1)
  z_nt_long = cbind(idt,y_nT_long,x_nT_long)  # (nT by k+1) long-format panel data
  return(z_nt_long) 
}
################################################################################

### Functions for the test statistics for panels without time effects CorrHetero_test()
### PMD_i, PMDV_i, Minor, Cofactor, Adjoint1, Det_i, TOLS_i, Vd_i
################################################################################
## Functions for calculating FE and FE-TE estimates: PMD_i, PMDV_i
PMD_i = function(m1,m2,Tobs,id) {
  Ti = Tobs
  xi = as.matrix(m1[(1+(id-1)*Ti):(id*Ti),]) # (T by k1)
  yi = as.matrix(m2[(1+(id-1)*Ti):(id*Ti),]) # (T by k2)
  k1i = dim(xi)[2]
  k2i = dim(yi)[2]
  mti = diag(Ti)-matrix(1, nrow=Ti, ncol=1) %*% t(matrix(1, nrow=Ti, ncol=1))/Ti # (T by T)
  pd_i = matrix(t(xi) %*% mti %*% yi,k1i*k2i,1) # (k1*k2) by 1
  pd_i
}

PMDV_i = function(mx,mre,Tobs,id) {
  Ti = Tobs
  xi = as.matrix(mx[(1+(id-1)*Ti):(id*Ti),]) # (T by k )
  rei = as.matrix(mre[(1+(id-1)*Ti):(id*Ti),]) # (T by 1) residuals
  ki = dim(xi)[2]
  Mti = diag(Ti)-matrix(1, nrow=Ti, ncol=1) %*% t(matrix(1, nrow=Ti, ncol=1))/Ti # (T by T)
  pdv_i = matrix(t(xi) %*% Mti %*% rei %*% t(rei) %*% Mti %*% xi,ki*ki,1) # (k*k)  by 1
  pdv_i
}

## Functions for calculating TMG estimates: Minor, Cofactor, Adjoint1, Det_i, TOLS_i
Minor = function(A, i, j) {
  det(as.matrix(A[-i,-j]) )
}

Cofactor = function(A, i, j) {
  (-1)^(i+j) * Minor(A,i,j)
}

Adjoint1 = function(A) {
  n = nrow(A)
  B = matrix(, n, n)
  for( i in 1:n )
    for( j in 1:n )
      B[j,i] = Cofactor(A, i, j)
  B
}

Det_i = function(paneldata_w,nobs,Tobs,k,id) {
  wi = matrix(paneldata_w[(1+(id-1)*Tobs):(id*Tobs),],Tobs,k)  # (T by k) including intercepts
  deti = det(t(wi) %*% wi) # scalar where t(wi) %*% wi is a (k by k) matrix
  deti
}

TOLS_i = function(panel_int,nobs,Tobs,k,an,id){
  obsi = as.matrix(panel_int[(1+(id-1)*Tobs):(id*Tobs),]) # paneldata = {(yi,wi)} (nT by k+1) matrix including intercepts
  yi = as.matrix(obsi[,1]) # yi (T by 1)
  wi = as.matrix(obsi[,2:(k+1)]) # regressor wi (T by k) with wit = (1,xit')'
  di = det(t(wi) %*% wi) # determinant
  if (di > an) {
    theta_i = solve(t(wi) %*% wi) %*% (t(wi) %*% yi) # (k by 1) individual OLS estimator
  } else {
    theta_i = an^(-1) * Adjoint1(t(wi) %*% wi) %*% (t(wi) %*% yi) # (k by 1) individual trimmed estimator
  }
  theta_i # eq. (4.2)
}

## Functions for calculating denominator of test statistics: Vd_i
Vd_i = function(panel_int,nobs,Tobs,k,an,q_bn,delta_bn,fe_hatb,id) {
  yi = matrix(panel_int[(1+(id-1)*Tobs):(id*Tobs),1],Tobs,1)
  wi = matrix(panel_int[(1+(id-1)*Tobs):(id*Tobs),2:(1+k)],Tobs,k)  # (T by k)
  xi = matrix(panel_int[(1+(id-1)*Tobs):(id*Tobs),3:(1+k)],Tobs,k-1) # (T by k-1)
  taut = matrix(1,Tobs,1) 
  mt = diag(1,Tobs)-taut %*% solve(t(taut)%*%taut) %*% t(taut) # (T by T)
  di = det(t(wi) %*% wi)
  if (di > an) {
    wwinv = solve(t(wi) %*% wi)  # (k by 1) individual OLS estimator
  } else {
    wwinv = an^(-1) * Adjoint1(t(wi) %*% wi)  # (k by 1) individual trimmed estimator
  }
  xmxinv = as.matrix(wwinv[-c(1),-c(1)]) # (1+delta_i) (X_i'M_TX_i)^{-1}
  
  gi = (solve(q_bn)-1/(1+delta_bn)*xmxinv) %*% t(xi)  # (k-1 by T) matrix eq. (7.3)
  refei = mt %*% (yi - xi %*% fe_hatb) # (T by 1) vector of residuals
  ggeei= matrix(0,k-1,k-1)
  
  for (t in 1:Tobs) {
    for (s in 1:Tobs) {
      git = gi[,t] 
      eit = refei[t]
      gis = gi[,s] 
      eis = refei[s] 
      ggeei = ggeei + git %*% t(gis) * (eit*eis) #  eq.(7.2)
    }
  }
  ggeei # a (k-1) by (k-1) matrix
}

CorrHetero_test_mc = function(paneldata,nobs,Tobs,k) {
  #### Import data of a balanced panel
  ######################################################
  nT = nobs*Tobs
  id_list = as.matrix(seq(1,nobs,by=1))
  int_nT_long = matrix(1,nobs*Tobs,1)
  paneldata_w = cbind(int_nT_long,paneldata[,2:k])
  panel_int = cbind(paneldata[,1],paneldata_w) # add intercepts
  y = as.matrix(panel_int[,1]) # (nT by 1)
  w = as.matrix(panel_int [,2:(1+k)]) # (nT by k) regressors include intercepts
  x = as.matrix(panel_int[,3:(1+k)]) # (nT by k-1)
  ######################################################
  
  ### FE estimation results
  ######################################################
  # FE (1) calculate numerator and denominator of FE estimator
  xmx_n = matrix(sapply(id_list,PMD_i,m1=x,m2=x,Tobs=Tobs),(k-1)*(k-1),nobs) 
  xmx = matrix(rowMeans(xmx_n)/Tobs,(k-1),(k-1)) # (k-1 by k-1) average over nT
  xmy_n = matrix(sapply(id_list,PMD_i,m1=x,m2=y,Tobs=Tobs),k-1,nobs) # k=2: (1 by n)
  xmy = matrix(rowMeans(xmy_n)/Tobs,k-1,1) # (k-1 by 1) average over nT
  
  # FE (2) calculate estimators and residuals
  fe_hatb = solve(xmx) %*% xmy # (k-1 by 1) eq. (2.14)
  taut = matrix(1,Tobs,1) 
  mt = diag(1,Tobs)-taut %*% solve(t(taut)%*%taut) %*% t(taut) # (T by T)
  re_fe = as.matrix(y - x %*% fe_hatb) # (nT by 1) residuals
  
  # FE (3) calcualte asymptotic variance of FE estimators
  xmuumx_n = matrix(sapply(id_list,PMDV_i,mx=x,mre=re_fe,Tobs=Tobs),(k-1)*(k-1),nobs)
  xmuumx = matrix(rowMeans(xmuumx_n)/Tobs,k-1,k-1) # (k-1 by k-1) average over nT
  fe_avarb = solve(xmx) %*% xmuumx %*% solve(xmx) / nobs / Tobs # Pesaran (2015) p. 654 
  ######################################################
  
  ### TMG estimation results
  ######################################################
  ## TMG (1) calculate di=det(Wi'Wi) and the threshold an = mean(di)*(n^(-arate))
  det_n = sapply(id_list,Det_i,paneldata_w=w,nobs=nobs,Tobs=Tobs,k=k) 
  det_bn = mean(det_n) # the sample mean of di=det(Wi'Wi)
  arate=1/3 # power of n in the threshold
  an = det_bn*(nobs^(-arate)) # the threshold
  
  ## TMG (2) calculate the trimming index
  trim_n = (det_n<=an)
  np = mean(trim_n)
  
  ## TMG (3) calculate trimmed individual estimates
  theta_trim_n = sapply(id_list,TOLS_i,panel_int=panel_int,nobs=nobs,Tobs=Tobs,k=k,an=an) # (k by n) eq. (4.2)
  tmgh_hat = matrix(rowMeans(theta_trim_n),k,1) # (k by 1) average over n eq. (4.4)
  
  ## TMG (4) calculate bias-corrected TMG estimator 
  delta_n = (det_n/an-1)*trim_n # (n by 1) eq. (4.3)
  delta_bn = mean(delta_n)
  tmg_hat = (1+delta_bn)^(-1)*tmgh_hat # (k by 1) eq. (4.5)
  tmg_hatb = tmg_hat[2:k,1]
  
  ## TMG (5) calculate asymptotic variance of TMG estimator 
  tmg_bm = matrix(tmg_hat, k ,nobs)
  tmg_av =(1+delta_bn)^(-2)*(nobs*(nobs-1))^(-1)*(theta_trim_n-tmg_bm) %*% t(theta_trim_n-tmg_bm) # (k by k) eq. (5.21)
  tmg_varb = diag(tmg_av)[2:k]
  ######################################################
  
  ### Calculate test statistics
  ######################################################
  dbeta = fe_hatb-tmg_hatb # (k-1) by 1 vector
  q_bn = matrix(rowMeans(xmx_n),(k-1),(k-1)) # (k-1 by k-1) average over n
  vd_n = sapply(id_list,Vd_i,panel_int=panel_int,nobs=nobs,Tobs=Tobs,k=k,an=an,q_bn=q_bn,delta_bn=delta_bn,fe_hatb=fe_hatb) # (k-1)*(k-1) by n matrix 
  vd_bn = matrix(rowMeans(matrix(vd_n,(k-1)*(k-1),nobs)),(k-1),(k-1)) # average over n eq. (7.2)
  hb =  nobs * t(dbeta) %*% solve(vd_bn) %*% dbeta # a scalar of test statistics eq. (7.4)
  
  result = hb > qchisq(0.95, df=k-1) 
  output = c(result,hb,fe_hatb,tmg_hatb,np,fe_avarb,tmg_varb)
  output
}
#################################################################################

### Functions for rge test statistics for panels with time effects: CorrHetero_TE_test() and CorrHetero_C_test()
### TMG-TE: PMD_i, PMDV_i, Minor, Cofactor, Adjoint1, Det_i, TOLS_i, Qw_i, Phiuu_i, Vdte_i
### TMG-C: PMD_i, PMDV_i, Minor, Cofactor, Adjoint1, Det_i, TOLS_i, MTxy_i, MTuu_i, Qw_i, Vdc_i
################################################################################
Qw_i = function(paneldata_w,nobs,Tobs,k,an,id){
  wi = matrix(paneldata_w[(1+(id-1)*Tobs):(id*Tobs),],Tobs,k)  # (T by k)
  di = det(t(wi) %*% wi) # determinant
  if (di > an) {
    qw_i = wi %*% solve(t(wi) %*% wi)  # (T by k)
  } else {
    qw_i = an^(-1)* wi %*% Adjoint1(t(wi) %*% wi)  # (T by k)
  }
  qw_i # eq. (6.3)
}

# calculate part of the variance of the TMG-TE estimator of the time effects phi_hat
Phiuu_i = function(paneldata,nobs,Tobs,k,est,id) {
  yi = matrix(paneldata[(1+(id-1)*Tobs):(id*Tobs),1],Tobs,1)
  xi = matrix(paneldata[(1+(id-1)*Tobs):(id*Tobs),2:k],Tobs,k-1) # (T by k-1)
  phi_hat = as.matrix(est[1:Tobs]) # (T by 1)
  beta_hat = as.matrix(est[(Tobs+2):(Tobs+k)]) # (k-1) by 1
  ui = yi - xi %*% beta_hat - phi_hat
  uui = ui %*% t(ui) # eq. (A.3.6)
  uui # (T by T)
}

Vdte_i = function(panel_int,nobs,Tobs,k,an,x_bn,y_bn,psi_nx,q_nx,delta_bn,qw_n,fete_hatb,id) {
  yi = matrix(panel_int[(1+(id-1)*Tobs):(id*Tobs),1],Tobs,1)
  wi = matrix(panel_int[(1+(id-1)*Tobs):(id*Tobs),2:(1+k)],Tobs,k)  # (T by k)
  xi = matrix(panel_int[(1+(id-1)*Tobs):(id*Tobs),3:(1+k)],Tobs,k-1) # (T by k-1)
  taut = matrix(1,Tobs,1) 
  mt = diag(1,Tobs)-taut %*% solve(t(taut)%*%taut) %*% t(taut) # (T by T)
  refei = matrix(mt %*% ((yi-y_bn) - (xi-x_bn) %*% fete_hatb), Tobs,1) # (T by 1) vector of residuals

  q_iw = matrix(qw_n[,id],Tobs,k) # (T by k)
  q_ix = matrix(q_iw[,-1],Tobs,k-1) # (T by k-1) partitioned from Q_i eq. (S.2.4)

  gi1 = (xi-x_bn) %*% solve(psi_nx) # FE-TE (T by k-1)
  gi2 = (1/(1+delta_bn)*q_ix) %*% t(solve(diag(1,k-1)-t(q_nx)%*%mt%*%x_bn)) # TMG-TE
  gi = matrix((gi1-gi2),Tobs,k-1) # (T by k-1) matrix eq. (S.2.10)
  
  ggeei= t(gi) %*% mt %*% refei %*% t(refei) %*% mt %*% gi # eq. (S.2.8)
  ggeei # a (k-1) by (k-1) matrix
}

CorrHetero_TE_test_mc = function(paneldata,nobs,Tobs,k) {
  #### Import data of a balanced panel
  ######################################################
  nT = nobs*Tobs
  id_list = as.matrix(seq(1,nobs,by=1))
  int_nT_long = matrix(1,nobs*Tobs,1)
  panel_int = cbind(paneldata[,1],cbind(int_nT_long,paneldata[,2:k])) # add intercepts
  y = as.matrix(panel_int[,1]) # (nT by 1)
  w = as.matrix(panel_int [,2:(1+k)]) # (nT by k) regressors include intercepts
  x = as.matrix(panel_int[,3:(1+k)]) # (nT by k-1)
  ######################################################
  
  ### FE-TE estimation results
  ######################################################
  # FE-TE (1) eliminate the time effects
  x_n = matrix(t(x),Tobs*(k-1),nobs) # T*(k-1) by n
  x_bn = t(matrix(rowMeans(x_n),(k-1),Tobs)) # T by (k-1) average over i
  x_bnm = t(matrix(t(x_bn),(k-1),Tobs*nobs)) # nT by (k-1) 
  x_dn = x - x_bnm # (nT by k-1) x_{it} - x_{ot}
  
  y_n = matrix(t(y),Tobs,nobs) # T by n
  y_bn = t(matrix(rowMeans(y_n),1,Tobs)) # T by 1
  y_bnm = t(matrix(t(y_bn),1,Tobs*nobs)) # T by n
  y_dn = y - y_bnm # nT by 1
  
  x2 = x_dn
  y2 = y_dn
  
  # FE-TE (2) calculate numerator and denominator of FE estimator
  xmx_n = matrix(sapply(id_list,PMD_i,m1=x2,m2=x2,Tobs=Tobs),(k-1)*(k-1),nobs) 
  xmx = matrix(rowMeans(xmx_n)/Tobs,(k-1),(k-1)) # (k-1 by k-1) average over nT
  xmy_n = matrix(sapply(id_list,PMD_i,m1=x2,m2=y2,Tobs=Tobs),k-1,nobs) # k=2: (1 by n)
  xmy = matrix(rowMeans(xmy_n)/Tobs,k-1,1) # (k-1 by 1) average over nT
  
  # FE-TE (3) calculate estimators and residuals
  fete_hatb = solve(xmx) %*% xmy # (k-1 by 1) eq. (S.2.1)
  re_fe = as.matrix(y2 - x2 %*% fete_hatb) # (nT by 1) 
  
  # FE-TE (4) calcualte ssymptotic variance 
  xmuumx_n = matrix(sapply(id_list,PMDV_i,mx=x2,mre=re_fe,Tobs=Tobs),(k-1)*(k-1),nobs)
  xmuumx = matrix(rowMeans(xmuumx_n)/Tobs,k-1,k-1) # (k-1 by k-1) average over nT
  fete_avarb = solve(xmx) %*% xmuumx %*% solve(xmx) / nobs / Tobs # Pesaran (2015) p. 654 
  ######################################################
  
  ### TMG-TE estimation results when T=k
  ######################################################
  det_n = sapply(id_list,Det_i,paneldata_w=w,nobs=nobs,Tobs=Tobs,k=k) 
  det_bn = mean(det_n) # the sample mean of di=det(Wi'Wi)
  arate = 1/3
  an = det_bn*(nobs^(-arate)) # the threshold
  
  ## TMG (2) calculate the trimming index
  trim_n = (det_n<=an)
  np = mean(trim_n)
  
  ## TMG (3) calculate trimmed individual estimates
  theta_trim_n = sapply(id_list,TOLS_i,panel_int=panel_int,nobs=nobs,Tobs=Tobs,k=k,an=an) # (k by n)
  tmgh_hat = matrix(rowMeans(theta_trim_n),k,1) # (k by 1) average over n
  
  ## TMG (4) calculate bias-corrected TMG estimator 
  delta_n = (det_n/an-1)*trim_n # (n by 1)
  delta_bn = mean(delta_n)
  tmg_hat = (1+delta_bn)^(-1)*tmgh_hat # (k by 1) eq. (4.5)
  
  ## calculate TMG-TE estimator under tau'phi=0
  w_n = matrix(t(w),k*Tobs,nobs) # (Tk by n)
  w_bn = t(matrix(rowMeans(w_n),k,Tobs)) # (T by k) average over n
  y_n = matrix(y,Tobs,nobs) # (T by n)
  y_bn = matrix(rowMeans(y_n),Tobs,1) # (T by 1) {y_it} average over n for each t
  
  taut = matrix(1,Tobs,1) 
  mt = diag(1,Tobs)-taut %*% solve(t(taut)%*%taut) %*% t(taut) # (T by T)
  
  qw_n = sapply(id_list,Qw_i,paneldata_w=w,nobs=nobs,Tobs=Tobs,k=k,an=an) # Tk by n eq. (6.3)
  qw_bn = (1+delta_bn)^(-1)*matrix(rowMeans(qw_n),Tobs,k) # (T by k) eq. (6.4)
  q_nx = matrix(qw_bn[,-1],Tobs,k-1) # eq. (S.2.5)
  
  ## TMG-TE (1) calculate estimator phi_hat and theta_hat
  phi_hat = solve(diag(1,Tobs)-mt%*%w_bn%*%t(qw_bn)) %*% mt %*% (y_bn-w_bn%*%tmg_hat) # eq. (6.11)
  theta_hat = tmg_hat - t(qw_bn)%*%phi_hat # eq. (6.9)
  
  ## TMG-TE (2) calculate asymptotic variance of theta_hat
  phie_nT = matrix(matrix(phi_hat,Tobs,nobs),Tobs*nobs,1)
  ydte_nT = y - phie_nT # (nT by 1) 
  panel_dte = cbind(ydte_nT,w)  
  theta_te_n = sapply(id_list,TOLS_i,panel_int=panel_dte,nobs=nobs,Tobs=Tobs,k=k,an=an) # (k by n)
  theta_bm = matrix(theta_hat,k,nobs)
  theta_av0 = (1+delta_bn)^(-2)*(nobs*(nobs-1))^(-1)*(theta_te_n-theta_bm) %*% t(theta_te_n-theta_bm) # (k by k) eq. (A.3.5)
  theta_av = solve(diag(1,k)-t(qw_bn)%*%mt%*%w_bn)%*%theta_av0%*%t(solve(diag(1,k)-t(qw_bn)%*%mt%*% w_bn)) # eq. (A.3.4)
  
  tmgte_hatb = theta_hat[2:k,1]
  tmgte_avb = theta_av[2:k,2:k]
  
  ## TMG-TE asymptotic variance of time effects phi
  tmgte_hat = as.matrix(c(phi_hat,theta_hat)) # (T+k) by 1: phi_hat, theta_hat 
  phiuu_n = sapply(id_list,Phiuu_i,paneldata=paneldata,nobs=nobs,Tobs=Tobs,k=k,est=tmgte_hat) 
  phiuu_bn = matrix(rowMeans(phiuu_n),Tobs,Tobs) 
  phi_av0 = (nobs-1)^(-1)*phiuu_bn # eq. (A.3.6)
  phi_av = mt %*% ( w_bn %*% theta_av %*% t(w_bn) + phi_av0 ) %*% mt # eq. (A.3.7)
  
  phi_av = diag(phi_av)
  ######################################################
  
  ### Calculate test statistics
  ######################################################
  dbeta = fete_hatb - tmgte_hatb # (k-1) by 1 vector
  psi_nx = matrix(rowMeans(xmx_n),(k-1),(k-1)) # (k-1 by k-1) average over n
  vd_n = sapply(id_list,Vdte_i,panel_int=panel_int,nobs=nobs,Tobs=Tobs,k=k,an=an,
                x_bn=x_bn,y_bn=y_bn,psi_nx=psi_nx,q_nx=q_nx,delta_bn=delta_bn,qw_n=qw_n,fete_hatb=fete_hatb)
  vd_bn = matrix(rowMeans(matrix(vd_n,(k-1)*(k-1),nobs)),(k-1),(k-1)) # average over n eq. (S.2.8)
  hb =  nobs * t(dbeta) %*% solve(vd_bn) %*% dbeta # a scalar of test statistics eq. (S.2.11)
  
  result = hb > qchisq(0.95, df=k-1) 
  output = c(result,hb,fete_hatb,fete_avarb,tmgte_hatb,tmgte_avb,np,phi_hat,phi_av)
  output
}

## Functions for calculating TMG-C estimates: Mtxy_i
MTxy_i = function(paneldata,nobs,Tobs,k,id) {
  yi = matrix(paneldata[(1+(id-1)*Tobs):(id*Tobs),1],Tobs,1)
  xi = matrix(paneldata[(1+(id-1)*Tobs):(id*Tobs),2:k],Tobs,k-1) # (T by k-1)
  taut = matrix(1,Tobs,1) 
  mt = diag(1,Tobs)-taut %*% solve(t(taut)%*%taut) %*% t(taut) # (T by T)
  mtxi = mt %*% xi
  mti = diag(1,Tobs)- mtxi %*% solve(t(mtxi) %*% mtxi) %*% t(mtxi) # (T by T)
  mtyi = mti %*% mt %*% yi # (T by 1)
  mtxyi = cbind(mti,mtyi) # T by (T+1) 
  mtxyi # components in (6.18)
}

# calculate part of the variance of phi_c
MTuu_i = function(paneldata,nobs,Tobs,k,phi_c,id) {
  yi = matrix(paneldata[(1+(id-1)*Tobs):(id*Tobs),1],Tobs,1)
  xi = matrix(paneldata[(1+(id-1)*Tobs):(id*Tobs),2:k],Tobs,k-1) # (T by k-1)
  taut = matrix(1,Tobs,1) 
  mt = diag(1,Tobs)-taut %*% solve(t(taut)%*%taut) %*% t(taut) # (T by T)
  mtxi = mt %*% xi
  mti = diag(1,Tobs)- mtxi %*% solve(t(mtxi)%*% mtxi) %*% t(mtxi) # (T by T)
  ydtei = matrix(yi - phi_c,Tobs,1)
  mtuui = mti %*% mt %*% ydtei %*% t(ydtei) %*% t(mti %*% mt) # component in (6.20)
  mtuui
}

Vdc_i = function(panel_int,nobs,Tobs,k,an,x_bn,y_bn,psi_nx,q_nx,mtx_bn,delta_bn,qw_n,fete_hatb,id) {
  yi = matrix(panel_int[(1+(id-1)*Tobs):(id*Tobs),1],Tobs,1)
  wi = matrix(panel_int[(1+(id-1)*Tobs):(id*Tobs),2:(1+k)],Tobs,k)  # (T by k)
  xi = matrix(panel_int[(1+(id-1)*Tobs):(id*Tobs),3:(1+k)],Tobs,k-1) # (T by k-1)
  taut = matrix(1,Tobs,1) 
  mt = diag(1,Tobs)-taut %*% solve(t(taut)%*%taut) %*% t(taut) # (T by T)
  refei = matrix(((yi-y_bn) - (xi-x_bn) %*% fete_hatb), Tobs,1) # (T by 1) vector of residuals
  q_iw = matrix(qw_n[,id],Tobs,k) # T by k
  q_ix = matrix(q_iw[,-c(1)],Tobs,k-1) # T by k-1
  
  gi1 = (xi-x_bn) %*% solve(psi_nx) # FE-TE
  mtxi = mt %*% xi    
  mti = diag(1,Tobs)- mtxi %*% solve(t(mtxi) %*% mtxi) %*% t(mtxi) 
  gi2 = (1+delta_bn)^(-1)*q_ix -  mti %*%solve(mtx_bn)%*%mt%*% q_nx # TMG-C
  gi = matrix((gi1-gi2),Tobs,k-1) # (T by k-1) matrix
  
  ggeei= t(gi) %*% mt %*% refei %*% t(refei) %*% mt %*% gi # eq. (S.2.16)
  ggeei # a (k-1) by (k-1) matrix
}

CorrHetero_C_test_mc = function(paneldata,nobs,Tobs,k) {
  if (Tobs<=k) {
    output = "The test statistic is based on the difference between the FE-TE and TMG-C estimators and applicable for panels with T>k."
  }
  
  if (Tobs>k) {
    #### Import data of a balanced panel
    ######################################################
    nT = nobs*Tobs
    id_list = as.matrix(seq(1,nobs,by=1))
    int_nT_long = matrix(1,nobs*Tobs,1)
    panel_int = cbind(paneldata[,1],cbind(int_nT_long,paneldata[,2:k])) # add intercepts
    y = as.matrix(panel_int[,1]) # (nT by 1)
    w = as.matrix(panel_int [,2:(1+k)]) # (nT by k) regressors include intercepts
    x = as.matrix(panel_int[,3:(1+k)]) # (nT by k-1)
    ######################################################
    
    ### FE-TE estimation results
    ######################################################
    # FE-TE (1) eliminate the time effects
    x_n = matrix(t(x),Tobs*(k-1),nobs) # T*(k-1) by n
    x_bn = t(matrix(rowMeans(x_n),(k-1),Tobs)) # T by (k-1) average over i
    x_bnm = t(matrix(t(x_bn),(k-1),Tobs*nobs)) # nT by (k-1) 
    x_dn = x - x_bnm # (nT by k-1) x_{it} - x_{ot}
    
    y_n = matrix(t(y),Tobs,nobs) # T by n
    y_bn = t(matrix(rowMeans(y_n),1,Tobs)) # T by 1
    y_bnm = t(matrix(t(y_bn),1,Tobs*nobs)) # T by n
    y_dn = y - y_bnm # nT by 1
    
    x2 = x_dn
    y2 = y_dn
    
    # FE-TE (2) calculate numerator and denominator of FE estimator
    xmx_n = matrix(sapply(id_list,PMD_i,m1=x2,m2=x2,Tobs=Tobs),(k-1)*(k-1),nobs) 
    xmx = matrix(rowMeans(xmx_n)/Tobs,(k-1),(k-1)) # (k-1 by k-1) average over nT
    xmy_n = matrix(sapply(id_list,PMD_i,m1=x2,m2=y2,Tobs=Tobs),k-1,nobs) # k=2: (1 by n)
    xmy = matrix(rowMeans(xmy_n)/Tobs,k-1,1) # (k-1 by 1) average over nT
    
    # FE-TE (3) calculate estimators and residuals
    fete_hatb = solve(xmx) %*% xmy # (k-1 by 1) eq. (S.2.1)
    re_fe = as.matrix(y2 - x2 %*% fete_hatb) # (nT by 1) 
    
    # FE-TE (4) calcualte ssymptotic variance 
    xmuumx_n = matrix(sapply(id_list,PMDV_i,mx=x2,mre=re_fe,Tobs=Tobs),(k-1)*(k-1),nobs)
    xmuumx = matrix(rowMeans(xmuumx_n)/Tobs,k-1,k-1) # (k-1 by k-1) average over nT
    fete_avarb = solve(xmx) %*% xmuumx %*% solve(xmx) / nobs / Tobs # Pesaran (2015) p. 654 
    ######################################################
    
    ### TMG-C estimation results when T>k
    ######################################################
    mtxy_n = sapply(id_list,MTxy_i,paneldata=paneldata,nobs=nobs,Tobs=Tobs,k=k)
    mtx_bn = matrix(rowMeans(mtxy_n[1:(Tobs*Tobs),]),Tobs,Tobs)
    mty_bn = matrix(rowMeans(mtxy_n[(Tobs*Tobs+1):(Tobs*(Tobs+1)),]),Tobs,1)
    phi_c = solve(mtx_bn) %*% mty_bn # eq. (6.18)
    
    mtuu_n = sapply(id_list,MTuu_i,paneldata=paneldata,nobs=nobs,Tobs=Tobs,k=k,phi_c=phi_c)
    mtuu_bn = matrix(rowMeans(mtuu_n),Tobs,Tobs)
    phic_av = nobs^(-1)*solve(mtx_bn) %*% mtuu_bn %*% t(solve(mtx_bn)) # eq. (6.19)
    
    phic_nT = matrix(matrix(phi_c,Tobs,nobs),Tobs*nobs,1)
    ydtc_nT = y - phic_nT # (nT by 1) vector of yit-phit_hat eq. (6.21)
    panel_dtc = cbind(ydtc_nT,w) 
    
    det_n = sapply(id_list,Det_i,paneldata_w=w,nobs=nobs,Tobs=Tobs,k=k) 
    det_bn = mean(det_n) # the sample mean of di=det(Wi'Wi)
    arate = 1/3
    an = det_bn*(nobs^(-arate)) # the threshold
    trim_n = (det_n<=an)
    np = mean(trim_n)
    
    delta_n = (det_n/an-1)*trim_n # (n by 1)
    delta_bn = mean(delta_n)
    
    thetac_n = sapply(id_list,TOLS_i,panel_int=panel_dtc,nobs=nobs,Tobs=Tobs,k=k,an=an) # (k by n)
    theta_hat = (1+delta_bn)^(-1)*matrix(rowMeans(thetac_n),k,1) # eq. (6.21)
    
    ## TMG-C asymptotic variance of E(theta_i)
    thetac_bm = matrix(theta_hat,k,nobs)
    thetac_av0 = (1+delta_bn)^(-2)*(nobs*(nobs-1))^(-1)*(thetac_n-thetac_bm) %*% t(thetac_n-thetac_bm) # (k by k) first component in eq. (6.22)
    qw_n = sapply(id_list,Qw_i,paneldata_w=w,nobs=nobs,Tobs=Tobs,k=k,an=an) # Tk by n 
    qw_bn = (1+delta_bn)^(-1)*matrix(rowMeans(qw_n),Tobs,k) # (T by k)
    q_nx =  matrix(qw_bn[,-1],Tobs,k-1) # (T by k-1)
    thetac_av1 = t(qw_bn) %*% phic_av %*% qw_bn # (k by k) second component in eq. (6.22)
    theta_av = thetac_av0 + thetac_av1 # eq. (6.22)
    
    phi_av = diag(phic_av)
    
    tmgc_hatb = theta_hat[2:k,1]
    tmgc_avb = theta_av[2:k,2:k]
    ######################################################
    
    ### Calculate test statistics
    ######################################################
    dbeta = fete_hatb - tmgc_hatb # (k-1) by 1 vector
    psi_nx = matrix(rowMeans(xmx_n),(k-1),(k-1)) # (k-1 by k-1) average over n
    vd_n = sapply(id_list,Vdc_i,panel_int=panel_int,nobs=nobs,Tobs=Tobs,k=k,an=an,
                  x_bn=x_bn,y_bn=y_bn,psi_nx=psi_nx,q_nx=q_nx,mtx_bn=mtx_bn,delta_bn=delta_bn,qw_n=qw_n,fete_hatb=fete_hatb)
    vd_bn = matrix(rowMeans(matrix(vd_n,(k-1)*(k-1),nobs)),(k-1),(k-1)) # average over n eq. (S.2.15)
    hb =  nobs * t(dbeta) %*% solve(vd_bn) %*% dbeta # a scalar of test statistics
    
    result = hb > qchisq(0.95, df=k-1) 
    output = c(result,hb,fete_hatb,fete_avarb,tmgc_hatb,tmgc_avb,np,phi_c,phi_av)
  }
  output
}

################################################################################

Test_rep = function(rep,nobs,Tobs,k,m_y,gauss_y,m_x,hetero_x,dist_x,ar_x,te_x,corr_e,para_case,kappa2,case,bal_panel,phi_te,te) {
  if (te==0) {
    test_result = matrix(,rep,7)
  }
  if (te==1) {
    test_result_te = matrix(,rep,7+te*(2*Tobs))
    test_result_c = matrix(,rep,7+te*(2*Tobs))
  }
  for (s in 1:rep) {
    paneldata_idt = Gen_balpanel(nobs,Tobs,k,m_y,gauss_y,m_x,hetero_x,dist_x,ar_x,te_x,corr_e,para_case,kappa2,phi_te,idt)
    paneldata = paneldata_idt[,3:(3+k-1)]
    
    if (te==0) {
      test_result[s,] = CorrHetero_test_mc(paneldata,nobs,Tobs,k)
    }
    if (te==1) {
      test_result_te[s,] = CorrHetero_TE_test_mc(paneldata,nobs,Tobs,k)
      if (Tobs>2) {
        test_result_c[s,] = CorrHetero_C_test_mc(paneldata,nobs,Tobs,k)
      }
    }
  }
  if (te==1) {
    test_result = list(test_result_te, test_result_c)
    names(test_result) = c("te","c")
  }
  test_result
}

################################################################################
### Set Key Parameters of DGP and Estimators
################################################################################
## Parameters of DGP
################################################################################
k = 2 # dim(wit) = k
m_y = cbind(1,1) # True value of parameters of ineterests
m_x = matrix(cbind(1,0),(k-1),2)

sigma_a = sqrt(0.2)
sigma_b = matrix(sqrt(c(0.5,0.75)),(k-1),2) # 2 cases
sigma = rbind(matrix(sigma_a,1,2),sigma_b) 
rho_eta = matrix(c(0.5,0,0.5,0.25,0.5,0.5),k,3) # 3 cases: only correlation in beta_i change for the test
PR2 = cbind(0.2,0.4) # 2 cases
di1 = length(PR2)
di2 = dim(sigma_b)[2]
di3 = dim(rho_eta)[2]
ncase = di1*di2*di3
case_list = seq(1,ncase,by=1)

case_table = matrix(,(1+k+k+k+k),ncase)
sigma_zeta_list = matrix(,k,ncase)
psi_list = matrix(,k,ncase)
for (i1 in 1:di1) {
  for (i2 in 1:di2) {
    for (i3 in 1:di3) {
      ic = i3+(i2-1)*di3+(i1-1)*di2*di3
      for (j in 1:k){
        sigma_zeta_list[j,ic] = sqrt(sigma[j,i2]^2*(1-rho_eta[j,i3]^2)) # Section S.3.1. 5(a)
        psi_list[j,ic] = rho_eta[j,i3]*sigma[j,i2] # Section S.3.1. 5(b)
      }
      case_table[,ic] = rbind(PR2[i1],sigma[1,i2]^2,sigma[2,i2]^2,rho_eta[1,i3],rho_eta[2,i3],sigma_zeta_list[1,ic]^2,sigma_zeta_list[2,ic]^2,psi_list[1,ic],psi_list[2,ic])
    }
  }
}
para_list = rbind(sigma_zeta_list,psi_list)
# (0) homogeneous slope coefficients
# (1) uncorrelated hetero rho_b=0, sigma_b=0.5
# (2) correlated hetero rho_b=0.25, sigma_b=0.5 
# (3) correlated hetero rho_b=0.5, sigma_b=0.5 - baseline
# (4) correlated hetero PR^2=0.4, rho_b=0.5, sigma_b=0.5
para_list = para_list[,c(1,1,2,3,9)] 
case_table = case_table[,c(1,1,2,3,9)] 
################################################################################

################################################################################
## Input data and fix the dimension
TNlist = c(1000,2000,5000,10000)
TTlist = c(2,3,4,5,6,8)
NT_list = expand.grid(TTlist,TNlist) 
dist_list = c(1,2)
rep = 2000 # number of replications for simulation
bal_panel = 1 # (0,1) Paneldata sets are balanced or not

################################################################################
## Setting the model in simulation
## combo of n and T
Nlist = c(1000,2000,5000,10000) 
Tlist = c(2,3,4,5,6,8)
NT = expand.grid(Nlist,Tlist) 

#### parameters of robustness
hetero_x = 1 # (0,1) errors in the x_it eq. are heteroskedastic or not
ar_x = 1 # (0,1) x_it follows an AR process or not
te_x = 0 # (0,2) not an interactive effect, a time effect, an interactive effect in x_{it}

#### different cases considered
gauss_y = 0 # (0,1) errors in the y_it eq. are Gaussian or chi-squared
corr_e = 0 # (0,1) errors in the y_it eq. are serially correlated or not

#### specification of simulation cases
dist_x = 1
ex_case = c(0,1,3)


################################################################################
### Run Monte Carlo simulation
################################################################################
for (te in c(0,1)) {
  test_m = matrix(,dim(NT_list)[1],5+(te>0)*5)
  name = paste("k2",dist_x,sep="dx")
  if (ar_x==1 & te_x==0) {
    name = paste(name,"arx",sep="_")
  }
  if (ar_x==1 & te_x==2) {
    name = paste(name,"afx",sep="_")
  }
  k2_table = get(name)
  for (case in ex_case) {
    for (l in 1:dim(NT)[1]) {
      ################################################################################
      nobs = NT[l,1]
      Tobs = NT[l,2]
      Tid = which(TTlist==Tobs)
      if (case==0) {
        kappa2 = 8 
      } else {
        kappa2 = k2_table[Tid,case-1*(case==3)*(te==0)]
      }
      rm(Tid)
      
      ## index of n and t for balanced paneldata sets
      Tl = matrix(seq(1,Tobs,by=1),Tobs,1)
      Tm = matrix(matrix(Tl,Tobs,nobs),nobs*Tobs,1)
      nl = matrix(seq(1,nobs,by=1),nobs,1)
      nm = matrix(t(matrix(nl,nobs,Tobs)),nobs*Tobs,1)
      idt = cbind(nm,Tm)
      rm(Tl,Tm,nl,nm)
      
      para_case = para_list[,(case+1)] # sigma_zeta, psi
      
      ### common time effects
      if (te==0) {
        phi_te = rep(0,Tobs) # T=3 (1,1,-2)
      }
      if (te==1) {
        phi_1 = seq(1,Tobs-1)
        phi_te = c(phi_1,-sum(phi_1))
      }
      ## A stationary AR(1) process of a common effect
      set.seed(2022202299)
      fth = matrix(,Tobs+51,1); fth[1]=0; # with a zero initial value
      for (tid in 2:(Tobs+51) ) {
        vt = rnorm(1,0,1)
        fth[tid] = 0.9*fth[tid-1]+sqrt(1-0.9^2)*vt;rm(vt) 
      }
      ft = fth[52:(Tobs+51)] # for t=1,2,...,T
      
      ### individual nuisance parameters
      set.seed(20222022)
      rhoe_n = matrix(runif(nobs,0,0.95),nobs,1) # hetero AR coeff in serial correlated errors
      
      set.seed(102021)
      sigma_vn = matrix(sqrt(0.5*rnorm(nobs,0,1)^2+0.5),nobs,(k-1)) # (n by k-1)
      sigma_un = matrix(sqrt(0.5*rnorm(nobs,0,1)^2+0.5),nobs,1) # (n by 1)
      axx_n = matrix(rnorm(nobs,0,1),nobs,(k-1)) # (n by k-1)
      phixx_n = matrix(runif(nobs,0,0.95),nobs,(k-1)) # (n by k-1)
      ################################################################################
      
      test_temp = Test_rep(rep,nobs,Tobs,k,m_y,gauss_y,m_x,hetero_x,dist_x,ar_x,te_x,corr_e,para_case,kappa2,case,bal_panel,phi_te,te)
      
      if (te==0) {
        name1 = paste("CHtest",dist_x,sep="_d")
        name2 = paste(name1,case,sep="c")
        name2 = paste(name2,ar_x,sep="_arx")
        name3 = paste(name2,nobs,sep="_n")
        name4 = paste(name3,Tobs,sep="_T")
        assign(name4,test_temp)
        test_m[as.numeric(which(TTlist==Tobs)+(which(TNlist==nobs)-1)*length(TTlist)),(case+1)]= mean(test_temp[,1])
      }
      if (te>0) {
        name1 = paste("CHtest","te",sep="_")
        name1 = paste(name1,dist_x,sep="_d")
        name2 = paste(name1,case,sep="c")
        name3 = paste(name2,nobs,sep="_n")
        name4 = paste(name3,Tobs,sep="_T")
        assign(name4,test_temp$te)
        test_m[as.numeric(which(TTlist==Tobs)+(which(TNlist==nobs)-1)*length(TTlist)),(case+1)]= mean(test_temp$te[,1])
        if (Tobs>2) {
          name1 = paste("CHtest","c",sep="_")
          name1 = paste(name1,dist_x,sep="_d")
          name2 = paste(name1,case,sep="c")
          name3 = paste(name2,nobs,sep="_n")
          name4 = paste(name3,Tobs,sep="_T")
          assign(name4,test_temp$c)
          test_m[as.numeric(which(TTlist==Tobs)+(which(TNlist==nobs)-1)*length(TTlist)),(case+1+5)]= mean(test_temp$c[,1])
        }
      }
      
    }
    rm(axx_n,idt,phixx_n,rhoe_n,sigma_un,sigma_vn)
  }
  if (te==0) {
    name1 = paste("CHtest",dist_x,sep="_d")
  } else {
    name1 = paste("CHtest_TE",dist_x,sep="_d")
  }
  assign(name1,test_m); 
  if (te==0) {
    print(cbind(NT_list,test_m[,1+ex_case]))
  } else {
    print(cbind(NT_list,test_m[,c(1+ex_case,5+ex_case)]))
  }
  
  ################################################################################
  ### Store Results of Monte Carlo simulation
  ################################################################################
  fn0 = "CHtest"
  if (te>0) {
    fn0 = paste(fn0,"_te",te,sep="")
  }
  ### 1. distribution of errors in x
  if (dist_x == 1) {
    fn1 = paste(fn0,"norm",sep="_")
  }
  if (dist_x == 2) {
    fn1 = paste(fn0,"unif",sep="_")
  }
  ### 2. with or without interactive effects in x
  fn2 = paste(fn1,te_x,sep="_tex")
  ### 3. non-Gaussian errors in panels or dynamics in x
  if (gauss_y == 1 & ar_x == 0) {
    fn3 = fn2
  }
  if (gauss_y==0) {
    fn3 = paste(fn2,"chi2",sep="_")
  }
  if (ar_x==1) {
    fn3 = paste(fn2,"arx",sep="_")
  }
  ### add extension as "RData"
  fn4 = paste(fn3,".RData",sep="")
  
  ################################################################################
  save.image(file = fn4) 
}

# Report MC results of tests of correlated heterogeneity: Tables 5 and S.15
##############################################################################
wb <- createWorkbook()

# Create a style for center-aligning the numbers
##############################################################################
center_style <- createStyle(halign = "center")
right <- createStyle(halign = "right")
left <- createStyle(halign = "left")
bbs <- createStyle(border = "bottom",borderStyle="thin")
lbs <- createStyle(border = "bottom",borderStyle="double")
tbs <- createStyle(border = "top",borderStyle="double")
wrap_text_style <- createStyle(wrapText = TRUE)
##############################################################################

sn = "Table 5"
addWorksheet(wb, sn)
fn1 = "CHtest_norm_tex0_arx.RData"
en = 1; temp1 = tryCatch(load(fn1),error=function(e) print(en));te=0

if (temp1[1] != 1) {
  writeData(wb, sn, x = "Table 5: Empirical size and power of the Hausman-type test of correlated heterogeneity in the baseline model without time effects", startCol = 1, startRow = 1, colNames = FALSE)
  writeData(wb, sn, x = "Under H_1", startCol = 3, startRow = 2, colNames = FALSE)
  writeData(wb, sn, x = "Under H_0", startCol = 13, startRow = 2, colNames = FALSE)
  
  panel_nrow = length(Tlist) 
  panel_ncol = length(Nlist)*3
  
  tab0 = matrix(CHtest_d1[,c(1,2,4)],panel_nrow,panel_ncol)
  tab = matrix(,panel_nrow,panel_ncol)
  for (i in 1:(dim(tab0)[1])) {
    for (j in 1:(dim(tab0)[2])) {
      tab[i,j] = format(round(tab0[i,j]*100, 1), nsmall = 1) 
    }
  }
  
  r1 = matrix(Tlist,panel_nrow,1)
  ncv = matrix("",nrow(tab),1)
  tab = cbind(r1,ncv,tab[,1:4],ncv,tab[,5:8],ncv,tab[,9:12])
  nrv = matrix("",1,ncol(tab))
  
  mergeCells(wb, sheet = sn, cols = 1:16, rows = 1)
  mergeCells(wb, sheet = sn, cols = 3:11, rows = 2)
  mergeCells(wb, sheet = sn, cols = 13:16, rows = 2)
  
  h1 = c("","","Homogeneity: sigma_{beta}^2=0","","","","","Uncorrelated hetro.: rho_{beta}=0,sigma_{beta}^2=0.5","","","","","Correlated hetro.: rho_{beta}=0.5,sigma_{beta}^2=0.5","","","")
  h2 = c("T/n","","1,000","2,000","5,000","10,000","","1,000","2,000","5,000","10,000","","1,000","2,000","5,000","10,000")
  h = rbind(h1,h2,tab)
  rownames(h) <- NULL; colnames(h) <- NULL
  writeData(wb,sn, x = h, startCol = 1, startRow = 3,colNames = FALSE, rowNames = FALSE)
  mergeCells(wb, sheet = sn, cols = 3:6, rows = 3)
  mergeCells(wb, sheet = sn, cols = 8:11, rows = 3)
  mergeCells(wb, sheet = sn, cols = 13:16, rows = 3)
  
  addStyle(wb,sn,style = center_style, rows = c(2:4),cols = 1:(ncol(h)), gridExpand = T)
  addStyle(wb,sn,style = right, rows = c(5:10),cols = 1:(ncol(h)), gridExpand = T)
  addStyle(wb,sn,style = left, rows = 1:10,cols = 1, gridExpand = T)
  addStyle(wb,sn,style = wrap_text_style, rows = 1,cols = 1:(ncol(h)), gridExpand = T,stack=T)
  addStyle(wb,sn,style = bbs, rows = 2,cols = c(3:11,13:16), gridExpand = T,stack=T)
  addStyle(wb,sn,style = bbs, rows = 3,cols = c(3:6, 8:11, 13:16), gridExpand = T,stack=T)
  addStyle(wb,sn,style = bbs, rows = 4,cols = 1:(ncol(h)), gridExpand = T,stack=T)
  addStyle(wb,sn,style = tbs, rows = 2,cols = 1:(ncol(h)), gridExpand = T,stack=T)
  addStyle(wb,sn,style = lbs, rows = (nrow(h)+2),cols = 1:(ncol(h)), gridExpand = T,stack=T)
}


sn = "Table S.15"
addWorksheet(wb, sn)
fn1 = "CHtest_te1_norm_tex0_arx.RData"
en = 1; temp1 = tryCatch(load(fn1),error=function(e) print(en));te=1

if (temp1[1] != 1) {
  writeData(wb, sn, x = "Table S.15: Empirical size and power of the Hausman-type test of correlated heterogeneity in the baseline model with time effects", startCol = 1, startRow = 1, colNames = FALSE)
  writeData(wb, sn, x = "Under H_1", startCol = 3, startRow = 2, colNames = FALSE)
  writeData(wb, sn, x = "Under H_0", startCol = 13, startRow = 2, colNames = FALSE)
  
  tab1 = matrix(CHtest_TE_d1[,c(1,2,4)],length(Tlist),length(Nlist)*3)
  tab2 = matrix(CHtest_TE_d1[,c(1,2,4)+5],length(Tlist),length(Nlist)*3) 
  tab2 = tab2[-1,]
  tab0 = rbind(tab1,tab2)
  tab = matrix(,nrow(tab0),ncol(tab0))
  for (i in 1:(dim(tab0)[1])) {
    for (j in 1:(dim(tab0)[2])) {
      tab[i,j] = format(round(tab0[i,j]*100, 1), nsmall = 1) 
    }
  }
  
  r1 = matrix(c(Tlist,Tlist[-1]),nrow(tab0),1)
  ncv = matrix("",nrow(tab),1)
  tab = cbind(r1,ncv,tab[,1:4],ncv,tab[,5:8],ncv,tab[,9:12])
  
  mergeCells(wb, sheet = sn, cols = 1:16, rows = 1)
  mergeCells(wb, sheet = sn, cols = 3:11, rows = 2)
  mergeCells(wb, sheet = sn, cols = 13:16, rows = 2)
  
  h1 = c("","","Homogeneity: sigma_{beta}^2=0","","","","","Uncorrelated hetro.: rho_{beta}=0,sigma_{beta}^2=0.5","","","","","Correlated hetro.: rho_{beta}=0.5,sigma_{beta}^2=0.5","","","")
  h2 = c("T/n","","1,000","2,000","5,000","10,000","","1,000","2,000","5,000","10,000","","1,000","2,000","5,000","10,000")
  h3 = c("TMG-TE",rep("",15))
  h4 = c("TMG-C",rep("",15))
  h = rbind(h1,h2,h3,tab[1:6,],h4,tab[7:11,])
  rownames(h) <- NULL; colnames(h) <- NULL
  writeData(wb,sn, x = h, startCol = 1, startRow = 3,colNames = FALSE, rowNames = FALSE)
  mergeCells(wb, sheet = sn, cols = 3:6, rows = 3)
  mergeCells(wb, sheet = sn, cols = 8:11, rows = 3)
  mergeCells(wb, sheet = sn, cols = 13:16, rows = 3)
  mergeCells(wb, sheet = sn, cols = 1:16, rows = 5)
  mergeCells(wb, sheet = sn, cols = 1:16, rows = 12)
  
  addStyle(wb,sn,style = center_style, rows = c(2:4),cols = 1:(ncol(h)), gridExpand = T)
  addStyle(wb,sn,style = right, rows = c(6:11,13:17),cols = 1:(ncol(h)), gridExpand = T)
  addStyle(wb,sn,style = left, rows = 1:17,cols = 1, gridExpand = T)
  addStyle(wb,sn,style = wrap_text_style, rows = 1,cols = 1:(ncol(h)), gridExpand = T,stack=T)
  addStyle(wb,sn,style = bbs, rows = 2,cols = c(3:11,13:16), gridExpand = T,stack=T)
  addStyle(wb,sn,style = bbs, rows = 3,cols = c(3:6,8:11,13:16), gridExpand = T,stack=T)
  addStyle(wb,sn,style = bbs, rows = c(4,5,12),cols = 1:(ncol(h)), gridExpand = T,stack=T)
  addStyle(wb,sn,style = tbs, rows = 2,cols = 1:(ncol(h)), gridExpand = T,stack=T)
  addStyle(wb,sn,style = lbs, rows = (nrow(h)+2),cols = 1:(ncol(h)), gridExpand = T,stack=T)
}

saveWorkbook(wb, file = "TMG_MC_test_results.xlsx",overwrite = TRUE)
##############################################################################

cat("MC Results of the tests of correlated heterogeneity have been written to the excel file TMG_MC_test_results.xlsx.")





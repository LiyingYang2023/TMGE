### Data organization
################################################################################
rm(list=ls())
if (!requireNamespace("R.matlab", quietly = TRUE)) {
  install.packages("R.matlab")
}
library(R.matlab)
library(MASS)
data = readMat('RPS_panel.mat') # from Graham and Powell (2012)

nobs = length(data$Y0)
y1 = as.matrix(data$Y0)
y2 = as.matrix(data$Y1)
y3 = as.matrix(data$Y2)
x11 = as.matrix(data$X0)
x12 = as.matrix(data$X1)
x13 = as.matrix(data$X2)

# Tobs=2, 2000--2001
# X1 = matrix(rbind(t(x11),t(x12)),nobs*2,1)
# Y1 = matrix(rbind(t(y1),t(y2)),nobs*2,1)
# paneldata_T2_1 = cbind(Y1,X1);

# Tobs=2, 2001--2002
X2 = matrix(rbind(t(x12),t(x13)),nobs*2,1)
Y2 = matrix(rbind(t(y2),t(y3)),nobs*2,1)
panel.0102 = cbind(Y2,X2);

# Tobs=3, 2000--2002
X3 = matrix(rbind(t(x11),t(x12),t(x13)),nobs*3,1)
Y3 = matrix(rbind(t(y1),t(y2),t(y3)),nobs*3,1)
panel.0002 = cbind(Y3,X3)
################################################################################


### Functions for the test statistics for panels without time effects CorrHetero_test()
### PMD_i, PMDV_i, Minor, Cofactor, Adjoint1, Det_i, TOLS_i, Vd_i
################################################################################
## Functions for calculating FE and FE-TE estimates: PMD_i, PMDV_i
PMD_i = function(m1,m2,Tobs,id) {
  Ti = Tobs
  xi = as.matrix(m1[(1+(id-1)*Ti):(id*Ti),]) # (T by k1)
  yi = as.matrix(m2[(1+(id-1)*Ti):(id*Ti),]) # (T by k2)
  k1i = dim(xi)[2]
  k2i = dim(yi)[2]
  mti = diag(Ti)-matrix(1, nrow=Ti, ncol=1) %*% t(matrix(1, nrow=Ti, ncol=1))/Ti # (T by T)
  pd_i = matrix(t(xi) %*% mti %*% yi,k1i*k2i,1) # (k1*k2) by 1
  pd_i
}

PMDV_i = function(mx,mre,Tobs,id) {
  Ti = Tobs
  xi = as.matrix(mx[(1+(id-1)*Ti):(id*Ti),]) # (T by k )
  rei = as.matrix(mre[(1+(id-1)*Ti):(id*Ti),]) # (T by 1) residuals
  ki = dim(xi)[2]
  Mti = diag(Ti)-matrix(1, nrow=Ti, ncol=1) %*% t(matrix(1, nrow=Ti, ncol=1))/Ti # (T by T)
  pdv_i = matrix(t(xi) %*% Mti %*% rei %*% t(rei) %*% Mti %*% xi,ki*ki,1) # (k*k)  by 1
  pdv_i
}

## Functions for calculating TMG estimates: Minor, Cofactor, Adjoint1, Det_i, TOLS_i
Minor = function(A, i, j) {
  det(as.matrix(A[-i,-j]) )
}

Cofactor = function(A, i, j) {
  (-1)^(i+j) * Minor(A,i,j)
}

Adjoint1 = function(A) {
  n = nrow(A)
  B = matrix(, n, n)
  for( i in 1:n )
    for( j in 1:n )
      B[j,i] = Cofactor(A, i, j)
  B
}

Det_i = function(paneldata_w,nobs,Tobs,k,id) {
  wi = matrix(paneldata_w[(1+(id-1)*Tobs):(id*Tobs),],Tobs,k)  # (T by k) including intercepts
  deti = det(t(wi) %*% wi) # scalar where t(wi) %*% wi is a (k by k) matrix
  deti
}

TOLS_i = function(panel_int,nobs,Tobs,k,an,id){
  obsi = as.matrix(panel_int[(1+(id-1)*Tobs):(id*Tobs),]) # paneldata = {(yi,wi)} (nT by k+1) matrix including intercepts
  yi = as.matrix(obsi[,1]) # yi (T by 1)
  wi = as.matrix(obsi[,2:(k+1)]) # regressor wi (T by k) with wit = (1,xit')'
  di = det(t(wi) %*% wi) # determinant
  if (di > an) {
    theta_i = solve(t(wi) %*% wi) %*% (t(wi) %*% yi) # (k by 1) individual OLS estimator
  } else {
    theta_i = an^(-1) * Adjoint1(t(wi) %*% wi) %*% (t(wi) %*% yi) # (k by 1) individual trimmed estimator
  }
  theta_i # eq. (4.2)
}

## Functions for calculating denominator of test statistics: Vd_i
Vd_i = function(panel_int,nobs,Tobs,k,an,q_bn,delta_bn,fe_hatb,id) {
  yi = matrix(panel_int[(1+(id-1)*Tobs):(id*Tobs),1],Tobs,1)
  wi = matrix(panel_int[(1+(id-1)*Tobs):(id*Tobs),2:(1+k)],Tobs,k)  # (T by k)
  xi = matrix(panel_int[(1+(id-1)*Tobs):(id*Tobs),3:(1+k)],Tobs,k-1) # (T by k-1)
  taut = matrix(1,Tobs,1) 
  mt = diag(1,Tobs)-taut %*% solve(t(taut)%*%taut) %*% t(taut) # (T by T)
  di = det(t(wi) %*% wi)
  if (di > an) {
    wwinv = solve(t(wi) %*% wi)  # (k by 1) individual OLS estimator
  } else {
    wwinv = an^(-1) * Adjoint1(t(wi) %*% wi)  # (k by 1) individual trimmed estimator
  }
  xmxinv = as.matrix(wwinv[-c(1),-c(1)]) # (1+delta_i) (X_i'M_TX_i)^{-1}
  
  gi = (solve(q_bn)-1/(1+delta_bn)*xmxinv) %*% t(xi)  # (k-1 by T) matrix eq. (7.3)
  refei = mt %*% (yi - xi %*% fe_hatb) # (T by 1) vector of residuals
  ggeei= matrix(0,k-1,k-1)
  
  for (t in 1:Tobs) {
    for (s in 1:Tobs) {
      git = gi[,t] 
      eit = refei[t]
      gis = gi[,s] 
      eis = refei[s] 
      ggeei = ggeei + git %*% t(gis) * (eit*eis) #  eq.(7.2)
    }
  }
  ggeei # a (k-1) by (k-1) matrix
}

CorrHetero_test = function(paneldata,nobs,Tobs,k) {
  #### Import data of a balanced panel
  ######################################################
  nT = nobs*Tobs
  id_list = as.matrix(seq(1,nobs,by=1))
  int_nT_long = matrix(1,nobs*Tobs,1)
  paneldata_w = cbind(int_nT_long,paneldata[,2:k])
  panel_int = cbind(paneldata[,1],paneldata_w) # add intercepts
  y = as.matrix(panel_int[,1]) # (nT by 1)
  w = as.matrix(panel_int [,2:(1+k)]) # (nT by k) regressors include intercepts
  x = as.matrix(panel_int[,3:(1+k)]) # (nT by k-1)
  ######################################################
  
  ### FE estimation results
  ######################################################
  # FE (1) calculate numerator and denominator of FE estimator
  xmx_n = matrix(sapply(id_list,PMD_i,m1=x,m2=x,Tobs=Tobs),(k-1)*(k-1),nobs) 
  xmx = matrix(rowMeans(xmx_n)/Tobs,(k-1),(k-1)) # (k-1 by k-1) average over nT
  xmy_n = matrix(sapply(id_list,PMD_i,m1=x,m2=y,Tobs=Tobs),k-1,nobs) # k=2: (1 by n)
  xmy = matrix(rowMeans(xmy_n)/Tobs,k-1,1) # (k-1 by 1) average over nT
  
  # FE (2) calculate estimators and residuals
  fe_hatb = solve(xmx) %*% xmy # (k-1 by 1) eq. (2.14)
  taut = matrix(1,Tobs,1) 
  mt = diag(1,Tobs)-taut %*% solve(t(taut)%*%taut) %*% t(taut) # (T by T)
  re_fe = as.matrix(y - x %*% fe_hatb) # (nT by 1) residuals
  # refe_0 = t(matrix(re_fe,Tobs,nobs)) # (n by T) 
  # refe_m = refe_0 %*% mt # (n by T) matrix
  
  # FE (3) calcualte asymptotic variance of FE estimators
  xmuumx_n = matrix(sapply(id_list,PMDV_i,mx=x,mre=re_fe,Tobs=Tobs),(k-1)*(k-1),nobs)
  xmuumx = matrix(rowMeans(xmuumx_n)/Tobs,k-1,k-1) # (k-1 by k-1) average over nT
  fe_avarb = solve(xmx) %*% xmuumx %*% solve(xmx) / nobs / Tobs # Pesaran (2015) p. 654 
  ######################################################
  
  ### TMG estimation results
  ######################################################
  ## TMG (1) calculate di=det(Wi'Wi) and the threshold an = mean(di)*(n^(-arate))
  det_n = sapply(id_list,Det_i,paneldata_w=w,nobs=nobs,Tobs=Tobs,k=k) 
  det_bn = mean(det_n) # the sample mean of di=det(Wi'Wi)
  arate=1/3 # power of n in the threshold
  an = det_bn*(nobs^(-arate)) # the threshold
  
  ## TMG (2) calculate the trimming index
  trim_n = (det_n<=an)
  np = mean(trim_n)
  
  ## TMG (3) calculate trimmed individual estimates
  theta_trim_n = sapply(id_list,TOLS_i,panel_int=panel_int,nobs=nobs,Tobs=Tobs,k=k,an=an) # (k by n) eq. (4.2)
  tmgh_hat = matrix(rowMeans(theta_trim_n),k,1) # (k by 1) average over n eq. (4.4)
  
  ## TMG (4) calculate bias-corrected TMG estimator 
  delta_n = (det_n/an-1)*trim_n # (n by 1) eq. (4.3)
  delta_bn = mean(delta_n)
  tmg_hat = (1+delta_bn)^(-1)*tmgh_hat # (k by 1) eq. (4.5)
  tmg_hatb = tmg_hat[2:k,1]
  
  ## TMG (5) calculate asymptotic variance of TMG estimator 
  tmg_bm = matrix(tmg_hat, k ,nobs)
  tmg_av =(1+delta_bn)^(-2)*(nobs*(nobs-1))^(-1)*(theta_trim_n-tmg_bm) %*% t(theta_trim_n-tmg_bm) # (k by k) eq. (5.21)
  tmg_varb = diag(tmg_av)[2:k]
  ######################################################
  
  ### Calculate test statistics
  ######################################################
  dbeta = fe_hatb-tmg_hatb # (k-1) by 1 vector
  q_bn = matrix(rowMeans(xmx_n),(k-1),(k-1)) # (k-1 by k-1) average over n
  vd_n = sapply(id_list,Vd_i,panel_int=panel_int,nobs=nobs,Tobs=Tobs,k=k,an=an,q_bn=q_bn,delta_bn=delta_bn,fe_hatb=fe_hatb) # (k-1)*(k-1) by n matrix 
  vd_bn = matrix(rowMeans(matrix(vd_n,(k-1)*(k-1),nobs)),(k-1),(k-1)) # average over n eq. (7.2)
  hb =  nobs * t(dbeta) %*% solve(vd_bn) %*% dbeta # a scalar of test statistics eq. (7.4)
  
  result = 1-pchisq(hb, df=k-1, ncp = 0, lower.tail = TRUE, log.p = FALSE)
  output = c(hb,result,fe_hatb,fe_avarb,tmg_hatb,tmg_varb,np)
  names(output) = c("statistics",'p.value',"fe.hat","fe.avar","tmg.hat","tmg.avar","trim.percent")
  output
}
#################################################################################

### Functions for rge test statistics for panels with time effects: CorrHetero_TE_test() and CorrHetero_C_test()
### TMG-TE: PMD_i, PMDV_i, Minor, Cofactor, Adjoint1, Det_i, TOLS_i, Qw_i, Phiuu_i, Vdte_i
### TMG-C: PMD_i, PMDV_i, Minor, Cofactor, Adjoint1, Det_i, TOLS_i, MTxy_i, MTuu_i, Qw_i, Vdc_i
################################################################################
Qw_i = function(paneldata_w,nobs,Tobs,k,an,id){
  wi = matrix(paneldata_w[(1+(id-1)*Tobs):(id*Tobs),],Tobs,k)  # (T by k)
  di = det(t(wi) %*% wi) # determinant
  if (di > an) {
    qw_i = wi %*% solve(t(wi) %*% wi)  # (T by k)
  } else {
    qw_i = an^(-1)* wi %*% Adjoint1(t(wi) %*% wi)  # (T by k)
  }
  qw_i # eq. (6.3)
}

# calculate part of the variance of the TMG-TE estimator of the time effects phi_hat
Phiuu_i = function(paneldata,nobs,Tobs,k,est,id) {
  yi = matrix(paneldata[(1+(id-1)*Tobs):(id*Tobs),1],Tobs,1)
  xi = matrix(paneldata[(1+(id-1)*Tobs):(id*Tobs),2:k],Tobs,k-1) # (T by k-1)
  phi_hat = as.matrix(est[1:Tobs]) # (T by 1)
  beta_hat = as.matrix(est[(Tobs+2):(Tobs+k)]) # (k-1) by 1
  ui = yi - xi %*% beta_hat - phi_hat
  uui = ui %*% t(ui) # eq. (A.3.6)
  uui # (T by T)
}

Vdte_i = function(panel_int,nobs,Tobs,k,an,x_bn,y_bn,psi_nx,q_nx,delta_bn,qw_n,fete_hatb,id) {
  yi = matrix(panel_int[(1+(id-1)*Tobs):(id*Tobs),1],Tobs,1)
  wi = matrix(panel_int[(1+(id-1)*Tobs):(id*Tobs),2:(1+k)],Tobs,k)  # (T by k)
  xi = matrix(panel_int[(1+(id-1)*Tobs):(id*Tobs),3:(1+k)],Tobs,k-1) # (T by k-1)
  taut = matrix(1,Tobs,1) 
  mt = diag(1,Tobs)-taut %*% solve(t(taut)%*%taut) %*% t(taut) # (T by T)
  refei = matrix(mt %*% ((yi-y_bn) - (xi-x_bn) %*% fete_hatb), Tobs,1) # (T by 1) vector of residuals
  
  q_iw = matrix(qw_n[,id],Tobs,k) # (T by k)
  q_ix = matrix(q_iw[,-1],Tobs,k-1) # (T by k-1) partitioned from Q_i eq. (S.2.4)
  
  gi1 = (xi-x_bn) %*% solve(psi_nx) # FE-TE (T by k-1)
  gi2 = (1/(1+delta_bn)*q_ix) %*% t(solve(diag(1,k-1)-t(q_nx)%*%mt%*%x_bn)) # TMG-TE
  gi = matrix((gi1-gi2),Tobs,k-1) # (T by k-1) matrix eq. (S.2.10)
  
  ggeei= t(gi) %*% mt %*% refei %*% t(refei) %*% mt %*% gi # eq. (S.2.8)
  ggeei # a (k-1) by (k-1) matrix
}

## Functions for calculating TMG-C estimates: Mtxy_i
MTxy_i = function(paneldata,nobs,Tobs,k,id) {
  yi = matrix(paneldata[(1+(id-1)*Tobs):(id*Tobs),1],Tobs,1)
  xi = matrix(paneldata[(1+(id-1)*Tobs):(id*Tobs),2:k],Tobs,k-1) # (T by k-1)
  taut = matrix(1,Tobs,1) 
  mt = diag(1,Tobs)-taut %*% solve(t(taut)%*%taut) %*% t(taut) # (T by T)
  mtxi = mt %*% xi
  mti = diag(1,Tobs)- mtxi %*% solve(t(mtxi) %*% mtxi) %*% t(mtxi) # (T by T)
  mtyi = mti %*% mt %*% yi # (T by 1)
  mtxyi = cbind(mti,mtyi) # T by (T+1) 
  mtxyi # components in (6.18)
}

# calculate part of the variance of phi_c
MTuu_i = function(paneldata,nobs,Tobs,k,phi_c,id) {
  yi = matrix(paneldata[(1+(id-1)*Tobs):(id*Tobs),1],Tobs,1)
  xi = matrix(paneldata[(1+(id-1)*Tobs):(id*Tobs),2:k],Tobs,k-1) # (T by k-1)
  taut = matrix(1,Tobs,1) 
  mt = diag(1,Tobs)-taut %*% solve(t(taut)%*%taut) %*% t(taut) # (T by T)
  mtxi = mt %*% xi
  mti = diag(1,Tobs)- mtxi %*% solve(t(mtxi)%*% mtxi) %*% t(mtxi) # (T by T)
  ydtei = matrix(yi - phi_c,Tobs,1)
  mtuui = mti %*% mt %*% ydtei %*% t(ydtei) %*% t(mti %*% mt) # component in (6.20)
  mtuui
}

Vdc_i = function(panel_int,nobs,Tobs,k,an,x_bn,y_bn,psi_nx,q_nx,mtx_bn,delta_bn,qw_n,fete_hatb,id) {
  yi = matrix(panel_int[(1+(id-1)*Tobs):(id*Tobs),1],Tobs,1)
  wi = matrix(panel_int[(1+(id-1)*Tobs):(id*Tobs),2:(1+k)],Tobs,k)  # (T by k)
  xi = matrix(panel_int[(1+(id-1)*Tobs):(id*Tobs),3:(1+k)],Tobs,k-1) # (T by k-1)
  taut = matrix(1,Tobs,1) 
  mt = diag(1,Tobs)-taut %*% solve(t(taut)%*%taut) %*% t(taut) # (T by T)
  refei = matrix(((yi-y_bn) - (xi-x_bn) %*% fete_hatb), Tobs,1) # (T by 1) vector of residuals
  q_iw = matrix(qw_n[,id],Tobs,k) # T by k
  q_ix = matrix(q_iw[,-c(1)],Tobs,k-1) # T by k-1
  
  gi1 = (xi-x_bn) %*% solve(psi_nx) # FE-TE
  mtxi = mt %*% xi    
  mti = diag(1,Tobs)- mtxi %*% solve(t(mtxi) %*% mtxi) %*% t(mtxi) 
  gi2 = (1+delta_bn)^(-1)*q_ix -  mti %*%solve(mtx_bn)%*%mt%*% q_nx # TMG-C
  gi = matrix((gi1-gi2),Tobs,k-1) # (T by k-1) matrix
  
  ggeei= t(gi) %*% mt %*% refei %*% t(refei) %*% mt %*% gi # eq. (S.2.16)
  ggeei # a (k-1) by (k-1) matrix
}

CorrHetero_TE_test = function(paneldata,nobs,Tobs,k) {
  if (Tobs<k) {
    output = "The Hausman-type test is not applicable when T<k."
  }
  
  if (Tobs>=k) {
    #### Import data of a balanced panel
    ######################################################
    nT = nobs*Tobs
    id_list = as.matrix(seq(1,nobs,by=1))
    int_nT_long = matrix(1,nobs*Tobs,1)
    panel_int = cbind(paneldata[,1],cbind(int_nT_long,paneldata[,2:k])) # add intercepts
    y = as.matrix(panel_int[,1]) # (nT by 1)
    w = as.matrix(panel_int [,2:(1+k)]) # (nT by k) regressors include intercepts
    x = as.matrix(panel_int[,3:(1+k)]) # (nT by k-1)
    ######################################################
    
    ### FE-TE estimation results
    ######################################################
    # FE-TE (1) eliminate the time effects
    x_n = matrix(t(x),Tobs*(k-1),nobs) # T*(k-1) by n
    x_bn = t(matrix(rowMeans(x_n),(k-1),Tobs)) # T by (k-1) average over i
    x_bnm = t(matrix(t(x_bn),(k-1),Tobs*nobs)) # nT by (k-1) 
    x_dn = x - x_bnm # (nT by k-1) x_{it} - x_{ot}
    
    y_n = matrix(t(y),Tobs,nobs) # T by n
    y_bn = t(matrix(rowMeans(y_n),1,Tobs)) # T by 1
    y_bnm = t(matrix(t(y_bn),1,Tobs*nobs)) # T by n
    y_dn = y - y_bnm # nT by 1
    
    x2 = x_dn
    y2 = y_dn
    
    # FE-TE (2) calculate numerator and denominator of FE estimator
    xmx_n = matrix(sapply(id_list,PMD_i,m1=x2,m2=x2,Tobs=Tobs),(k-1)*(k-1),nobs) 
    xmx = matrix(rowMeans(xmx_n)/Tobs,(k-1),(k-1)) # (k-1 by k-1) average over nT
    xmy_n = matrix(sapply(id_list,PMD_i,m1=x2,m2=y2,Tobs=Tobs),k-1,nobs) # k=2: (1 by n)
    xmy = matrix(rowMeans(xmy_n)/Tobs,k-1,1) # (k-1 by 1) average over nT
    
    # FE-TE (3) calculate estimators and residuals
    fete_hatb = solve(xmx) %*% xmy # (k-1 by 1) eq. (S.2.1)
    re_fe = as.matrix(y2 - x2 %*% fete_hatb) # (nT by 1) 
    
    # FE-TE (4) calcualte ssymptotic variance 
    xmuumx_n = matrix(sapply(id_list,PMDV_i,mx=x2,mre=re_fe,Tobs=Tobs),(k-1)*(k-1),nobs)
    xmuumx = matrix(rowMeans(xmuumx_n)/Tobs,k-1,k-1) # (k-1 by k-1) average over nT
    fete_avarb = solve(xmx) %*% xmuumx %*% solve(xmx) / nobs / Tobs # Pesaran (2015) p. 654 
    ######################################################
    
    ### TMG-TE estimation results when T=k
    ######################################################
    det_n = sapply(id_list,Det_i,paneldata_w=w,nobs=nobs,Tobs=Tobs,k=k) 
    det_bn = mean(det_n) # the sample mean of di=det(Wi'Wi)
    arate = 1/3
    an = det_bn*(nobs^(-arate)) # the threshold
    
    ## TMG (2) calculate the trimming index
    trim_n = (det_n<=an)
    np = mean(trim_n)
    
    ## TMG (3) calculate trimmed individual estimates
    theta_trim_n = sapply(id_list,TOLS_i,panel_int=panel_int,nobs=nobs,Tobs=Tobs,k=k,an=an) # (k by n)
    tmgh_hat = matrix(rowMeans(theta_trim_n),k,1) # (k by 1) average over n
    
    ## TMG (4) calculate bias-corrected TMG estimator 
    delta_n = (det_n/an-1)*trim_n # (n by 1)
    delta_bn = mean(delta_n)
    tmg_hat = (1+delta_bn)^(-1)*tmgh_hat # (k by 1) eq. (4.5)
    
    ## calculate TMG-TE estimator under tau'phi=0
    w_n = matrix(t(w),k*Tobs,nobs) # (Tk by n)
    w_bn = t(matrix(rowMeans(w_n),k,Tobs)) # (T by k) average over n
    y_n = matrix(y,Tobs,nobs) # (T by n)
    y_bn = matrix(rowMeans(y_n),Tobs,1) # (T by 1) {y_it} average over n for each t
    
    taut = matrix(1,Tobs,1) 
    mt = diag(1,Tobs)-taut %*% solve(t(taut)%*%taut) %*% t(taut) # (T by T)
    
    qw_n = sapply(id_list,Qw_i,paneldata_w=w,nobs=nobs,Tobs=Tobs,k=k,an=an) # Tk by n eq. (6.3)
    qw_bn = (1+delta_bn)^(-1)*matrix(rowMeans(qw_n),Tobs,k) # (T by k) eq. (6.4)
    q_nx = matrix(qw_bn[,-1],Tobs,k-1) # eq. (S.2.5)
    
    ## TMG-TE (1) calculate estimator phi_hat and theta_hat
    phi_hat = solve(diag(1,Tobs)-mt%*%w_bn%*%t(qw_bn)) %*% mt %*% (y_bn-w_bn%*%tmg_hat) # eq. (6.11)
    theta_hat = tmg_hat - t(qw_bn)%*%phi_hat # eq. (6.9)
    
    ## TMG-TE (2) calculate asymptotic variance of theta_hat
    phie_nT = matrix(matrix(phi_hat,Tobs,nobs),Tobs*nobs,1)
    ydte_nT = y - phie_nT # (nT by 1) 
    panel_dte = cbind(ydte_nT,w)  
    theta_te_n = sapply(id_list,TOLS_i,panel_int=panel_dte,nobs=nobs,Tobs=Tobs,k=k,an=an) # (k by n)
    theta_bm = matrix(theta_hat,k,nobs)
    theta_av0 = (1+delta_bn)^(-2)*(nobs*(nobs-1))^(-1)*(theta_te_n-theta_bm) %*% t(theta_te_n-theta_bm) # (k by k) eq. (A.3.5)
    theta_av = solve(diag(1,k)-t(qw_bn)%*%mt%*%w_bn)%*%theta_av0%*%t(solve(diag(1,k)-t(qw_bn)%*%mt%*% w_bn)) # eq. (A.3.4)
    
    tmgte_hatb = theta_hat[2:k,1]
    tmgte_avb = theta_av[2:k,2:k]
    
    ## TMG-TE asymptotic variance of time effects phi
    tmgte_hat = as.matrix(c(phi_hat,theta_hat)) # (T+k) by 1: phi_hat, theta_hat 
    phiuu_n = sapply(id_list,Phiuu_i,paneldata=paneldata,nobs=nobs,Tobs=Tobs,k=k,est=tmgte_hat) 
    phiuu_bn = matrix(rowMeans(phiuu_n),Tobs,Tobs) 
    phi_av0 = (nobs-1)^(-1)*phiuu_bn # eq. (A.3.6)
    phi_av = mt %*% ( w_bn %*% theta_av %*% t(w_bn) + phi_av0 ) %*% mt # eq. (A.3.7)
    
    phi_av = diag(phi_av)
    ######################################################
    
    ### Calculate test statistics
    ######################################################
    dbeta = fete_hatb - tmgte_hatb # (k-1) by 1 vector
    psi_nx = matrix(rowMeans(xmx_n),(k-1),(k-1)) # (k-1 by k-1) average over n
    vd_n = sapply(id_list,Vdte_i,panel_int=panel_int,nobs=nobs,Tobs=Tobs,k=k,an=an,
                  x_bn=x_bn,y_bn=y_bn,psi_nx=psi_nx,q_nx=q_nx,delta_bn=delta_bn,qw_n=qw_n,fete_hatb=fete_hatb)
    vd_bn = matrix(rowMeans(matrix(vd_n,(k-1)*(k-1),nobs)),(k-1),(k-1)) # average over n eq. (S.2.8)
    hb =  nobs * t(dbeta) %*% solve(vd_bn) %*% dbeta # a scalar of test statistics eq. (S.2.11)
    
    result = 1-pchisq(hb, df=k-1, ncp = 0, lower.tail = TRUE, log.p = FALSE)
    output = c(hb,result,fete_hatb,fete_avarb,tmgte_hatb,tmgte_avb,np,phi_hat,phi_av)
    names(output) = c("statistics",'p.value',"fete.hat","fete.avar","tmgte.hat","tmgte.avar","trim.percent",rep("te.hat",Tobs),rep("te.avar",Tobs))
  }
  output
}

CorrHetero_C_test = function(paneldata,nobs,Tobs,k) {
  if (Tobs==k) {
    output = "The Hausman-type test based on the different between the FE-TE and TMG-C estimators is not applicable when T<=k."
  }
  
  if (Tobs>k) {
    ##### Import data of a balanced panel
    ######################################################
    nT = nobs*Tobs
    id_list = as.matrix(seq(1,nobs,by=1))
    int_nT_long = matrix(1,nobs*Tobs,1)
    panel_int = cbind(paneldata[,1],cbind(int_nT_long,paneldata[,2:k])) # add intercepts
    y = as.matrix(panel_int[,1]) # (nT by 1)
    w = as.matrix(panel_int [,2:(1+k)]) # (nT by k) regressors include intercepts
    x = as.matrix(panel_int[,3:(1+k)]) # (nT by k-1)
    ######################################################
    
    ### FE-TE estimation results
    ######################################################
    # FE-TE (1) eliminate the time effects
    x_n = matrix(t(x),Tobs*(k-1),nobs) # T*(k-1) by n
    x_bn = t(matrix(rowMeans(x_n),(k-1),Tobs)) # T by (k-1) average over i
    x_bnm = t(matrix(t(x_bn),(k-1),Tobs*nobs)) # nT by (k-1) 
    x_dn = x - x_bnm # (nT by k-1) x_{it} - x_{ot}
    
    y_n = matrix(t(y),Tobs,nobs) # T by n
    y_bn = t(matrix(rowMeans(y_n),1,Tobs)) # T by 1
    y_bnm = t(matrix(t(y_bn),1,Tobs*nobs)) # T by n
    y_dn = y - y_bnm # nT by 1
    
    x2 = x_dn
    y2 = y_dn
    
    # FE-TE (2) calculate numerator and denominator of FE estimator
    xmx_n = matrix(sapply(id_list,PMD_i,m1=x2,m2=x2,Tobs=Tobs),(k-1)*(k-1),nobs) 
    xmx = matrix(rowMeans(xmx_n)/Tobs,(k-1),(k-1)) # (k-1 by k-1) average over nT
    xmy_n = matrix(sapply(id_list,PMD_i,m1=x2,m2=y2,Tobs=Tobs),k-1,nobs) # k=2: (1 by n)
    xmy = matrix(rowMeans(xmy_n)/Tobs,k-1,1) # (k-1 by 1) average over nT
    
    # FE-TE (3) calculate estimators and residuals
    fete_hatb = solve(xmx) %*% xmy # (k-1 by 1) eq. (S.2.1)
    re_fe = as.matrix(y2 - x2 %*% fete_hatb) # (nT by 1) 
    
    # FE-TE (4) calcualte ssymptotic variance 
    xmuumx_n = matrix(sapply(id_list,PMDV_i,mx=x2,mre=re_fe,Tobs=Tobs),(k-1)*(k-1),nobs)
    xmuumx = matrix(rowMeans(xmuumx_n)/Tobs,k-1,k-1) # (k-1 by k-1) average over nT
    fete_avarb = solve(xmx) %*% xmuumx %*% solve(xmx) / nobs / Tobs # Pesaran (2015) p. 654 
    ######################################################
    
    ### TMG-C estimation results when T>k
    ######################################################
    mtxy_n = sapply(id_list,MTxy_i,paneldata=paneldata,nobs=nobs,Tobs=Tobs,k=k)
    mtx_bn = matrix(rowMeans(mtxy_n[1:(Tobs*Tobs),]),Tobs,Tobs)
    mty_bn = matrix(rowMeans(mtxy_n[(Tobs*Tobs+1):(Tobs*(Tobs+1)),]),Tobs,1)
    phi_c = solve(mtx_bn) %*% mty_bn # eq. (6.18)
    
    mtuu_n = sapply(id_list,MTuu_i,paneldata=paneldata,nobs=nobs,Tobs=Tobs,k=k,phi_c=phi_c)
    mtuu_bn = matrix(rowMeans(mtuu_n),Tobs,Tobs)
    phic_av = nobs^(-1)*solve(mtx_bn) %*% mtuu_bn %*% t(solve(mtx_bn)) # eq. (6.19)
    
    phic_nT = matrix(matrix(phi_c,Tobs,nobs),Tobs*nobs,1)
    ydtc_nT = y - phic_nT # (nT by 1) vector of yit-phit_hat eq. (6.21)
    panel_dtc = cbind(ydtc_nT,w) 
    
    det_n = sapply(id_list,Det_i,paneldata_w=w,nobs=nobs,Tobs=Tobs,k=k) 
    det_bn = mean(det_n) # the sample mean of di=det(Wi'Wi)
    arate = 1/3
    an = det_bn*(nobs^(-arate)) # the threshold
    trim_n = (det_n<=an)
    np = mean(trim_n)
    
    delta_n = (det_n/an-1)*trim_n # (n by 1)
    delta_bn = mean(delta_n)
    
    thetac_n = sapply(id_list,TOLS_i,panel_int=panel_dtc,nobs=nobs,Tobs=Tobs,k=k,an=an) # (k by n)
    thetac_hat = (1+delta_bn)^(-1)*matrix(rowMeans(thetac_n),k,1) # eq. (6.21)
    
    ## TMG-C asymptotic variance of E(theta_i)
    thetac_bm = matrix(thetac_hat,k,nobs)
    thetac_av0 = (1+delta_bn)^(-2)*(nobs*(nobs-1))^(-1)*(thetac_n-thetac_bm) %*% t(thetac_n-thetac_bm) # (k by k) first component in eq. (6.22)
    qw_n = sapply(id_list,Qw_i,paneldata_w=w,nobs=nobs,Tobs=Tobs,k=k,an=an) # Tk by n 
    qw_bn = (1+delta_bn)^(-1)*matrix(rowMeans(qw_n),Tobs,k) # (T by k)
    q_nx =  matrix(qw_bn[,-1],Tobs,k-1) # (T by k-1)
    thetac_av1 = t(qw_bn) %*% phic_av %*% qw_bn # (k by k) second component in eq. (6.22)
    thetac_av = thetac_av0 + thetac_av1 # eq. (6.22)
    
    phi_av = diag(phic_av)
    
    tmgc_hatb = thetac_hat[2:k,1]
    tmgc_avb = thetac_av[2:k,2:k]
    ######################################################
    
    ### Calculate test statistics
    ######################################################
    dbeta = fete_hatb - tmgc_hatb # (k-1) by 1 vector
    psi_nx = matrix(rowMeans(xmx_n),(k-1),(k-1)) # (k-1 by k-1) average over n
    vd_n = sapply(id_list,Vdc_i,panel_int=panel_int,nobs=nobs,Tobs=Tobs,k=k,an=an,
                  x_bn=x_bn,y_bn=y_bn,psi_nx=psi_nx,q_nx=q_nx,mtx_bn=mtx_bn,delta_bn=delta_bn,qw_n=qw_n,fete_hatb=fete_hatb)
    vd_bn = matrix(rowMeans(matrix(vd_n,(k-1)*(k-1),nobs)),(k-1),(k-1)) # average over n eq. (S.2.15)
    hb =  nobs * t(dbeta) %*% solve(vd_bn) %*% dbeta # a scalar of test statistics
    
    result = 1-pchisq(hb, df=k-1, ncp = 0, lower.tail = TRUE, log.p = FALSE)
    output = c(hb,result,fete_hatb,fete_avarb,tmgc_hatb,tmgc_avb,np,phi_c,phi_av)
    names(output) = c("statistics",'p.value',"fete.hat","fete.avar","tmgc.hat","tmgc.avar","trim.percent",rep("te.hat",Tobs),rep("te.avar",Tobs))
  }
  output
}
################################################################################

### TMG, TMG-TE and TMG-C estimators
#################################################################################
TMG_est = function(paneldata,nobs,Tobs,k){
  id_list = as.matrix(seq(1,nobs,by=1))
  int_nT_long = matrix(1,nobs*Tobs,1)
  x = paneldata[,2:k] # nT by (k-1)
  w = cbind(int_nT_long,x) # (nT by k)
  y = matrix(paneldata[,1],nobs*Tobs,1) # (nT by 1)
  panel_int = cbind(y,w) # add intercepts
  
  ## TMG (1) calculate di=det(Wi'Wi) and the threshold an = mean(di)*(n^(-arate))
  det_n = sapply(id_list,Det_i,paneldata_w=w,nobs=nobs,Tobs=Tobs,k=k) 
  det_bn = mean(det_n) # the sample mean of di=det(Wi'Wi)
  arate = 1/3
  an = det_bn*(nobs^(-arate)) # the threshold
  
  ## TMG (2) calculate the trimming index
  trim_n = (det_n<=an)
  np = mean(trim_n)
  
  ## TMG (3) calculate trimmed individual estimates
  theta_trim_n = sapply(id_list,TOLS_i,panel_int=panel_int,nobs=nobs,Tobs=Tobs,k=k,an=an) # (k by n)
  tmgh_hat = matrix(rowMeans(theta_trim_n),k,1) # (k by 1) average over n
  
  ## TMG (4) calculate bias-corrected TMG estimator 
  delta_n = (det_n/an-1)*trim_n # (n by 1)
  delta_bn = mean(delta_n)
  tmg_hat = (1+delta_bn)^(-1)*tmgh_hat # (k by 1) 
  
  ## TMG (5) calculate asymptotic variance of TMG estimator 
  tmg_bm = matrix(tmg_hat, k ,nobs)
  tmg_av =(1+delta_bn)^(-2)*(nobs*(nobs-1))^(-1)*(theta_trim_n-tmg_bm) %*% t(theta_trim_n-tmg_bm) # (k by k)
  
  ## Report the covariance matrix of TMG estimator
  tmg_cov = tmg_av[1,2:k]
  if (k > 2) {
    for (j in 2:(k-1)) {
      tmg_cov = append(tmg_cov,tmg_av[j,(j+1):k])
    }
  }
  tmg_avar = matrix(,1,(k+k*(k-1)/2))
  tmg_avar[1,1:k] = diag(tmg_av)
  tmg_avar[1,(k+1):(k+k*(k-1)/2)] = tmg_cov
  
  # TMG: np,ests,avar
  output = c(t(tmg_hat),tmg_avar,np) # 1+k+(k+k*(k-1)/2))
  names(output) = c(rep("coefficients",k),rep("avar",k+k*(k-1)/2),"trim.percent")
  output
}

TMG_TE_est = function(paneldata,nobs,Tobs,k){
  if (Tobs<k) {
    output = "The TMG-C estimator is not applicable to panels with T<k, where the k-dimensional regressors do not include time effects."
  }
  if (Tobs>=k) {
    id_list = as.matrix(seq(1,nobs,by=1))
    int_nT_long = matrix(1,nobs*Tobs,1)
    panel_int = cbind(paneldata[,1],cbind(int_nT_long,paneldata[,2:k])) # add intercepts
    y = as.matrix(panel_int[,1]) # (nT by 1)
    w = as.matrix(panel_int [,2:(1+k)]) # (nT by k) regressors include intercepts
    x = as.matrix(panel_int[,3:(1+k)]) # (nT by k-1)
    
    ## calculate TMG estimator
    #################################################################
    ## TMG (1) calculate di=det(Wi'Wi) and the threshold an = mean(di)*(n^(-arate))
    det_n = sapply(id_list,Det_i,paneldata_w=w,nobs=nobs,Tobs=Tobs,k=k) 
    det_bn = mean(det_n) # the sample mean of di=det(Wi'Wi)
    arate = 1/3
    an = det_bn*(nobs^(-arate)) # the threshold
    
    ## TMG (2) calculate the trimming index
    trim_n = (det_n<=an)
    np = mean(trim_n)
    
    ## TMG (3) calculate trimmed individual estimates
    theta_trim_n = sapply(id_list,TOLS_i,panel_int=panel_int,nobs=nobs,Tobs=Tobs,k=k,an=an) # (k by n)
    tmgh_hat = matrix(rowMeans(theta_trim_n),k,1) # (k by 1) average over n
    
    ## TMG (4) calculate bias-corrected TMG estimator 
    delta_n = (det_n/an-1)*trim_n # (n by 1)
    delta_bn = mean(delta_n)
    tmg_hat = (1+delta_bn)^(-1)*tmgh_hat # (k by 1) eq. (4.5)
    #################################################################
    
    ## calculate TMG-TE estimator under tau'phi=0
    #################################################################
    w_n = matrix(t(w),k*Tobs,nobs) # (Tk by n)
    w_bn = t(matrix(rowMeans(w_n),k,Tobs)) # (T by k) average over n
    y_n = matrix(y,Tobs,nobs) # (T by n)
    y_bn = matrix(rowMeans(y_n),Tobs,1) # (T by 1) {y_it} average over n for each t
    
    taut = matrix(1,Tobs,1) 
    mt = diag(1,Tobs)-taut %*% solve(t(taut)%*%taut) %*% t(taut) # (T by T)
    
    qw_n = sapply(id_list,Qw_i,paneldata_w=w,nobs=nobs,Tobs=Tobs,k=k,an=an) # Tk by n eq. (6.3)
    qw_bn = (1+delta_bn)^(-1)*matrix(rowMeans(qw_n),Tobs,k) # (T by k) eq. (6.4)
    q_nx = matrix(qw_bn[,-1],Tobs,k-1) # eq. (S.2.5)
    
    ## TMG-TE (1) calculate estimator phi_hat and theta_hat
    phi_hat = solve(diag(1,Tobs)-mt%*%w_bn%*%t(qw_bn)) %*% mt %*% (y_bn-w_bn%*%tmg_hat) # eq. (6.11)
    theta_hat = tmg_hat - t(qw_bn)%*%phi_hat # eq. (6.9)
    
    ## TMG-TE (2) calculate asymptotic variance of theta_hat
    phie_nT = matrix(matrix(phi_hat,Tobs,nobs),Tobs*nobs,1)
    ydte_nT = y - phie_nT # (nT by 1) 
    panel_dte = cbind(ydte_nT,w)  
    theta_te_n = sapply(id_list,TOLS_i,panel_int=panel_dte,nobs=nobs,Tobs=Tobs,k=k,an=an) # (k by n)
    theta_bm = matrix(theta_hat,k,nobs)
    theta_av0 = (1+delta_bn)^(-2)*(nobs*(nobs-1))^(-1)*(theta_te_n-theta_bm) %*% t(theta_te_n-theta_bm) # (k by k) eq. (A.3.5)
    theta_av = solve(diag(1,k)-t(qw_bn)%*%mt%*%w_bn)%*%theta_av0%*%t(solve(diag(1,k)-t(qw_bn)%*%mt%*% w_bn)) # eq. (A.3.4)
    
    ## TMG-TE asymptotic variance of time effects phi
    tmgte_hat = as.matrix(c(phi_hat,theta_hat)) # (T+k) by 1: phi_hat, theta_hat 
    phiuu_n = sapply(id_list,Phiuu_i,paneldata=paneldata,nobs=nobs,Tobs=Tobs,k=k,est=tmgte_hat)
    phiuu_bn = matrix(rowMeans(phiuu_n),Tobs,Tobs)
    phi_av0 = nobs^(-1)*phiuu_bn
    phi_av = mt %*% ( w_bn %*% theta_av %*% t(w_bn) + phi_av0 ) %*% mt
    #################################################################
    
    ## Report the estimated asymptotic variance of TMG-TE
    #################################################################
    theta_cov = theta_av[1,2:k]
    if (k > 2) {
      for (j in 2:(k-1)) {
        theta_cov = append(theta_cov,theta_av[j,(j+1):k])
      }
    }
    theta_avar = matrix(,1,(k+k*(k-1)/2))
    theta_avar[1,1:k] = diag(theta_av)
    theta_avar[1,(k+1):(k+k*(k-1)/2)] = theta_cov
    
    phi_avar = diag(phi_av)
    #################################################################
    
    # report TMG-TE estimates
    #################################################################
    
    output = c(t(theta_hat),theta_avar,t(phi_hat),t(phi_avar),np) # 1+k+(k+k*(k-1)/2))+ T+(T+T*(T-1)/2)
    names(output) = c(rep("coefficients",k),rep("avar",k+k*(k-1)/2),rep("time.effects",Tobs),rep("time.effects.avar",Tobs),"trim.percent")
    #################################################################
  }
  output
}

TMG_C_est = function(paneldata,nobs,Tobs,k){
  if (Tobs<=k) {
    output = "The TMG-C estimator is not applicable to panels with T<=k, where the k-dimensional regressors do not include time effects."
  }
  if (Tobs > k) {
    id_list = as.matrix(seq(1,nobs,by=1))
    int_nT_long = matrix(1,nobs*Tobs,1)
    x = paneldata[,2:k] # nT by (k-1)
    w = cbind(int_nT_long,x) # (nT by k)
    y = matrix(paneldata[,1],nobs*Tobs,1) # (nT by 1)
    panel_int = cbind(y,w) # add intercepts
    
    ### TMG-C estimation results when T>k
    ######################################################
    mtxy_n = sapply(id_list,MTxy_i,paneldata=paneldata,nobs=nobs,Tobs=Tobs,k=k)
    mtx_bn = matrix(rowMeans(mtxy_n[1:(Tobs*Tobs),]),Tobs,Tobs)
    mty_bn = matrix(rowMeans(mtxy_n[(Tobs*Tobs+1):(Tobs*(Tobs+1)),]),Tobs,1)
    phi_c = solve(mtx_bn) %*% mty_bn # eq. (6.18)
    
    mtuu_n = sapply(id_list,MTuu_i,paneldata=paneldata,nobs=nobs,Tobs=Tobs,k=k,phi_c=phi_c)
    mtuu_bn = matrix(rowMeans(mtuu_n),Tobs,Tobs)
    phic_av = nobs^(-1)*solve(mtx_bn) %*% mtuu_bn %*% t(solve(mtx_bn)) # eq. (6.19)
    
    phic_nT = matrix(matrix(phi_c,Tobs,nobs),Tobs*nobs,1)
    ydtc_nT = y - phic_nT # (nT by 1) vector of yit-phit_hat eq. (6.21)
    panel_dtc = cbind(ydtc_nT,w) 
    
    det_n = sapply(id_list,Det_i,paneldata_w=w,nobs=nobs,Tobs=Tobs,k=k) 
    det_bn = mean(det_n) # the sample mean of di=det(Wi'Wi)
    arate = 1/3
    an = det_bn*(nobs^(-arate)) # the threshold
    trim_n = (det_n<=an)
    np = mean(trim_n)
    
    delta_n = (det_n/an-1)*trim_n # (n by 1)
    delta_bn = mean(delta_n)
    
    thetac_n = sapply(id_list,TOLS_i,panel_int=panel_dtc,nobs=nobs,Tobs=Tobs,k=k,an=an) # (k by n)
    thetac_hat = (1+delta_bn)^(-1)*matrix(rowMeans(thetac_n),k,1) # eq. (6.21)
    
    ## TMG-C asymptotic variance of E(theta_i)
    thetac_bm = matrix(thetac_hat,k,nobs)
    thetac_av0 = (1+delta_bn)^(-2)*(nobs*(nobs-1))^(-1)*(thetac_n-thetac_bm) %*% t(thetac_n-thetac_bm) # (k by k) first component in eq. (6.22)
    qw_n = sapply(id_list,Qw_i,paneldata_w=w,nobs=nobs,Tobs=Tobs,k=k,an=an) # Tk by n 
    qw_bn = (1+delta_bn)^(-1)*matrix(rowMeans(qw_n),Tobs,k) # (T by k)
    q_nx =  matrix(qw_bn[,-1],Tobs,k-1) # (T by k-1)
    thetac_av1 = t(qw_bn) %*% phic_av %*% qw_bn # (k by k) second component in eq. (6.22)
    thetac_av = thetac_av0 + thetac_av1 # eq. (6.22)
    #################################################################
    
    thetac_cov = thetac_av[1,2:k]
    if (k > 2) {
      for (j in 2:(k-1)) {
        thetac_cov = append(thetac_cov,thetac_av[j,(j+1):k])
      }
    }
    thetac_avar = matrix(,1,(k+k*(k-1)/2))
    thetac_avar[1,1:k] = diag(thetac_av)
    thetac_avar[1,(k+1):(k+k*(k-1)/2)] = thetac_cov
    
    phic_avar = diag(phic_av)
    #################################################################
    
    ## Report the estimated asymptotic variance of TMG-TE
    #################################################################
    thetac_cov = thetac_av[1,2:k]
    if (k > 2) {
      for (j in 2:(k-1)) {
        thetac_cov = append(thetac_cov,thetac_av[j,(j+1):k])
      }
    }
    thetac_avar = matrix(,1,(k+k*(k-1)/2))
    thetac_avar[1,1:k] = diag(thetac_av)
    thetac_avar[1,(k+1):(k+k*(k-1)/2)] = thetac_cov
    #################################################################
    
    output = c(t(thetac_hat),thetac_avar,t(phi_c),t(phic_avar),np) # 1+k+(k+k*(k-1)/2))+ T+(T+T*(T-1)/2)
    names(output) = c(rep("coefficients",k),rep("avar",k+k*(k-1)/2),rep("time.effects",Tobs),rep("time.effects.avar",Tobs),"trim.percent")
  }
  output
}
#################################################################################

### FE estimator (PMD_i, PMDV_i, FE_est, FE_TE_est)
################################################################################
FE_est = function(paneldata,nobs,Tobs,k) {
  nT = nobs*Tobs
  id_list = as.matrix(seq(1,nobs,by=1))
  int_nT_long = matrix(1,nobs*Tobs,1)
  x = as.matrix(paneldata[,2:k]) # nT by (k-1)
  w = cbind(int_nT_long,x) # (nT by k)
  y = matrix(paneldata[,1],nobs*Tobs,1) # (nT by 1)
  panel_int = cbind(y,w) # add intercepts
  
  # FE (1) calculate numerator and denominator of FE estimator
  xmx_n = matrix(sapply(id_list,PMD_i,m1=x,m2=x,Tobs=Tobs),(k-1)*(k-1),nobs) 
  xmx = matrix(rowMeans(xmx_n)/Tobs,(k-1),(k-1)) # (k-1 by k-1) average over nT
  xmy_n = matrix(sapply(id_list,PMD_i,m1=x,m2=y,Tobs=Tobs),k-1,nobs) # k=2: (1 by n)
  xmy = matrix(rowMeans(xmy_n)/Tobs,k-1,1) # (k-1 by 1) average over nT
  
  # FE (2) calculate estimators and residuals
  fe_hatb = solve(xmx) %*% xmy # (k-1 by 1) eq. (2.14)
  taut = matrix(1,Tobs,1) 
  mt = diag(1,Tobs)-taut %*% solve(t(taut)%*%taut) %*% t(taut) # (T by T)
  re_fe = as.matrix(y - x %*% fe_hatb) # (nT by 1) residuals
  
  # FE (3) calcualte asymptotic variance of FE estimators
  xmuumx_n = matrix(sapply(id_list,PMDV_i,mx=x,mre=re_fe,Tobs=Tobs),(k-1)*(k-1),nobs)
  xmuumx = matrix(rowMeans(xmuumx_n)/Tobs,k-1,k-1) # (k-1 by k-1) average over nT
  fe_avarb = solve(xmx) %*% xmuumx %*% solve(xmx) / nobs / Tobs # Pesaran (2015) p. 654 
  
  fe_hata =  mean(y - x %*% fe_hatb) 
  fe_hat = append(fe_hata,fe_hatb)
  
  x_br = matrix(colMeans(x),k-1,1) # (k-1 by 1) average over nT
  fe_avara = t(x_br) %*% fe_avarb %*% x_br
  fe_acovab = t(x_br) %*% fe_avarb # (1 by k-1)

  fe_avar = matrix(,1,(k+k*(k-1)/2))
  fe_avar[1,1:k] = append(fe_avara,diag(fe_avarb))
  acov_temp = fe_acovab
  if (k > 2) {
    for (j in 1:(k-2)) {
      acov_temp = append(acov_temp,fe_avarb[j,(j+1):(k-1)])
    }
  }
  fe_avar[1,(k+1):(k+k*(k-1)/2)] = acov_temp
  
  fe_output = c(fe_hat,fe_avar)
  names(fe_output) = c(rep("coefficients",k),rep("avar",k+k*(k-1)/2))
  fe_output
}

PMUV_i = function(mx,refe,Tobs,id) {
  Ti = Tobs
  xi = as.matrix(mx[(1+(id-1)*Ti):(id*Ti),]) # (T by k )
  rei = as.matrix(refe[(1+(id-1)*Ti):(id*Ti),]) # (T by 1) residuals
  ki = dim(xi)[2]
  Mti = diag(Ti)-matrix(1, nrow=Ti, ncol=1) %*% t(matrix(1, nrow=Ti, ncol=1))/Ti # (T by T)
  muum_i = matrix(Mti %*% rei %*% t(rei) %*% Mti,Ti*Ti,1) # (T*T)  by 1
  muum_i
}

FE_TE_est = function(paneldata,nobs,Tobs,k) {
  nT = nobs*Tobs
  id_list = as.matrix(seq(1,nobs,by=1))
  int_nT_long = matrix(1,nobs*Tobs,1)
  x = as.matrix(paneldata[,2:k]) # nT by (k-1)
  w = cbind(int_nT_long,x) # (nT by k)
  y = matrix(paneldata[,1],nobs*Tobs,1) # (nT by 1)
  panel_int = cbind(y,w) # add intercepts
  
  # FE-TE (1) eliminate the time effects
  x_n = matrix(t(x),Tobs*(k-1),nobs) # T*(k-1) by n
  x_bn = t(matrix(rowMeans(x_n),(k-1),Tobs)) # T by (k-1)
  x_bnm = t(matrix(t(x_bn),(k-1),Tobs*nobs)) # nT by (k-1)
  x_dn = x - x_bnm # (nT by k-1) x_{it} - x_{ot}
  
  y_n = matrix(t(y),Tobs,nobs) # T*(k-1) by n
  y_bn = t(matrix(rowMeans(y_n),1,Tobs)) # T by (k-1)
  y_bnm = t(matrix(t(y_bn),1,Tobs*nobs)) # T*(k-1) by n
  y_dn = y - y_bnm # nT by 1
  
  x = x_dn
  y = y_dn
  
  # FE-TE (2) calculate numerator and denominator of FE estimator
  xmx_n = matrix(sapply(id_list,PMD_i,m1=x,m2=x,Tobs=Tobs),(k-1)*(k-1),nobs) 
  xmx = matrix(rowMeans(xmx_n)/Tobs,(k-1),(k-1)) # (k-1 by k-1) average over nT
  xmy_n = matrix(sapply(id_list,PMD_i,m1=x,m2=y,Tobs=Tobs),k-1,nobs) # k=2: (1 by n)
  xmy = matrix(rowMeans(xmy_n)/Tobs,k-1,1) # (k-1 by 1) average over nT
  
  # FE-TE (3) calculate estimators and residuals
  fete_hatb = solve(xmx) %*% xmy # (k-1 by 1)
  re_fe = as.matrix(y - x %*% fete_hatb) # (nT by 1) 
  
  # FE-TE (4) calculate asymptotic variance 
  xmuumx_n = matrix(sapply(id_list,PMDV_i,mx=x,mre=re_fe,Tobs=Tobs),(k-1)*(k-1),nobs)
  xmuumx = matrix(rowMeans(xmuumx_n)/Tobs,k-1,k-1) # (k-1 by k-1) average over nT
  fete_avarb = solve(xmx) %*% xmuumx %*% solve(xmx) / nobs / Tobs # Pesaran (2015) p. 654 
  
  # FE-TE estimator of time effects
  taut = matrix(1,Tobs,1) 
  mt = diag(1,Tobs)-taut %*% solve(t(taut)%*%taut) %*% t(taut) # (T by T)
  phi_fe = mt %*% (y_bn - x_bn %*% fete_hatb)
  muum_n = matrix(sapply(id_list,PMUV_i,mx=x,refe=re_fe,Tobs=Tobs),Tobs*Tobs,nobs)
  muum = matrix(rowMeans(muum_n),Tobs,Tobs) / nobs # (T by T) average over n
  phife_avar = diag(muum)
  
  fete_hata = mean(y_bn - x_bn %*% fete_hatb - phi_fe)
  fete_avara = (Tobs^(-1) * t(taut) %*% x_bn) %*% fete_avarb %*% t(Tobs^(-1) * t(taut) %*% x_bn) 
  fete_acovab = (Tobs^(-1) * t(taut) %*% x_bn) %*% fete_avarb # (1 by k-1)
  
  # FE report results
  fete_avar = matrix(,1,(k+k*(k-1)/2))
  fete_avar[1,1:k] = append(fete_avara,diag(fete_avarb))
  acov_temp = fete_acovab
  if (k > 2) {
    for (j in 1:(k-2)) {
      acov_temp = append(acov_temp,fete_avarb[j,(j+1):(k-1)])
    }
  }
  fete_avar[1,(k+1):(k+k*(k-1)/2)] = acov_temp
  
  fete_hat = append(fete_hata,fete_hatb)

  fete_output = c(fete_hat,fete_avar,t(phi_fe),t(phife_avar))
  names(fete_output) = c(rep("coefficients",k),rep("avar",k+k*(k-1)/2),rep("time.effects",Tobs),rep("time.effects.avar",Tobs))
  fete_output
}
################################################################################

######  GP estimator 
#### (Minor, Cofactor, Adjoint1, Dw_i, Det_i, GPedn_i, GPuu_i, GP_est)
################################################################################
# T=k calcualte the determinant of regressors 
Dw_i = function(paneldata_w,nobs,Tobs,k,id) {
  wi = matrix(paneldata_w[(1+(id-1)*Tobs):(id*Tobs),],Tobs,k)  # (T by k) with T=K
  dwi = det(wi) 
  dwi
}

# GP: calculate denomiator and numerator for estimators of both time effects and hetero coeff 
GPedn_i = function(panel_int,trim_n,nobs,Tobs,k,hn,te,id){
  obsi = as.matrix(panel_int[(1+(id-1)*Tobs):(id*Tobs),]) # paneldata = {(yi,xi)} (nT by k+1) matrix
  yi = as.matrix(obsi[,1]) # yi (T by 1)
  wi = as.matrix(obsi[,2:(k+1)]) # wi (T by k) 
  trimi = trim_n[id] # index of trimming: 1 trim
  
  # no time effects
  if (te==0 ){
    dwinv_i = matrix(0,Tobs,k) # (T by k)
    if (trimi==0) {
      dwinv_i = wi %*% solve( t(wi) %*% wi )
    }
    qi = (1-trimi)*dwinv_i # (T by k)
    ri = (1-trimi)*wi# (T by k)
    qri = t(qi) %*% ri # k by k
    qyi = t(qi) %*% yi # k by 1
  }
  
  # with time effects
  if (te>0) {
    # ts=1 (intercepts) or ts=k (all coefficients)
    if (te == 1) {
      v0 = matrix(0,1,(Tobs-1)) # 1 by (T-1)
      z0 = diag(1,(Tobs-1)) # (T-1) by (T-1)
      zi = rbind(v0,z0) # a common intercept shift (T by T-1)
    } else {
      zi = matrix(0,Tobs,((Tobs-1)*k)) # time shifters (T by (T-1)k)
      for (idx in 2:Tobs) {
        zi[idx, (1+k*(idx-2)):(k+k*(idx-2))] = wi[idx,]
      }
    }
    
    # irregular estimator of time effects with T=k
    if (Tobs==k) {
      wzi = Adjoint1(wi) %*% zi
      winv_i = matrix(0,Tobs,k) 
      if (trimi==0) {
        winv_i = 1/det(wi)*diag(1,k)
      }
      qi = cbind(trimi/hn*wzi,(1-trimi)*winv_i) # (T by (Tobs-1)k+k)
      ri = cbind(wzi,(1-trimi)*det(wi)*diag(1,k)) # (T by (Tobs-1)k+k)
      qri = t(qi) %*% ri # (Tobs-1)k+k by (Tobs-1)*k+k
      qyi = t(qi) %*% Adjoint1(wi) %*% yi # (Tobs-1)*k+k by 1
    }
    
    # regular estimator of time effects with T=k
    if (Tobs>k) {
      mwi = diag(1,Tobs)- wi %*% solve(t(wi) %*% wi) %*% t(wi) # T by T
      mwzi = mwi %*% zi # T by (T-1)k
      wwinv_i = matrix(0,k,k) 
      if (trimi==0) {
        wwinv_i = solve(t(wi) %*% wi)
      }
      qi = cbind(mwzi,(1-trimi)*wi %*% wwinv_i)
      ri = cbind(zi,(1-trimi)*wi)
      qri = t(qi) %*% ri
      qyi = t(qi) %*% yi # (Tobs-1)*k+k by 1
    }
  }
  cbind(qri,qyi) # k by (k+1)
}

# GP: calculate asymptotic variance for each i
GPuu_i = function(panel_int,trim_n,nobs,Tobs,k,hn,te,gp_hat,id){
  obsi = as.matrix(panel_int[(1+(id-1)*Tobs):(id*Tobs),]) # paneldata = {(yi,xi)} (nT by k+1) matrix
  yi = as.matrix(obsi[,1]) # yi (T by 1)
  wi = as.matrix(obsi[,2:(k+1)]) # wi (T by k) 
  trimi = trim_n[id] # index of trimming: 1=trim
  
  # no time effects
  ###########################
  if (te==0) {
    dwinv_i = matrix(0,Tobs,k) # (T by k)
    if (trimi==0) {
      dwinv_i = wi %*% solve( t(wi) %*% wi )
    }
    qi = (1-trimi)*dwinv_i # (T by k)
    ri = (1-trimi)*wi# (T by k)
    qri = t(qi) %*% ri # k by k
    qyi = t(qi) %*%  yi # k by 1
    uhat_i =  yi - ri %*% gp_hat
  }
  ###########################
  
  # with time effects
  if (te>0) {
    # construct Zi matrix: ts=1 (intercepts) or ts=k (all coefficients)
    ###########################
    if (te == 1) {
      v0 = matrix(0,1,(Tobs-1))
      z0 = diag(1,(Tobs-1))
      zi = rbind(v0,z0) # a common intercept shift (T by T-1)
    } else {
      zi = matrix(0,Tobs,((Tobs-1)*k)) # time shifters (T by (T-1)k)
      for (idx in 2:Tobs) {
        zi[idx, (1+k*(idx-2)):(k+k*(idx-2))] = wi[idx,]
      }
    }
    ###########################
    # irregular estimator by GP (2012)
    ###########################
    if (Tobs==k) {
      wzi = Adjoint1(wi) %*% zi
      winv_i = matrix(0,Tobs,k) 
      if (trimi==0) {
        winv_i = 1/det(wi)*diag(1,Tobs,k)
      }
      qi = cbind(trimi/hn*wzi,(1-trimi)*winv_i) # (T by (Tobs-1)k+k)
      ri = cbind(wzi,(1-trimi)*det(wi)*diag(1,Tobs,k)) # (T by (Tobs-1)k+k)
      uhat_i = Adjoint1(wi) %*% yi - ri %*% gp_hat
    } 
    ###########################
    # regular estimator by Chamberlain (1992)
    ###########################
    if (Tobs>k) {
      mwi = diag(1,Tobs)- wi %*% solve(t(wi) %*% wi) %*% t(wi)
      mwzi = mwi %*% zi # T by (T-1)k
      wwinv_i = matrix(0,k,k) 
      if (trimi==0) {
        wwinv_i = solve(t(wi) %*% wi)
      }
      qi = cbind(mwzi,(1-trimi)*wi%*% wwinv_i)
      ri = cbind(zi,(1-trimi)*wi)
      uhat_i = yi - ri %*% gp_hat
    }
    ###########################
  }
  uui = (t(qi) %*% uhat_i) %*% t((t(qi) %*% uhat_i)) # (Tobs-1)k+k by (Tobs-1)k+k
  uui 
}

GP_est = function(paneldata,nobs,Tobs,k,te){
  id_list = as.matrix(seq(1,nobs,by=1))
  int_nT_long = matrix(1,nobs*Tobs,1)
  paneldata_w = cbind(int_nT_long,paneldata[,2:k])
  panel_int = cbind(paneldata[,1],paneldata_w) # add intercepts
  dimte = 0*(te==0)+(Tobs-1)*(te==1)+(Tobs-1)*k*(te==((Tobs-1)*k))
  
  # GP (1) calculate di = det(Wi'Wi)
  det_n = sapply(id_list,Det_i,paneldata_w=paneldata_w,nobs=nobs,Tobs=Tobs,k=k) 
  
  ## GP (2) calculate the threshold and indexes of trimming
  if (Tobs==k) {
    dw_n = sapply(id_list,Dw_i,paneldata_w=paneldata_w,nobs=nobs,Tobs=Tobs,k=k) 
    sd_hat = sd(dw_n); qn_hat = IQR(dw_n)
    c = 1/2*min(sd_hat,qn_hat/1.34)
  } else {
    c = sqrt(mean(det_n))
  }
  hn = c*(nobs^(-1/3))
  hn2 = hn^2
  trim_n = (det_n<=hn2)
  
  ## GP (3) calculate the numertor and denominator of GP estimators 
  gpedn_n = sapply(id_list,GPedn_i,panel_int=panel_int,trim_n=trim_n,nobs=nobs,Tobs=Tobs,k=k,hn=hn,te=te)
  # denominator: mean(Qi'Ri) lower-triangular matrix
  gped = matrix(rowMeans(gpedn_n[1:((dimte+k)^2),]),(dimte+k),(dimte+k)) # denominator
  # numerator: mean(Qi'yi)
  gpen = matrix(rowMeans(gpedn_n[(((dimte+k)^2)+1):(((dimte+k)^2)+(dimte+k)),]),(dimte+k),1) # numerator
  gp_hat = solve(gped) %*% gpen # (T-1+k)
  
  ## GP (4) calculate the asymptotic variance of the GP estimators 
  uu_n = sapply(id_list,GPuu_i,panel_int=panel_int,trim_n=trim_n,nobs=nobs,Tobs=Tobs,k=k,hn=hn,te=te,gp_hat=gp_hat)
  uu_hat = matrix(rowMeans(uu_n), (dimte+k),(dimte+k))
  avar_hat = 1/nobs*solve(gped) %*% uu_hat %*% t(solve(gped)) # (T-1+k) by (T-1+k) 
  
  ## report GP estimates after transformation between different normalizations of time effects
  if (te==0) {
    theta_hat = gp_hat
    theta_av = avar_hat
  }
  if (te==1) {
    vte1 = -1/Tobs+rbind(matrix(0,1,Tobs-1),diag(1,Tobs-1)) # T by (T-1) phi* to phi
    vte2 = matrix(0,Tobs,k) # (T by k) alpha* to phi (zeros)
    vte = cbind(vte1,vte2) # T by (T-1+k) matrix 
    va = matrix(c(rep(1/Tobs,Tobs-1),1,rep(0,k-1)),1,(Tobs-1+k)) # 1 by (T-1+k) vector
    vb = cbind(matrix(0,k-1,Tobs),diag(1,k-1)) # (k-1) by (T-1+k) matrix
    trm = rbind(vte,va,vb) # (T-1+k) by (T-1+k) matrix
    
    gp_hat2 = trm %*% gp_hat
    avar_hat2 = trm %*% avar_hat %*% t(trm)
    
    phi_hat = gp_hat2[1:Tobs]
    phi_av = avar_hat2[1:Tobs,1:Tobs]
    theta_hat = gp_hat2[(Tobs+1):(Tobs+k)]
    theta_av = avar_hat2[(Tobs+1):(Tobs+k),(Tobs+1):(Tobs+k)]
    phi_avar = diag(phi_av)
  }
  if (te>1) {
    idte = seq(1,Tobs-1,by=k)
    idw = c(((Tobs-1)*k+1):((Tobs-1)*k+k))
    id = c(idte,idw)
    gp_hat1 = as.matrix(gp_hat[id]) # phi*, E(theta_i)
    
    idm = expand.grid(id,id)
    avar_hat1 = matrix(,length(gp_hat1),length(gp_hat1))
    idx = seq(1,length(gp_hat1),by=1)
    idm1 = expand.grid(idx,idx)
    for (s in 1:dim(idm)[1]) {
      i = idm[s,2]; j = idm[s,1];
      temp = avar_hat[i,j]
      i1 = idm1[s,2]; j1 = idm1[s,1];
      avar_hat1[i1,j1] = temp; rm(temp)
    }
    
    vte1 = -1/Tobs+rbind(matrix(0,1,Tobs-1),diag(1,Tobs-1)) # T by (T-1) phi* to phi
    vte2 = matrix(0,Tobs,k) # (T by k) alpha* to phi (zeros)
    vte = cbind(vte1,vte2) # T by (T-1+k) matrix 
    va = matrix(c(rep(1/Tobs,Tobs-1),1,rep(0,k-1)),1,(Tobs-1+k)) # 1 by (T-1+k) vector
    vb = cbind(matrix(0,k-1,Tobs),diag(1,k-1)) # (k-1) by (T-1+k) matrix
    trm = rbind(vte,va,vb) # (T-1+k) by (T-1+k) matrix
    
    gp_hat2 = trm %*% gp_hat1
    avar_hat2 = trm %*% avar_hat1 %*% t(trm)
    
    phi_hat = gp_hat2
    phi_av = avar_hat
    theta_hat = gp_hat2[(Tobs+1):(Tobs+k)]
    theta_av = avar_hat2[(Tobs+1):(Tobs+k),(Tobs+1):(Tobs+k)]
    phi_avar = diag(phi_av)
  }
  
  theta_cov = theta_av[1,2:k]
  if (k > 2) {
    for (j in 2:(k-1)) {
      theta_cov = append(theta_cov,theta_av[j,(j+1):k])
    }
  }
  theta_avar = matrix(,1,(k+k*(k-1)/2))
  theta_avar[1,1:k] = diag(theta_av)
  theta_avar[1,(k+1):(k+k*(k-1)/2)] = theta_cov
  
  np = mean(trim_n) # trimmed portion
  
  if (te==0) {
    gp_output = c(theta_hat,theta_avar,np)
    names(gp_output) = c(rep("coefficients",k),rep("avar",k+k*(k-1)/2),"trim.percent")
  }
  if (te>0) {
    gp_output = c(theta_hat,theta_avar,phi_hat,phi_avar,np)
    names(gp_output) = c(rep("coefficients",k),rep("avar",k+k*(k-1)/2),rep("time.effects",Tobs),rep("time.effects.avar",Tobs),"trim.percent")
  }
  gp_output
}
################################################################################

######  SU (SUN_est_l, SU_est_l, SU_est) 
################################################################################
SU_est = function(paneldata,nobs,Tobs,k){
  t=0 # time effects only in intercepts
  p = k
  N = nobs
  T = Tobs
  L=1
  
  R = matrix(c(0,0,0,0),2,2)      # For t = 1 for Monte Carlo
  if( t == 2 ){
    R = diag(p)
  }
  paneldata_x = matrix(paneldata[,2],2,nobs)
  paneldata_y = matrix(paneldata[,1],2,nobs) 
  
  X1 = matrix(paneldata_x[1,],nobs,1)
  X2 = matrix(paneldata_x[2,],nobs,1)
  Y1 = matrix(paneldata_y[1,],nobs,1)
  Y2 = matrix(paneldata_y[2,],nobs,1)
  
  ################################################################
  # ADJOINT MATRIX FUNCTION
  ################################################################
  adjoint <- function(A){
    adjA = matrix(0,dim(A)[2],dim(A)[1])
    for( i in 1:(dim(A)[1]) ){
      for( j in 1:(dim(A)[2]) ){
        adjA[j,i] = (-1)^(i+j) * det(as.matrix(A[-i,-j]))
      }
    }
    return( adjA )
  }
  
  ################################################################
  # D, BOLD-FACE X, BOLD-FACE X*, BOLD-FACE X^{-1}, & BOLD-FACE W
  ################################################################
  i = 1
  D = det(rbind(cbind(1,X1[i,1]),cbind(1,X2[i,1])))
  bfX = list(rbind(cbind(1,X1[i,1]),cbind(1,X2[i,1])))
  bfXstr = list(adjoint(rbind(cbind(1,X1[i,1]),cbind(1,X2[i,1]))))
  bfXinv = list(ginv(rbind(cbind(1,X1[i,1]),cbind(1,X2[i,1]))))
  #bfW = list(rbind(0,cbind(1,X2[i,1])))
  bfW = list(rbind(0,cbind(0,0)))
  bfY = list(rbind(Y1[i,1],Y2[i,1]))
  for( i in 2:N ){
    D = c(D,det(rbind(cbind(1,X1[i,1]),cbind(1,X2[i,1]))))
    bfX[length(bfX)+1] = list(rbind(cbind(1,X1[i,1]),cbind(1,X2[i,1])))
    bfXstr[length(bfXstr)+1] = list(adjoint(rbind(cbind(1,X1[i,1]),cbind(1,X2[i,1]))))
    bfXinv[length(bfXinv)+1] = list(ginv(rbind(cbind(1,X1[i,1]),cbind(1,X2[i,1]))))
    bfW[length(bfW)+1] = list(rbind(0,cbind(0,0))) #list(rbind(0,cbind(1,X2[i,1])))
    bfY[length(bfY)+1] = list(rbind(Y1[i,1],Y2[i,1]))
  }
  
  ################################################################
  # h AND b (GRAHAM & POWELL, 2012, PAGE 2138)
  ################################################################
  h = min(c(sd(D), (quantile(D,0.75)-quantile(D,0.25))/1.34 )) / N^(1/(2*L+1)) / 2
  
  ################################################################
  # h_hat, e1, D0L, D1L
  ################################################################
  i = 1
  h_hat = (abs(D[i])<=h)*matrix(D[i]^(0:(L-1)),L,1) / N
  e1 = matrix(c(1, array(0,L)),L+1,1)
  D0L = list((abs(D[i])<=h)*matrix(D[i]^(0:L),L+1,1))
  D1L = list((abs(D[i])<=h)*matrix(D[i]^(1:L),L,1))
  for(i in 2:N){
    h_hat = h_hat + (abs(D[i])<=h)*matrix(D[i]^(0:(L-1)),L,1) / N
    D0L[length(D0L)+1] = list((abs(D[i])<=h)*matrix(D[i]^(0:L),L+1,1))
    D1L[length(D1L)+1] = list((abs(D[i])<=h)*matrix(D[i]^(1:L),L,1))
  }
  
  ################################################################
  # ESTIMATE DELTA
  ################################################################
  END0LD0L = 0                                     # E_N[D0L D0L']
  for( i in 1:N ){
    D0Li = matrix(unlist(D0L[i]),L+1,1)
    END0LD0L = END0LD0L + D0Li%*%t(D0Li) / N
  }
  
  denominator = 0
  numerator = 0
  for( i in 1:N ){
    D0Li = matrix(unlist(D0L[i]),L+1,1)
    XstrWi = matrix(unlist(bfXstr[i]),T,p)%*%matrix(unlist(bfW[i]),T,(T-1)*p)
    XstrYi = matrix(unlist(bfXstr[i]),T,p)%*%matrix(unlist(bfY[i]),T,1)
    denominator = denominator + as.numeric(t(D0Li)%*%ginv(END0LD0L)%*%e1) * t(XstrWi) %*% XstrWi / N
    numerator   = numerator   + as.numeric(t(D0Li)%*%ginv(END0LD0L)%*%e1) * t(XstrWi) %*% XstrYi / N
  }
  delta_hat = ginv(denominator)%*%numerator
  
  ################################################################
  # ESTIMATE GAMMA
  ################################################################
  END1LD1L = 0                                     # E_N[D1L D1L']
  for( i in 1:N ){
    D1Li = matrix(unlist(D1L[i]),L,1)
    END1LD1L = END1LD1L + D1Li%*%t(D1Li) / N
  }
  
  gamma_hat = 0
  for( i in 1:N ){
    D1Li = matrix(unlist(D1L[i]),L,1)
    XstrWi = matrix(unlist(bfXstr[i]),T,p)%*%matrix(unlist(bfW[i]),T,(T-1)*p)
    XstrYi = matrix(unlist(bfXstr[i]),T,p)%*%matrix(unlist(bfY[i]),T,1)
    gamma_hat = gamma_hat + (XstrYi - XstrWi %*% delta_hat) %*% t(D1Li) / N
  }
  gamma_hat = gamma_hat %*% ginv(END1LD1L)
  
  ################################################################
  # ESTIMATE BETA_L
  ################################################################
  beta_M_hat_numerator = 0
  for( i in 1:N ){
    XstrWi = matrix(unlist(bfXstr[i]),T,p)%*%matrix(unlist(bfW[i]),T,(T-1)*p)
    XstrYi = matrix(unlist(bfXstr[i]),T,p)%*%matrix(unlist(bfY[i]),T,1)
    if( abs(D[i])>h ){
      beta_M_hat_numerator = beta_M_hat_numerator + (abs(D[i])>h)*(1/D[i])*(XstrYi - XstrWi %*% delta_hat) / N
    }
  }
  beta_M_hat_denominator = mean((abs(D)>h))
  
  beta_M_hat = beta_M_hat_numerator * beta_M_hat_denominator^(-1)
  beta_L_hat = beta_M_hat_numerator + gamma_hat %*% h_hat
  
  ################################################################
  # ESTIMATE THETA
  ################################################################
  theta_L_hat = beta_L_hat + R%*%delta_hat
  theta_M_hat = beta_M_hat + R%*%delta_hat
  
  ################################################################
  # COMPUTE V_hat
  ################################################################
  V_hat = 0
  for( i in 1:N ){
    D0Li = matrix(unlist(D0L[i]),L+1,1)
    XstrWi = matrix(unlist(bfXstr[i]),T,p)%*%matrix(unlist(bfW[i]),T,(T-1)*p)
    V_hat = V_hat + as.numeric(t(D0Li)%*%ginv(END0LD0L)%*%e1) * t(XstrWi)%*%XstrWi / N
  }
  
  ################################################################
  # COMPUTE Q_hat
  ################################################################
  Q_hat = 0
  for( i in 1:N ){
    D1Li = matrix(unlist(D1L[i]),L,1)
    XstrWi = matrix(unlist(bfXstr[i]),T,p)%*%matrix(unlist(bfW[i]),T,(T-1)*p)
    if( abs(D[i])>h ){
      Q_hat = Q_hat + as.numeric( (abs(D[i])>h)/D[i] + t(D1Li)%*%ginv(END1LD1L)%*%h_hat ) * XstrWi / N
    }
  }
  
  ################################################################
  # COMPUTE zeta_hat (1ST TERM)
  ################################################################
  zeta_hat_1 = NULL
  for(i in 1:N){
    XstrWi = matrix(unlist(bfXstr[i]),T,p)%*%matrix(unlist(bfW[i]),T,(T-1)*p)
    XstrYi = matrix(unlist(bfXstr[i]),T,p)%*%matrix(unlist(bfY[i]),T,1)
    if( abs(D[i])>h ){
      zeta_hat_1 = cbind(zeta_hat_1, (abs(D[i])>h)/D[i] * (XstrYi - XstrWi%*%delta_hat))
    }else{
      zeta_hat_1 = cbind(zeta_hat_1, matrix(0,p,1) )
    }
  }
  zeta_hat_1 = zeta_hat_1 - matrix(rowMeans(zeta_hat_1),p,N)
  
  ################################################################
  # COMPUTE zeta_hat (2ND TERM)
  ################################################################
  zeta_hat_2 = NULL
  for(i in 1:N){
    D1Li = matrix(unlist(D1L[i]),L,1)
    XstrWi = matrix(unlist(bfXstr[i]),T,p)%*%matrix(unlist(bfW[i]),T,(T-1)*p)
    XstrYi = matrix(unlist(bfXstr[i]),T,p)%*%matrix(unlist(bfY[i]),T,1)
    zeta_hat_2 = cbind(zeta_hat_2, ((XstrYi-XstrWi%*%delta_hat) - gamma_hat%*%D1Li) %*% t(D1Li) %*% ginv(END1LD1L) %*% h_hat)
  }
  
  ################################################################
  # COMPUTE zeta_hat (3RD TERM)
  ################################################################
  zeta_hat_3R = NULL
  zeta_hat_3Q = NULL
  for(i in 1:N){
    D0Li = matrix(unlist(D0L[i]),L+1,1)
    XstrWi = matrix(unlist(bfXstr[i]),T,p)%*%matrix(unlist(bfW[i]),T,(T-1)*p)
    XstrYi = matrix(unlist(bfXstr[i]),T,p)%*%matrix(unlist(bfY[i]),T,1)
    zeta_hat_3R = cbind(zeta_hat_3R, as.numeric(t(D0Li)%*%ginv(END0LD0L)%*%e1) * R%*%ginv(V_hat)%*%t(XstrWi)%*%(XstrYi-XstrWi%*%delta_hat))
    zeta_hat_3Q = cbind(zeta_hat_3Q, as.numeric(t(D0Li)%*%ginv(END0LD0L)%*%e1) * Q_hat%*%ginv(V_hat)%*%t(XstrWi)%*%(XstrYi-XstrWi%*%delta_hat))
  }
  
  ################################################################
  # COMPUTE zeta_hat (ALL TOGETHER)
  ################################################################
  zeta_hat_M = zeta_hat_1 + zeta_hat_3R
  zeta_hat_L = zeta_hat_1 + zeta_hat_2 + zeta_hat_3R - zeta_hat_3Q
  rm(zeta_hat_1); rm(zeta_hat_2); rm(zeta_hat_3R); rm(zeta_hat_3Q); gc();
  
  ################################################################
  # VARIANCE AND SD
  ################################################################
  VAR_theta_M = zeta_hat_M %*% t(zeta_hat_M) / N
  VAR_theta_L = zeta_hat_L %*% t(zeta_hat_L) / N
  #rm(zeta_hat); 
  rm(zeta_hat_M); gc();
  SD_theta_M_hat = matrix(sqrt(diag(VAR_theta_M/N)),,1)
  SD_theta_L_hat = matrix(sqrt(diag(VAR_theta_L/N)),,1)
  
  
  ### report estimated unconditional cross-sectional means of coefficients without time effects
  ####### R = matrix(zeroes)
  sum_est = theta_M_hat # 2 by 1
  sum_av = VAR_theta_M / N # 2 by 2
  sum_cov = sum_av[1,2:k]
  if (k > 2) {
    for (j in 2:k) {
      sum_cov = append(sum_cov,sum_av[1,(2+j-1):k])
    }
  }
  sum_avar = matrix(,1,(k+k*(k-1)/2))
  sum_avar[1,1:k] = diag(sum_av)
  sum_avar[1,(k+1):(k+k*(k-1)/2)] = sum_cov
  
  np = mean(abs(D)<=h) # trimmed portion
  
  sum_an_output = as.matrix(cbind(np,t(sum_est),sum_avar))
  
  #######
  su_est = theta_L_hat # 2 by 1
  su_av = VAR_theta_L / N # 2 by 2
  su_cov = su_av[1,2:k]
  if (k > 2) {
    for (j in 2:(k-1)) {
      su_cov = append(su_cov,su_av[j,(j+1):k])
    }
  }
  su_avar = matrix(,1,(k+k*(k-1)/2))
  su_avar[1,1:k] = diag(su_av)
  su_avar[1,(k+1):(k+k*(k-1)/2)] = su_cov
  
  np = mean(abs(D)<=h) # trimmed portion
  
  output = c(t(su_est),su_avar,np)
  names(output) = c(rep("coefficients",k),rep("avar",k),"trim.percent")
  output
}

SU_TE_est = function(paneldata,nobs,Tobs,k,te){
  t = 1 # only time effects in intercepts
  p = k # dim(w_it)
  N = nobs
  L = 1 # order of local polynomial regression
  T = Tobs
  
  #R = matrix(c(0,0,0,0),2,2)      # For t = 1 for Monte Carlo
  R = matrix(c(1/Tobs,0),2,1)  # only time effects in intercepts
  
  # input a panel data set
  ###########################################
  paneldata_x = matrix(paneldata[,2],2,nobs)
  paneldata_y = matrix(paneldata[,1],2,nobs) 
  
  X1 = matrix(paneldata_x[1,],nobs,1)
  X2 = matrix(paneldata_x[2,],nobs,1)
  Y1 = matrix(paneldata_y[1,],nobs,1)
  Y2 = matrix(paneldata_y[2,],nobs,1)
  ###########################################
  
  ################################################################
  # ADJOINT MATRIX FUNCTION
  ################################################################
  adjoint <- function(A){
    adjA = matrix(0,dim(A)[2],dim(A)[1])
    for( i in 1:(dim(A)[1]) ){
      for( j in 1:(dim(A)[2]) ){
        adjA[j,i] = (-1)^(i+j) * det(as.matrix(A[-i,-j]))
      }
    }
    return( adjA )
  }
  
  ################################################################
  # D, BOLD-FACE X, BOLD-FACE X*, BOLD-FACE X^{-1}, & BOLD-FACE W
  ################################################################
  i = 1
  D = det(rbind(cbind(1,X1[i,1]),cbind(1,X2[i,1])))  # det(Wi)
  bfX = list(rbind(cbind(1,X1[i,1]),cbind(1,X2[i,1])))
  bfXstr = list(adjoint(rbind(cbind(1,X1[i,1]),cbind(1,X2[i,1]))))
  bfXinv = list(ginv(rbind(cbind(1,X1[i,1]),cbind(1,X2[i,1]))))
  bfW = list(rbind(0,cbind(1))) #list(rbind(0,cbind(1,X2[i,1])))
  bfY = list(rbind(Y1[i,1],Y2[i,1]))
  for( i in 2:N ){
    D = c(D,det(rbind(cbind(1,X1[i,1]),cbind(1,X2[i,1]))))
    bfX[length(bfX)+1] = list(rbind(cbind(1,X1[i,1]),cbind(1,X2[i,1])))
    bfXstr[length(bfXstr)+1] = list(adjoint(rbind(cbind(1,X1[i,1]),cbind(1,X2[i,1]))))
    bfXinv[length(bfXinv)+1] = list(ginv(rbind(cbind(1,X1[i,1]),cbind(1,X2[i,1]))))
    bfW[length(bfW)+1] = list(rbind(0,cbind(1))) #list(rbind(0,cbind(1,X2[i,1])))
    bfY[length(bfY)+1] = list(rbind(Y1[i,1],Y2[i,1]))
  }
  
  ################################################################
  # h AND b (GRAHAM & POWELL, 2012, PAGE 2138)
  ################################################################
  h = min(c(sd(D), (quantile(D,0.75)-quantile(D,0.25))/1.34 )) / N^(1/(2*L+1)) / 2
  
  ################################################################
  # h_hat, e1, D0L, D1L
  ################################################################
  i = 1
  h_hat = (abs(D[i])<=h)*matrix(D[i]^(0:(L-1)),L,1) / N
  e1 = matrix(c(1, array(0,L)),L+1,1)
  D0L = list((abs(D[i])<=h)*matrix(D[i]^(0:L),L+1,1))
  D1L = list((abs(D[i])<=h)*matrix(D[i]^(1:L),L,1))
  for(i in 2:N){
    h_hat = h_hat + (abs(D[i])<=h)*matrix(D[i]^(0:(L-1)),L,1) / N
    D0L[length(D0L)+1] = list((abs(D[i])<=h)*matrix(D[i]^(0:L),L+1,1))
    D1L[length(D1L)+1] = list((abs(D[i])<=h)*matrix(D[i]^(1:L),L,1))
  }
  
  ################################################################
  # ESTIMATE DELTA ## time effects
  ################################################################
  END0LD0L = 0                                     # E_N[D0L D0L']
  for( i in 1:N ){
    D0Li = matrix(unlist(D0L[i]),L+1,1)
    END0LD0L = END0LD0L + D0Li%*%t(D0Li) / N
  }
  
  denominator = 0
  numerator = 0
  for( i in 1:N ){
    D0Li = matrix(unlist(D0L[i]),L+1,1)
    XstrWi = matrix(unlist(bfXstr[i]),T,p)%*%matrix(unlist(bfW[i]),T,(T-1)*1) #matrix(unlist(bfXstr[i]),T,p)%*%matrix(unlist(bfW[i]),T,(T-1)*p)
    XstrYi = matrix(unlist(bfXstr[i]),T,p)%*%matrix(unlist(bfY[i]),T,1)
    denominator = denominator + as.numeric(t(D0Li)%*%ginv(END0LD0L)%*%e1) * t(XstrWi) %*% XstrWi / N
    numerator   = numerator   + as.numeric(t(D0Li)%*%ginv(END0LD0L)%*%e1) * t(XstrWi) %*% XstrYi / N
  }
  delta_hat = ginv(denominator)%*%numerator
  
  ################################################################
  # ESTIMATE GAMMA
  ################################################################
  END1LD1L = 0                                     # E_N[D1L D1L']
  for( i in 1:N ){
    D1Li = matrix(unlist(D1L[i]),L,1)
    END1LD1L = END1LD1L + D1Li%*%t(D1Li) / N
  }
  
  gamma_hat = 0
  for( i in 1:N ){
    D1Li = matrix(unlist(D1L[i]),L,1)
    XstrWi = matrix(unlist(bfXstr[i]),T,p)%*%matrix(unlist(bfW[i]),T,(T-1)*1) #matrix(unlist(bfXstr[i]),T,p)%*%matrix(unlist(bfW[i]),T,(T-1)*p)
    XstrYi = matrix(unlist(bfXstr[i]),T,p)%*%matrix(unlist(bfY[i]),T,1)
    gamma_hat = gamma_hat + (XstrYi - XstrWi %*% delta_hat) %*% t(D1Li) / N
  }
  gamma_hat = gamma_hat %*% ginv(END1LD1L)
  
  ################################################################
  # ESTIMATE BETA^M & BETA_L
  ################################################################
  beta_M_hat_numerator = 0
  for( i in 1:N ){
    XstrWi = matrix(unlist(bfXstr[i]),T,p)%*%matrix(unlist(bfW[i]),T,(T-1)*1) #matrix(unlist(bfXstr[i]),T,p)%*%matrix(unlist(bfW[i]),T,(T-1)*p)
    XstrYi = matrix(unlist(bfXstr[i]),T,p)%*%matrix(unlist(bfY[i]),T,1)
    if( abs(D[i])>h ){
      beta_M_hat_numerator = beta_M_hat_numerator + (abs(D[i])>h)*(1/D[i])*(XstrYi - XstrWi %*% delta_hat) / N
    }
  }
  beta_M_hat_denominator = mean((abs(D)>h))
  
  beta_M_hat = beta_M_hat_numerator * beta_M_hat_denominator^(-1)
  beta_L_hat = beta_M_hat_numerator + gamma_hat %*% h_hat
  
  ################################################################
  # ESTIMATE THETA
  ################################################################
  theta_L_hat = beta_L_hat + R%*%delta_hat
  theta_M_hat = beta_M_hat + R%*%delta_hat
  
  ################################################################
  # COMPUTE V_hat
  ################################################################
  V_hat = 0
  for( i in 1:N ){
    D0Li = matrix(unlist(D0L[i]),L+1,1)
    XstrWi = matrix(unlist(bfXstr[i]),T,p)%*%matrix(unlist(bfW[i]),T,(T-1)*1) #matrix(unlist(bfXstr[i]),T,p)%*%matrix(unlist(bfW[i]),T,(T-1)*p)
    V_hat = V_hat + as.numeric(t(D0Li)%*%ginv(END0LD0L)%*%e1) * t(XstrWi)%*%XstrWi / N
  }
  
  ################################################################
  # COMPUTE Q_hat
  ################################################################
  Q_hat = 0
  for( i in 1:N ){
    D1Li = matrix(unlist(D1L[i]),L,1)
    XstrWi = matrix(unlist(bfXstr[i]),T,p)%*%matrix(unlist(bfW[i]),T,(T-1)*1) #matrix(unlist(bfXstr[i]),T,p)%*%matrix(unlist(bfW[i]),T,(T-1)*p)
    if( abs(D[i])>h ){
      Q_hat = Q_hat + as.numeric( (abs(D[i])>h)/D[i] + t(D1Li)%*%ginv(END1LD1L)%*%h_hat ) * XstrWi / N
    }
  }
  
  ################################################################
  # COMPUTE zeta_hat (1ST TERM)
  ################################################################
  zeta_hat_1 = NULL
  for(i in 1:N){
    XstrWi = matrix(unlist(bfXstr[i]),T,p)%*%matrix(unlist(bfW[i]),T,(T-1)*1) #matrix(unlist(bfXstr[i]),T,p)%*%matrix(unlist(bfW[i]),T,(T-1)*p)
    XstrYi = matrix(unlist(bfXstr[i]),T,p)%*%matrix(unlist(bfY[i]),T,1)
    if( abs(D[i])>h ){
      zeta_hat_1 = cbind(zeta_hat_1, (abs(D[i])>h)/D[i] * (XstrYi - XstrWi%*%delta_hat))
    }else{
      zeta_hat_1 = cbind(zeta_hat_1, matrix(0,p,1) )
    }
  }
  zeta_hat_1 = zeta_hat_1 - matrix(rowMeans(zeta_hat_1),p,N)
  
  ################################################################
  # COMPUTE zeta_hat (2ND TERM)
  ################################################################
  zeta_hat_2 = NULL
  for(i in 1:N){
    D1Li = matrix(unlist(D1L[i]),L,1)
    XstrWi = matrix(unlist(bfXstr[i]),T,p)%*%matrix(unlist(bfW[i]),T,(T-1)*1) #matrix(unlist(bfXstr[i]),T,p)%*%matrix(unlist(bfW[i]),T,(T-1)*p)
    XstrYi = matrix(unlist(bfXstr[i]),T,p)%*%matrix(unlist(bfY[i]),T,1)
    zeta_hat_2 = cbind(zeta_hat_2, ((XstrYi-XstrWi%*%delta_hat) - gamma_hat%*%D1Li) %*% t(D1Li) %*% ginv(END1LD1L) %*% h_hat)
  }
  
  ################################################################
  # COMPUTE zeta_hat (3RD TERM)
  ################################################################
  zeta_hat_3R = NULL
  zeta_hat_3Q = NULL
  for(i in 1:N){
    D0Li = matrix(unlist(D0L[i]),L+1,1)
    XstrWi = matrix(unlist(bfXstr[i]),T,p)%*%matrix(unlist(bfW[i]),T,(T-1)*1) #matrix(unlist(bfXstr[i]),T,p)%*%matrix(unlist(bfW[i]),T,(T-1)*p)
    XstrYi = matrix(unlist(bfXstr[i]),T,p)%*%matrix(unlist(bfY[i]),T,1)
    zeta_hat_3R = cbind(zeta_hat_3R, as.numeric(t(D0Li)%*%ginv(END0LD0L)%*%e1) * R%*%ginv(V_hat)%*%t(XstrWi)%*%(XstrYi-XstrWi%*%delta_hat))
    zeta_hat_3Q = cbind(zeta_hat_3Q, as.numeric(t(D0Li)%*%ginv(END0LD0L)%*%e1) * Q_hat%*%ginv(V_hat)%*%t(XstrWi)%*%(XstrYi-XstrWi%*%delta_hat))
  }
  
  ################################################################
  # COMPUTE zeta_hat (ALL TOGETHER)
  ################################################################
  zeta_hat_M = zeta_hat_1 + zeta_hat_3R
  zeta_hat_L = zeta_hat_1 + zeta_hat_2 + zeta_hat_3R - zeta_hat_3Q
  rm(zeta_hat_1); rm(zeta_hat_2); rm(zeta_hat_3R); rm(zeta_hat_3Q); #gc();
  
  ################################################################
  # VARIANCE AND SD
  ################################################################
  VAR_theta_M = zeta_hat_M %*% t(zeta_hat_M) / N
  VAR_theta_L = zeta_hat_L %*% t(zeta_hat_L) / N
  rm(zeta_hat_M); #gc(); #rm(zeta_hat);
  SD_theta_M_hat = matrix(sqrt(diag(VAR_theta_M/N)),,1)
  SD_theta_L_hat = matrix(sqrt(diag(VAR_theta_L/N)),,1)
  
  ################################################################
  ## report SU (2021) estimation results
  ################################################################
  su_est = theta_L_hat # 2 by 1
  su_av = VAR_theta_L / N # 2 by 2
  su_cov = su_av[1,2:k]
  if (k > 2) {
    for (j in 2:(k-1)) {
      su_cov = append(su_cov,su_av[j,(j+1):k])
    }
  }
  su_avar = matrix(,1,(k+k*(k-1)/2))
  su_avar[1,1:k] = diag(su_av)
  su_avar[1,(k+1):(k+k*(k-1)/2)] = su_cov
  
  np = mean(abs(D)<=h) # trimmed portion
  
  vte1 = -1/Tobs+rbind(matrix(0,1,Tobs-1),diag(1,Tobs-1)) # T by (T-1) phi* to phi
  phi_hat = vte1 %*% delta_hat
  
  output = c(t(su_est),su_avar,t(phi_hat),np)
  names(output) = c(rep("coefficients",k),rep("avar",k),rep("time.effects",Tobs),"trim.percent")
  output
}
################################################################################


#### Test and estimation
################################################################################
# Hausman-type statistics (2001-2002)
test.0102 = CorrHetero_test(panel.0102,nobs=nobs,Tobs=2,k=2) # w/o time-effect
test.te.0102 = CorrHetero_TE_test(panel.0102,nobs=nobs,Tobs=2,k=2) # w/ time-effect

# FE estimators (2001-2002)
fe.0102 = FE_est(panel.0102,nobs=nobs,Tobs=2,k=2) # w/o time-effect
fe.te.0102 = FE_TE_est(panel.0102,nobs=nobs,Tobs=2,k=2) # w/ time-effect

# GP estimators (2001-2002)
gp.0102 = GP_est(panel.0102,nobs=nobs,Tobs=2,k=2,te=0) # w/o time-effect
gp.te.0102 = GP_est(panel.0102,nobs=nobs,Tobs=2,k=2,te=1) # with time-effect

# SU estimators (2001-2002)
su.0102 = SU_est(panel.0102,nobs=nobs,Tobs=2,k=2) # w/o time-effect
su.te.0102 = SU_TE_est(panel.0102,nobs=nobs,Tobs=2,k=2) # w/ time-effect

# TMG estimators (2001-2002)
tmg.0102 = TMG_est(panel.0102,nobs=nobs,Tobs=2,k=2) # w/o time-effect
tmg.te.0102 = TMG_TE_est(panel.0102,nobs=nobs,Tobs=2,k=2) # w/ time-effect

# Hausman-type statistics (2000-2002)
test.0002 = CorrHetero_test(panel.0002,nobs=nobs,Tobs=3,k=2) # w/o time-effect
test.te.0002 = CorrHetero_TE_test(panel.0002,nobs=nobs,Tobs=3,k=2) # w/ time-effect
test.c.0002 = CorrHetero_C_test(panel.0002,nobs=nobs,Tobs=3,k=2) # w/ time-effect

# FE estimators (2000-2002)
fe.0002 = FE_est(panel.0002,nobs=nobs,Tobs=3,k=2) # w/o time-effect
fe.te.0002 = FE_TE_est(panel.0002,nobs=nobs,Tobs=3,k=2) # w/ time-effect

# GP estimators (2000-2002)
gp.0002 = GP_est(panel.0002,nobs=nobs,Tobs=3,k=2,te=0) # w/o time-effect
gp.te.0002 = GP_est(panel.0002,nobs=nobs,Tobs=3,k=2,te=1) # with time effects

# TMG estimators (2000-2002)
tmg.0002 = TMG_est(panel.0002,nobs=nobs,Tobs=3,k=2) # w/o time-effect
tmg.te.0002 = TMG_TE_est(panel.0002,nobs=nobs,Tobs=3,k=2) # w/ time-effect
tmg.c.0002 = TMG_C_est(panel.0002,nobs=nobs,Tobs=3,k=2) # w/ time-effect)
################################################################################


### Results Collection ###
####################################################################################################

# Table 6
test.result = matrix(NA,2,5)
test.result[1:2,1] = test.0102[1:2]
test.result[1:2,2] = test.0002[1:2]
test.result[1:2,3] = test.te.0102[1:2]
test.result[1:2,4] = test.te.0002[1:2]
test.result[1:2,5] = test.c.0002[1:2]

cv = matrix(NA,2,1)
test.result = cbind(test.result[,1],cv,test.result[,2],cv,test.result[,3],cv,test.result[,4:5])

# Table 7
est.result.T2 = matrix(NA, 5, 8)
est.result.T2[1,1] = fe.0102[2]
est.result.T2[2,1] = sqrt(fe.0102[4])

est.result.T2[1,2] = gp.0102[2]
est.result.T2[2,2] = sqrt(gp.0102[4])
est.result.T2[5,2] = 100*gp.0102[6]

est.result.T2[1,3] = su.0102[2]
est.result.T2[2,3] = sqrt(su.0102[4])
est.result.T2[5,3] = 100*su.0102[6]

est.result.T2[1,4] = tmg.0102[2]
est.result.T2[2,4] = sqrt(tmg.0102[4])
est.result.T2[5,4] = 100*tmg.0102[6]

est.result.T2[1,5] = fe.te.0102[2]
est.result.T2[2,5] = sqrt(fe.te.0102[4])
est.result.T2[3,5] = fe.te.0102[7]
est.result.T2[4,5] = sqrt(fe.te.0102[9])

est.result.T2[1,6] = gp.te.0102[2]
est.result.T2[2,6] = sqrt(gp.te.0102[4]) 
est.result.T2[3,6] = gp.te.0102[7]
est.result.T2[4,6] = sqrt(gp.te.0102[9])
est.result.T2[5,6] = 100*gp.te.0102[10]

est.result.T2[1,7] = su.te.0102[2]
est.result.T2[2,7] = sqrt(su.te.0102[4])
est.result.T2[5,7] = 100*su.te.0102[8]

est.result.T2[1,8] = tmg.te.0102[2]
est.result.T2[2,8] = sqrt(tmg.te.0102[4])
est.result.T2[3,8] = tmg.te.0102[7]
est.result.T2[4,8] = sqrt(tmg.te.0102[9])
est.result.T2[5,8] = 100*tmg.te.0102[10]

cv = matrix(NA,5,1)
est.result.T2 = cbind(est.result.T2[,1:4],cv,est.result.T2[,5:8])

# Table 8
est.result.T3 = matrix(NA, 7, 7)
est.result.T3[1,1] = fe.0002[2]
est.result.T3[2,1] = sqrt(fe.0002[4])

est.result.T3[1,2] = gp.0002[2]
est.result.T3[2,2] = sqrt(gp.0002[4])
est.result.T3[7,2] = 100*gp.0002[6]

est.result.T3[1,3] = tmg.0002[2]
est.result.T3[2,3] = sqrt(tmg.0002[4])
est.result.T3[7,3] = 100*tmg.0002[6]

est.result.T3[1,4] = fe.te.0002[2]
est.result.T3[2,4] = sqrt(fe.te.0002[4])
est.result.T3[3,4] = fe.te.0002[7]
est.result.T3[4,4] = sqrt(fe.te.0002[10])
est.result.T3[5,4] = fe.te.0002[8]
est.result.T3[6,4] = sqrt(fe.te.0002[11])

est.result.T3[1,5] = gp.te.0002[2]
est.result.T3[2,5] = sqrt(gp.te.0002[4]) 
est.result.T3[3,5] = gp.te.0002[7]
est.result.T3[4,5] = sqrt(gp.te.0002[10])
est.result.T3[5,5] = gp.te.0002[8]
est.result.T3[6,5] = sqrt(gp.te.0002[11])
est.result.T3[7,5] = 100*gp.te.0002[12]

est.result.T3[1,6] = tmg.te.0002[2]
est.result.T3[2,6] = sqrt(tmg.te.0002[4]) 
est.result.T3[3,6] = tmg.te.0002[7]
est.result.T3[4,6] = sqrt(tmg.te.0002[10])
est.result.T3[5,6] = tmg.te.0002[8]
est.result.T3[6,6] = sqrt(tmg.te.0002[11])
est.result.T3[7,6] = 100*tmg.te.0002[12]

est.result.T3[1,7] = tmg.c.0002[2]
est.result.T3[2,7] = sqrt(tmg.c.0002[4]) 
est.result.T3[3,7] = tmg.c.0002[7]
est.result.T3[4,7] = sqrt(tmg.c.0002[10])
est.result.T3[5,7] = tmg.c.0002[8]
est.result.T3[6,7] = sqrt(tmg.c.0002[11])
est.result.T3[7,7] = 100*tmg.c.0002[12]

cv = matrix(NA,7,1)
est.result.T3 = cbind(est.result.T3[,1:3],cv,est.result.T3[,4:7])
################################################################################


# Install and load the openxlsx package
if (!requireNamespace("openxlsx", quietly = TRUE)) {
  install.packages("openxlsx")
}
library(openxlsx)

# Create a style for center-aligning the numbers
center_style <- createStyle(halign = "center")
bbs <- createStyle(border = "bottom",borderStyle="thin")
lbs <- createStyle(border = "bottom",borderStyle="double")
tbs <- createStyle(border = "top",borderStyle="double")
wrap_text_style <- createStyle(wrapText = TRUE)

# Create a new workbook
wb <- createWorkbook()

# Add a worksheet to the workbook
sn = "Table 6"
addWorksheet(wb, sn)

# Report Hausman-type statistics for testing correlated heterogeneity
##############################################################################################
# Add a heading that spans multiple columns
writeData(wb, sn, x = "Table 6: Hausman-type statistics for testing correlated heterogeneity in the e ects of household expenditures on calorie demand in Nicaragua", startCol = 1, startRow = 1, colNames = FALSE)
writeData(wb, sn, x = "Without time effects", startCol = 2, startRow = 2, colNames = FALSE)
writeData(wb, sn, x = "With time effects", startCol = 6, startRow = 2, colNames = FALSE)
# Merge cells for the heading
mergeCells(wb, sheet = sn, cols = 1:9, rows = 1)
mergeCells(wb, sheet = sn, cols = 2:4, rows = 2)
mergeCells(wb, sheet = sn, cols = 6:9, rows = 2)

h2 = matrix(,nrow(test.result),ncol(test.result))
h2[which(is.na(test.result)==F)] = format(round(test.result[which(is.na(test.result)==F)], 3), nsmall = 3) 
hh1 = c("2001--2002","","2000--2002","","2001--2002","","2000--2002","2000--2002")
hh2 = c("","","","","TMG-TE","","TMG-TE","TMG-C")
hl1 = c("2","","3","","2","","3","3")
htab = rbind(hh1,hh2,h2,hl1)
hc1 = c("","","Statistics","p-value","T") 
htab = cbind(hc1,htab)
htab[is.na(htab)] = rep("",length(which(is.na(htab)==1)))
rownames(htab) <- NULL
colnames(htab) <- NULL


# Write your data below the heading
writeData(wb, sn, x = htab, startCol = 1, startRow = 3,colNames = FALSE, rowNames = FALSE)
addStyle(wb,sn,style = center_style, rows = 2:7,cols = 2:9, gridExpand = T)

addStyle(wb,sn,style = wrap_text_style, rows = 1,cols = 1:(ncol(htab)), gridExpand = T,stack=T)

addStyle(wb,sn,style = bbs, rows = 2,cols = c(2:4,6:9), gridExpand = T,stack=T)
addStyle(wb,sn,style = bbs, rows = 3,cols = c(2,4,6,8,9), gridExpand = T,stack=T)
addStyle(wb,sn,style = bbs, rows = 4,cols = c(1:4,6:9), gridExpand = T,stack=T)
addStyle(wb,sn,style = tbs, rows = 2,cols = 1:9, gridExpand = T,stack=T)
addStyle(wb,sn,style = lbs, rows = 7,cols = 1:9, gridExpand = T,stack=T)
##############################################################################################

# Add a worksheet to the workbook
sn = 'Table 7'
addWorksheet(wb,sn)

# Report estimated average effects for panels with T=2
##############################################################################################
# Add a heading that spans multiple columns
writeData(wb, sn, x = "Table 7: Alternative estimates of the average effect of household expenditures on calorie demand in Nicaragua over the period 2001--2002 (T = 2)", startCol = 1, startRow = 1, colNames = FALSE)
writeData(wb, sn, x = "Without time effects", startCol = 2, startRow = 2, colNames = FALSE)
writeData(wb, sn, x = "With time effects", startCol = 7, startRow = 2, colNames = FALSE)
# Merge cells for the heading
mergeCells(wb, sheet = sn, cols = 1:10, rows = 1)
mergeCells(wb, sheet = sn, cols = 2:5, rows = 2)
mergeCells(wb, sheet = sn, cols = 7:10, rows = 2)

e2 = matrix(,nrow(est.result.T2),ncol(est.result.T2))
e2[which(is.na(est.result.T2)==F)] = sprintf("%.4f", est.result.T2[which(is.na(est.result.T2)==F)] )
for (i in c(2,4)) {
  for (j in 1:ncol(e2)) {
    if (is.na(e2[i,j])==F) {
      e2[i,j] = paste0("(",e2[i,j],")",sep="")
    }
  }
}
for (i in c(5)) {
  for (j in 1:ncol(e2)) {
    if (is.na(e2[i,j])==F) {
      e2[i,j] = sprintf("%.1f",est.result.T2[i,j])
    }
  }
}
eh1 = c("(1)","(2)","(3)","(4)","","(5)","(6)","(7)","(8)")
eh2 = c("FE","GP","SU","TMG","","FE-TE","GP","SU","TMG-TE")
e2tab = rbind(eh1,eh2,e2)
ec1 = c("","","hat{beta}_0","","hat{phi}_2002","","hat{pi} (times 100)") 
e2tab = cbind(ec1,e2tab)
e2tab[is.na(e2tab)] = rep("...",length(which(is.na(e2tab)==1)))
e2tab[,6] = ""
rownames(e2tab) <- NULL
colnames(e2tab) <- NULL
# print(htab)

# Write your data below the heading
writeData(wb,sn, x = e2tab, startCol = 1, startRow = 3,colNames = FALSE, rowNames = FALSE)
addStyle(wb,sn,style = center_style, rows = 2:(nrow(e2tab)+2),cols = 2:(ncol(e2tab)), gridExpand = T)

addStyle(wb,sn,style = wrap_text_style, rows = 1,cols = 1:(ncol(e2tab)), gridExpand = T,stack=T)

addStyle(wb,sn,style = bbs, rows = 2,cols = c(2:5,7:10), gridExpand = T,stack=T)
addStyle(wb,sn,style = bbs, rows = 4,cols = c(1:5,7:10), gridExpand = T,stack=T)
addStyle(wb,sn,style = tbs, rows = 2,cols = 1:(ncol(e2tab)), gridExpand = T,stack=T)
addStyle(wb,sn,style = lbs, rows = (nrow(e2tab)+2),cols = 1:(ncol(e2tab)), gridExpand = T,stack=T)
##############################################################################################

# Add a worksheet to the workbook
sn = 'Table 8'
addWorksheet(wb, sn)

# Report estimated average effects for panels with T=2
##############################################################################################
# Add a heading that spans multiple columns
writeData(wb, sn, x = "Table 8: Alternative estimates of the average effect of household expenditures on calorie demand in Nicaragua over the period 2000--2002 (T = 3)", startCol = 1, startRow = 1, colNames = FALSE)
writeData(wb, sn, x = "Without time effects", startCol = 2, startRow = 2, colNames = FALSE)
writeData(wb, sn, x = "With time effects", startCol = 6, startRow = 2, colNames = FALSE)
# Merge cells for the heading
mergeCells(wb, sheet = sn, cols = 1:9, rows = 1)
mergeCells(wb, sheet = sn, cols = 2:4, rows = 2)
mergeCells(wb, sheet = sn, cols = 6:9, rows = 2)

e3 = matrix(NA,nrow(est.result.T3),ncol(est.result.T3))
e3[which(is.na(est.result.T3)==F)] = sprintf("%.4f", est.result.T3[which(is.na(est.result.T3)==F)] )
for (i in c(2,4,6)) {
  for (j in 1:ncol(e3)) {
    if (is.na(e3[i,j])==F) {
      e3[i,j] = paste0("(",e3[i,j],")",sep="")
    }
  }
}
for (i in c(7)) {
  for (j in 1:ncol(e3)) {
    if (is.na(e3[i,j])==F) {
      e3[i,j] = sprintf("%.1f",est.result.T3[i,j])
    }
  }
}
eh1 = c("(1)","(2)","(3)","","(4)","(5)","(6)","(7)")
eh2 = c("FE","GP","TMG","","FE-TE","GP","TMG-TE","TMG-C")
e3tab = rbind(eh1,eh2,e3)
ec1 = c("","","hat{beta}_0","","hat{phi}_2001","","hat{phi}_2002","","hat{pi} (times 100)") 
e3tab = cbind(ec1,e3tab)
e3tab[is.na(e3tab)] = rep("...",length(which(is.na(e3tab)==1)))
e3tab[,5] = ""
rownames(e3tab) <- NULL
colnames(e3tab) <- NULL

# Write your data below the heading
writeData(wb,sn, x = e3tab, startCol = 1, startRow = 3,colNames = FALSE, rowNames = FALSE)
addStyle(wb,sn,style = center_style, rows = 2:(nrow(e3tab)+2),cols = 2:(ncol(e3tab)), gridExpand = T)

addStyle(wb,sn,style = wrap_text_style, rows = 1,cols = 1:(ncol(e3tab)), gridExpand = T,stack=T)

addStyle(wb,sn,style = bbs, rows = 2,cols = c(2:4,6:9), gridExpand = T,stack=T)
addStyle(wb,sn,style = bbs, rows = 3,cols = c(2:4,6:9), gridExpand = T,stack=T)
addStyle(wb,sn,style = bbs, rows = 4,cols = c(1:4,6:9), gridExpand = T,stack=T)
addStyle(wb,sn,style = tbs, rows = 2,cols = 1:(ncol(e3tab)), gridExpand = T,stack=T)
addStyle(wb,sn,style = lbs, rows = (nrow(e3tab)+2),cols = 1:(ncol(e3tab)), gridExpand = T,stack=T)
##############################################################################################


# Save the workbook to an Excel file
saveWorkbook(wb, file = "RPS_results.xlsx",overwrite = TRUE)

# Provide a message to confirm the process is complete
cat("Results of the Hausman-type test of correlated heterogeneity and estimation have been written to the Excel file RPS_results.xlsx.")



